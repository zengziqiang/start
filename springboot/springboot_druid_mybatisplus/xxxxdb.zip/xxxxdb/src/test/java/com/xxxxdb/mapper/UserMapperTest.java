package com.xxxxdb.mapper;

import com.xxxxdb.entity.User;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * @author iszengziqiang@163.com
 * @date 2020/12/14 20:03
 * @Version: 1.0
 * @desc //todo
 */
@SpringBootTest
class UserMapperTest {

    @Autowired
    UserMapper userMapper;

    @Test
    public void getUser() {
        User user = userMapper.selectById(1);
        System.out.println(user.toString());
    }


}