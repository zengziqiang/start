package com.xxxxdb.service;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.xxxxdb.entity.User;
import com.xxxxdb.mapper.UserMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

/**
 * @author iszengziqiang@163.com
 * @date 2020/12/14 20:14
 * @Version: 1.0
 * @desc //todo
 */
@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService {
    /**
     * @param id
     * @return
     */
    @Override
    public String getUser(Integer id) {
        User byId = getById(id);
        if (byId != null) {
            return byId.toString();
        }
        return "无数据";
    }

    @Transactional
    @Override
    public String creatUser(Integer flag) {
        User user = new User();
        int i = (int) (1 + Math.random() * (1000));
        user.setName("姓名：" + i);
        user.setAddress("地址：" + i);
        user.setCreateTime(LocalDateTime.now());
        boolean save = save(user);
        if (flag == 1) {
            int i1 = 1 / 0;
        }
        return String.valueOf(save);
    }
}
