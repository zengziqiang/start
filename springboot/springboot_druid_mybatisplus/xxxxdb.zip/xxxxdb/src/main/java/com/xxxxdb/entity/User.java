package com.xxxxdb.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * @author iszengziqiang@163.com
 * @date 2020/12/14 19:52
 * @Version: 1.0
 * @desc //todo
 */
@Data
public class User {

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;
    private String name;
    private String address;
    private LocalDateTime createTime;
    private LocalDateTime updateTime;

}
