package com.xxxxdb.controller;

import com.xxxxdb.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author iszengziqiang@163.com
 * @date 2020/12/14 20:14
 * @Version: 1.0
 * @desc //todo
 */
@RestController
@RequestMapping("/user/")
public class UserController {

    @Autowired
    UserService userService;

    @GetMapping(value = "/id")
    public String getUser(Integer id){
        return userService.getUser(id);
    }

    @GetMapping(value = "/create")
    public String creatUser(Integer flag){
        return userService.creatUser(flag);
    }

}
