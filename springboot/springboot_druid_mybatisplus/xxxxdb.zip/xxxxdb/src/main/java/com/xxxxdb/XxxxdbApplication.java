package com.xxxxdb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//@MapperScan("com.xxxxdb.mapper")
@SpringBootApplication
public class XxxxdbApplication {

    public static void main(String[] args) {
        SpringApplication.run(XxxxdbApplication.class, args);
    }

}
