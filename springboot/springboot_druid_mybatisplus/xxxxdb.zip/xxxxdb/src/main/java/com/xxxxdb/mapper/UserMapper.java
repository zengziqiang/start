package com.xxxxdb.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.xxxxdb.entity.User;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

/**
 * @author iszengziqiang@163.com
 * @date 2020/12/14 19:57
 * @Version: 1.0
 * @desc //todo
 */
@Mapper
@Repository
public interface UserMapper extends BaseMapper<User> {

}
