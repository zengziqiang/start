package com.xxxxdb.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.xxxxdb.entity.User;

/**
 * @author iszengziqiang@163.com
 * @date 2020/12/14 20:13
 * @Version: 1.0
 * @desc //todo
 */
public interface UserService extends IService<User> {
    /**
     *
     * @param id
     * @return
     */
    String getUser(Integer id);

    String creatUser(Integer flag);
}
