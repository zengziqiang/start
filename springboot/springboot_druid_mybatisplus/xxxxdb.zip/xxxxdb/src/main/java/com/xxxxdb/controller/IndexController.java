package com.xxxxdb.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;

/**
 * @author iszengziqiang@163.com
 * @date 2020/12/14 18:07
 * @Version: 1.0
 * @desc //todo
 */
@RestController
public class IndexController {

    @GetMapping("/")
    public String indexTime() {
        return LocalDateTime.now().toString();
    }

}
