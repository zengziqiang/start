package com.bkgtsoft.a.web.controller;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.*;

/**
 * @author iszengziqiang@163.com
 * @date 2020/6/11 15:13
 * @Version: 1.0
 * @desc //todo
 */
@SpringBootTest
class SupplyApprovalLogControllerTest {



    @Test
    public void abc(){
        System.out.println("1");
    }

}