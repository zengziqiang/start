package com.bkgtsoft.spd.common.controller;

import com.alibaba.fastjson.JSON;
import com.bkgtsoft.spd.common.response.RespBean;
import lombok.extern.slf4j.Slf4j;

/**
 * @author qixinqiang
 * 基类, 所有的controller应继承该类
 */
@Slf4j
public abstract class BaseController {

    protected String interfaceVersion = "dev-0.0.1";

    /**
     * 简化写法，已包括：log、异常
     *
     * @param logName     log名称
     * @param dto         参数
     * @param interfaceId 接口地址
     * @param callable    回调
     * @return
     */
    protected RespBean exec(String logName, Object dto, String interfaceId, ControllerCallable callable) {
        return exec(logName, dto, interfaceId, true, callable);
    }

    /**
     * 简化写法，已包括：log、异常
     *
     * @param logName     log名称
     * @param dto         参数
     * @param interfaceId 接口地址
     * @param showResult  是否展示结果到log，针对list记录过大时，应该false
     * @param callable    回调
     * @return
     */
    protected RespBean exec(String logName, Object dto, String interfaceId, boolean showResult, ControllerCallable callable) {
        log.info(logName + " param:{}", JSON.toJSONString(dto, true));
        RespBean respBean = null;
        try {
            respBean = callable.execute();
        } catch (Exception e) {
            log.error(logName + "异常", e);
            respBean = RespBean.error(500, "操作失败，请稍后再试", interfaceId, interfaceVersion);
            return respBean;
        }
        if (showResult)
            log.info(logName + " result:{}", JSON.toJSONString(respBean, true));
        else {
            log.info(logName + " result:{}", JSON.toJSONString(RespBean.ok(interfaceId, interfaceVersion), true));
        }
        return respBean;
    }
}
