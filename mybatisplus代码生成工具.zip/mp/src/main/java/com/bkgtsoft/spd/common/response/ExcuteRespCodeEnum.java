package com.bkgtsoft.spd.common.response;

/**
 * @author lzb
 * @Title: ItbpSuccessCodeEnum
 * @Description: Itbp 响应信息枚举
 * @date 2019/6/12 9:49
 */
public enum ExcuteRespCodeEnum implements RespCodeEnum {
    EXCUTE_SUCCESS(205, "操作成功"),
    EXCUTE_FAILED(305, "操作失败"),
    QUERY_SUCCESS(201, "查询成功"),
    QUERY_FAILED(301, "查询失败"),
    INSERT_SUCCESS(202, "新增成功"),
    INSERT_FAILED(302, "新增失败"),
    UPDATE_SUCCESS(203, "更新成功"),
    UPDATE_FAILED(303, "更新失败"),
    DELETE_SUCCESS(204, "删除成功"),
    DELETE_FAILED(304, "删除失败"),
    PARAMETER_IS_NULL(305, "参数为空"),
    PARAMETER_FAILED(306, "无效参数");

    private int code;
    private String msg;

    private ExcuteRespCodeEnum(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    @Override
    public int getCode() {
        return this.code;
    }

    @Override
    public String getMsg() {
        return this.msg;
    }

    public static RespCodeEnum getRespCodeEnumByCode(int code) {
        for (ExcuteRespCodeEnum value : ExcuteRespCodeEnum.values()) {
            if (value.getCode() == code) {
                return value;
            }
        }
        return null;
    }
}
