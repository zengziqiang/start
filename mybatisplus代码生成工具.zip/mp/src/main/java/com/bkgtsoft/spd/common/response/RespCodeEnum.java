package com.bkgtsoft.spd.common.response;

/**
 * @author esJiang
 * @Title: RespCodeEnum
 * @Description: 统一响应码信息 所有的响应信息必须实现该接口
 * @date 2019/6/12 9:48
 */
public interface RespCodeEnum {

    /**
     * @Author esJiang
     * @Describle 返回响应码
     * @Date 2019/6/12 10:02
     */
    int getCode() ;

    /**
     * @Author esJiang
     * @Describle 返回响应信息
     * @Date 2019/6/12 10:02
     */
    String getMsg() ;

}
