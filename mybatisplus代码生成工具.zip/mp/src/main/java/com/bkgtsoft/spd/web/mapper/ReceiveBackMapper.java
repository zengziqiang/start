package com.bkgtsoft.spd.web.mapper;

import com.bkgtsoft.spd.web.entity.ReceiveBack;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 高值耗材领用/归还表 Mapper 接口
 * </p>
 *
 * @author zzq
 * @since 2020-12-11
 */
public interface ReceiveBackMapper extends BaseMapper<ReceiveBack> {

}
