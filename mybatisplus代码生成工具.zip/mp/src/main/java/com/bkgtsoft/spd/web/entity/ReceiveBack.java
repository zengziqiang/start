package com.bkgtsoft.spd.web.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.time.LocalDateTime;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 高值耗材领用/归还表
 * </p>
 *
 * @author zzq
 * @since 2020-12-11
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("highvalue_receive_back")
@ApiModel(value="ReceiveBack对象", description="高值耗材领用/归还表")
public class ReceiveBack implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "cw_material_out_detail表ID")
    @TableField("material_out_detail_id")
    private Integer materialOutDetailId;

    @ApiModelProperty(value = "散货：明细条码；高值：高值耗材码")
    @TableField("bar_code_detail")
    private String barCodeDetail;

    @ApiModelProperty(value = "发放日期")
    @TableField("receive_date")
    private LocalDateTime receiveDate;

    @ApiModelProperty(value = "归还日期")
    @TableField("back_date")
    private LocalDateTime backDate;

    @ApiModelProperty(value = "领用人")
    @TableField("receive_username")
    private String receiveUsername;

    @ApiModelProperty(value = "领用人ID")
    @TableField("receive_id")
    private Integer receiveId;

    @ApiModelProperty(value = "科室ID")
    @TableField("office_id")
    private Integer officeId;

    @ApiModelProperty(value = "科室名称")
    @TableField("office_name")
    private String officeName;

    @ApiModelProperty(value = "出库仓库ID")
    @TableField("warehouse_out_id")
    private Integer warehouseOutId;

    @ApiModelProperty(value = "出库仓库名称")
    @TableField("warehouse_out_name")
    private String warehouseOutName;

    @ApiModelProperty(value = "1发放2归还3使用")
    @TableField("status")
    private Integer status;

    @TableField("create_time")
    private LocalDateTime createTime;

    @TableField("update_time")
    private LocalDateTime updateTime;


}
