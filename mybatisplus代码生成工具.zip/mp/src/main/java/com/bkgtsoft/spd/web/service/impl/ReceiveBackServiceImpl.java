package com.bkgtsoft.spd.web.service.impl;

import com.bkgtsoft.spd.web.entity.ReceiveBack;
import com.bkgtsoft.spd.web.mapper.ReceiveBackMapper;
import com.bkgtsoft.spd.web.service.ReceiveBackService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 高值耗材领用/归还表 服务实现类
 * </p>
 *
 * @author zzq
 * @since 2020-12-11
 */
@Service
public class ReceiveBackServiceImpl extends ServiceImpl<ReceiveBackMapper, ReceiveBack> implements ReceiveBackService {

}
