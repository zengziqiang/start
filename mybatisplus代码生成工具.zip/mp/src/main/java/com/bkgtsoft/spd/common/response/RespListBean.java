package com.bkgtsoft.spd.common.response;

import java.util.List;


/**
   * @Description 接口返回对象
   * @Author esJiang
   * @Date 2019/6/12 14:36
   * @Version V0.0.4
**/
public class RespListBean<T> extends RespBean<ListVo<T>> {

    public void setInfo(List<T> list) {
        ListVo<T> listVo = new ListVo<>();
        listVo.setList(list);
        listVo.setTotal(list.size());
        super.setInfo(listVo);
    }

    public void setInfo(List<T> list,Integer size) {
        ListVo<T> listVo = new ListVo<>();
        listVo.setList(list);
        listVo.setTotal(size);
        super.setInfo(listVo);
    }
}