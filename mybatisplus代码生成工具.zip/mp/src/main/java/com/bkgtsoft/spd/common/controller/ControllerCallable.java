package com.bkgtsoft.spd.common.controller;


import com.bkgtsoft.spd.common.response.RespBean;

/**
 */
@FunctionalInterface
public interface ControllerCallable<T> {
    RespBean<T> execute();
}