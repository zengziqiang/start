package com.bkgtsoft.spd.web.service;

import com.bkgtsoft.spd.web.entity.ReceiveBack;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 高值耗材领用/归还表 服务类
 * </p>
 *
 * @author zzq
 * @since 2020-12-11
 */
public interface ReceiveBackService extends IService<ReceiveBack> {

}
