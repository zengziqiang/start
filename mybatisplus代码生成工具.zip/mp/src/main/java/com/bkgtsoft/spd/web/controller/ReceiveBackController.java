package com.bkgtsoft.spd.web.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 高值耗材领用/归还表 前端控制器
 * </p>
 *
 * @author zzq
 * @since 2020-12-11
 */
@RestController
@RequestMapping("/web/receive-back")
public class ReceiveBackController {

}
