package com.bkgtsoft.spd.common.response;


import java.util.List;

/**
 * @ClassName ListVo
 * @Description 配合RespListBean使用
 * @Author esJiang
 * @Date 2019/3/5 17:11
 * Version V0.0.4
 */
public class ListVo<T> {
    private List<T> list;
    private int total;

    public ListVo() {
    }

    public ListVo(List<T> list) {
        this.list = list;
        if(null != list ){
            this.total = list.size() ;
        }
    }

    public ListVo(List<T> list, int total) {
        this.list = list;
        this.total = total;
    }

    public List<T> getList() {
        return list;
    }

    public void setList(List<T> list) {
        this.list = list;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

}
