package com.bkgtsoft.spd.common.response;

import lombok.Data;


/**
 * @Description 接口返回对象
 * @Author esJiang
 * @Date 2019/6/12 14:36
 * @Version V1.0.1
 **/
@Data
public class RespBean<T> {
    private boolean status;
    private int code;
    private String msg;
    private String interfaceId;
    private String interfaceversion;
    private T info;

    public RespBean() {
    }

    public static <T> RespBean<T> ok(String interfaceId, String interfaceversion) {
        return new RespBean<>(true, null, null, interfaceId, interfaceversion);
    }

    public static <T> RespBean<T> ok(RespCodeEnum respCodeEnum, T obj, String interfaceId, String interfaceversion) {
        return new RespBean<>(true, respCodeEnum, obj, interfaceId, interfaceversion);
    }

    public static <T> RespBean<T> ok(RespCodeEnum respCodeEnum, String interfaceId, String interfaceversion) {
        return new RespBean<>(true, respCodeEnum, null, interfaceId, interfaceversion);
    }

    public static <T> RespBean<T> ok(int code, String msg, T obj, String interfaceId, String interfaceversion) {
        return new RespBean<>(true, code, msg, obj, interfaceId, interfaceversion);
    }

    public static <T> RespBean<T> error(RespCodeEnum respCodeEnum, T obj, String interfaceId, String interfaceversion) {
        return new RespBean<>(false, respCodeEnum, obj, interfaceId, interfaceversion);
    }

    public static <T> RespBean<T> error(RespCodeEnum respCodeEnum, String interfaceId, String interfaceversion) {
        return new RespBean<>(false, respCodeEnum, null, interfaceId, interfaceversion);
    }

    public static <T> RespBean<T> error(int code, String msg, String interfaceId, String interfaceversion) {
        return new RespBean<>(false, code, msg, null, interfaceId, interfaceversion);
    }

    public static <T> RespBean<T> error(int code, String msg, T obj, String interfaceId, String interfaceversion) {
        return new RespBean<>(false, code, msg, obj, interfaceId, interfaceversion);
    }

    private RespBean(boolean status, RespCodeEnum respCodeEnum, T info, String interfaceId, String interfaceversion) {
        this.status = status;
        if (null != respCodeEnum) {
            this.code = respCodeEnum.getCode();
            this.msg = respCodeEnum.getMsg();
        }
        this.info = info;
        this.interfaceId = interfaceId;
        this.interfaceversion = interfaceversion;
    }

    private RespBean(boolean status, int code, String msg, T info, String interfaceId, String interfaceversion) {
        this.status = status;
        this.code = code;
        this.msg = msg;
        this.info = info;
        this.interfaceId = interfaceId;
        this.interfaceversion = interfaceversion;
    }
}