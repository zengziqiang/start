package com.bkgtsoft.spd.common.response;

import lombok.Getter;

/**
 * @author esJianng
 * @Title: ItbpErrorCodeEnum
 * @Description: Itbp 响应信息枚举
 * @date 2019/6/12 9:49
 */
@Getter
public enum BkRespCodeEnum implements RespCodeEnum {

    SystemError(500, "系统错误"),
    ParameterError(599, "参数错误"),
    NotLogin(501, "未登录"),
    UsernameOrPasswordError(502, "账户名或者密码输入错误"),
    AccountLocked(503, "账户被锁定，请联系管理员"),
    PasswordExpired(504, "密码过期，请联系管理员"),
    AccountForbided(505, "账户被禁用，请联系管理员"),
    LoginFailed(506, "登录失败"),
    BadClentIdentify(508, "客户端信息不能为空"),
    AccessDenied(40301, "拒绝访问"),
    InsufficientAuthentication(40101, "认证失败"),
    InvalidToken(40102, "token过期或非法"),
    TokenNotNull(40302, "token不能为空"),
    MethodNotAllowed(405, "不支持的请求方式"),
    ExcuteFailed(505, "操作失败"),
    QueryFaild(501, "查询失败"),
    QueryParam(511, "查询条件不能为空"),
    ParamNotNull(510, "参数不能为空"),
    UsernameNotNull(509, "用户名不能为空"),
    PasswordNotNull(509, "密码不能为空");


    private int code;
    private String msg;

    BkRespCodeEnum(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public static RespCodeEnum getRespCodeEnumByCode(int code) {
        for (BkRespCodeEnum value : BkRespCodeEnum.values()) {
            if (value.getCode() == code) {
                return value;
            }
        }
        return null;
    }
}
