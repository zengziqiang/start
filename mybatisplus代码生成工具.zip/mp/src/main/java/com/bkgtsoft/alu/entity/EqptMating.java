package com.bkgtsoft.alu.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.time.LocalDateTime;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 装备配套情况表
 * </p>
 *
 * @author zzq
 * @since 2021-01-08
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="EqptMating对象", description="装备配套情况表")
public class EqptMating implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "装备明细Id")
    private Integer equipId;

    @ApiModelProperty(value = "配套名称")
    private String matingName;

    @ApiModelProperty(value = "数量")
    private Integer matingCount;

    @ApiModelProperty(value = "备注")
    private String remark;

    private LocalDateTime createTime;

    private LocalDateTime updateTime;


}
