package com.bkgtsoft.alu.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 装备配套情况表 前端控制器
 * </p>
 *
 * @author zzq
 * @since 2021-01-08
 */
@RestController
@RequestMapping("/alu/eqpt-mating")
public class EqptMatingController {

}
