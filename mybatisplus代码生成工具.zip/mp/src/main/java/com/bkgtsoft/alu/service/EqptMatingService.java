package com.bkgtsoft.alu.service;

import com.bkgtsoft.alu.entity.EqptMating;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 装备配套情况表 服务类
 * </p>
 *
 * @author zzq
 * @since 2021-01-08
 */
public interface EqptMatingService extends IService<EqptMating> {

}
