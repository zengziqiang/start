package com.bkgtsoft.alu.service.impl;

import com.bkgtsoft.alu.entity.EqptMating;
import com.bkgtsoft.alu.mapper.EqptMatingMapper;
import com.bkgtsoft.alu.service.EqptMatingService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 装备配套情况表 服务实现类
 * </p>
 *
 * @author zzq
 * @since 2021-01-08
 */
@Service
public class EqptMatingServiceImpl extends ServiceImpl<EqptMatingMapper, EqptMating> implements EqptMatingService {

}
