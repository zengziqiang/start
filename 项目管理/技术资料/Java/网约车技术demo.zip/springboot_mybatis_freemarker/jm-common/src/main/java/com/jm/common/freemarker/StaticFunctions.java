package com.jm.common.freemarker;

import com.jm.platform.spring.FreemarkerFunction;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * freemarker 的静态资源函数
 */
@Component
public class StaticFunctions {

    @Value("${jzt.static_domain}")
    private String staticDomain;

    @Value("${jzt.static_version}")
    private String staticVersion;

    /**
     * 第三方前端库函数资源
     * 根据 jzt.static_domain 的配置，生成静态资源路径
     * <p/>
     * 比如 /css/base.css 会根据配置变成
     * http://static.yyjzt.com/js/jquery.js 或
     * /static/js/jquery.js
     */
    @FreemarkerFunction("s3")
    public String s3(String resourcePath) {
        return staticDomain + resourcePath;
    }

    /**
     * 自己编写的前端库资源
     * 根据 jzt.static_domain 的配置，生成静态资源路径
     * <p/>
     * 比如 /css/base.css 会根据配置变成
     * http://static.yyjzt.com/css/base.css?v=20170328 或
     * /static/css/base.css?v=20170328
     */
    @FreemarkerFunction("s0")
    public String s0(String resourcePath) {
        return staticDomain + resourcePath + "?v=" + staticVersion;
    }

}
