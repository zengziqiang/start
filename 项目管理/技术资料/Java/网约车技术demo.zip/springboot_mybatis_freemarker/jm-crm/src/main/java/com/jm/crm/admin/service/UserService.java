package com.jm.crm.admin.service;


import com.jm.crm.admin.entity.User;

import java.util.List;
import java.util.Map;


public interface UserService {

    void save(User user);

    User getListUser(String username , String password);
}
