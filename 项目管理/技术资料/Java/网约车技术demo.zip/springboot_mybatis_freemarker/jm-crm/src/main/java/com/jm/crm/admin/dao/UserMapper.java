package com.jm.crm.admin.dao;

import com.jm.crm.admin.entity.User;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

@Mapper
public interface UserMapper {


    void save(User user);

    User getListUser(@Param("username") String username, @Param("password") String password);
}
