package com.jm.crm.admin.service.impl;


import com.jm.crm.admin.dao.UserMapper;
import com.jm.crm.admin.entity.User;
import com.jm.crm.admin.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class UserServiceImpl implements UserService{

    @Autowired
    private UserMapper userMapper;

    @Override
    public void save(User user){
        userMapper.save(user);
    }

    @Override
    public User getListUser(String username , String password){
        return userMapper.getListUser(username , password);
    }
}
