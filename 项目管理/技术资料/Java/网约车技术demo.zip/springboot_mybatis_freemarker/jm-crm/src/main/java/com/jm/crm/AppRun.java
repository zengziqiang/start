package com.jm.crm;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.MultipartConfigFactory;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import javax.servlet.MultipartConfigElement;


@SpringBootApplication
//@EnableCaching
//@EnableFeignClients
//@ServletComponentScan
//@EnableEurekaClient
//@EnableWebMvc
@MapperScan("com.fs") // 扫描：该包下相应的class,主要是MyBatis的持久化类.
public class AppRun extends SpringBootServletInitializer {
    public static void main(String[] args) {
        SpringApplication.run(AppRun.class, args);
    }

    @Bean
    public MultipartConfigElement multipartConfigElemen3t() {
        MultipartConfigFactory factory = new MultipartConfigFactory();
        // 设置文件大小限制
        factory.setMaxFileSize("10MB"); //KB,MB
        // 设置总上传大小限制
        factory.setMaxRequestSize("50MB");
        return factory.createMultipartConfig();
    }
}