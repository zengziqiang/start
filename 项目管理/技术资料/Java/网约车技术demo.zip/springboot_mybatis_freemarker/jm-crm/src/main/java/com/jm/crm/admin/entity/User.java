package com.jm.crm.admin.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

public class User implements Serializable{

    @ApiModelProperty("用户编号")
    @JsonProperty("id")
    private int id;

    @ApiModelProperty("用户名称")
    @JsonProperty("username")
    private String username;

    @ApiModelProperty("用户密码")
    @JsonProperty("password")
    private String password;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
