package com.jm.crm.admin.controller;


import com.google.gson.Gson;
import com.jm.crm.admin.entity.User;
import com.jm.crm.mq.UserSender;
import com.jm.crm.admin.service.UserService;
import com.jm.crm.mq.config.RabbitMQConfigDirect;
import com.jm.platform.platform.HttpParameterParser;
import com.jm.platform.springmvc.JsonView;
import io.swagger.annotations.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.Map;


//192.168.0.180:8081/swagger-ui.html
@RestController
@RequestMapping("/admin")
public class AdminController {
    private static final Logger LOGGER = LoggerFactory.getLogger(AdminController.class);


    @Autowired
    private UserService userService;

    @Autowired
    private RedisTemplate redisTemplate;

    @Autowired
    private UserSender userSender;

//    @Autowired
//    private RabbitMQConfig rabbitMQConfig;   @Autowired
//    private RabbitMQConfig rabbitMQConfig;

    //value = 右侧显示的信息
    //notes = 详细描述
    @ApiOperation(value = "首页", notes = "进入注册页面", response = Void.class)
//    @ApiResponses(@ApiResponse(code = 404, message = "没有找到此接口", response = Void.class))
    @RequestMapping(value = "/index.htm", method = RequestMethod.GET)
    public ModelAndView index(HttpServletRequest request) {
         return new ModelAndView("/index.ftl");
    }



    @RequestMapping(value = "/hello1.htm", method = RequestMethod.GET)
    public void hello1(HttpServletRequest request) {
        String str =  userSender.send1("发送一条简单的消息队列1");
        LOGGER.info("======="+ str);
    }

    @RequestMapping(value = "/hello2.htm", method = RequestMethod.GET)
    public void hello2(HttpServletRequest request) {
        //发送简单队列
        String str =  userSender.send2("发送一条简单的消息队列2");
        LOGGER.info("======="+ str);
    }

    @RequestMapping(value = "/hello3.htm", method = RequestMethod.GET)
    public void hello3(HttpServletRequest request) {
        //发送简单队列
        String str =  userSender.send3("发送一条简单的消息队列2");
        LOGGER.info("======="+ str);
    }

    @ApiOperation(value = "注册", notes = "用户注册", response = Void.class)
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "form", dataType = "String", name = "username", value = "用户名"),
            @ApiImplicitParam(paramType = "form", dataType = "String", name = "password", value = "用户密码")
    })
//    @ApiResponses(@ApiResponse(code = 404, message = "没有找到此接口", response = Void.class))
    @RequestMapping(value = "/save.htm", method = RequestMethod.POST, produces = MediaType.TEXT_HTML_VALUE)
    public ModelAndView save(HttpServletRequest request) {
        final HttpParameterParser parser = HttpParameterParser.newInstance(request);
        final String username = parser.getString("username", "");
        final String password = parser.getString("password", "");
        User user = new User();
        user.setUsername(username);
        user.setPassword(password);

            //redis存
            redisTemplate.opsForValue().set("model", user);
            userService.save(user);
            return new ModelAndView("/error/500.ftl");
    }

    @ResponseBody
    @ApiOperation(value = "登陆", notes = "获取用户信息", response = User.class)
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "username", value = "用户名"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "password", value = "用户密码")
    })
    @ApiResponses(@ApiResponse(code = 404, message = "没有找到此接口getListUser", response = Void.class))
    @RequestMapping(value = "/getListUser.json", method = RequestMethod.GET)
    public ModelAndView getListUser(HttpServletRequest request) {

        HttpParameterParser parser = HttpParameterParser.newInstance(request);
        String username = parser.getString("username", "");
        String password = parser.getString("password", "");

        //redis取
        Map<String, Object> model = new HashMap<String, Object>();
        User user = (User) redisTemplate.opsForValue().get("model");
        if (user.getUsername().equalsIgnoreCase(username) && user.getPassword().equalsIgnoreCase(password)) {
            String uname = user.getUsername();
            String upass = user.getPassword();
            model.put("username", uname);
            model.put("password", upass);
            LOGGER.info(user.getUsername() + "========redis========" + user.getPassword());
            return new ModelAndView(new JsonView(model));
        } else {
            User users = userService.getListUser(username, password);
            if (users != null) {
                model.put("user", users);
                return new ModelAndView(new JsonView(model));
            } else {
                model.put("error", "mysql中没有任何数据");
                return new ModelAndView(new JsonView(model));
            }
        }
    }
}
