/*
 * 获取供应商下面的的药品药品数据
 * 
 */
function loadEditMerchandiseTable(supplierId) {
	$("#merchandiseTable").datagrid({
		nowrap : true,
		striped : true,
		fitColumns : true,
		rownumbers: true,
		url : "/admin/supplier/searchSupplierMerchandise.json?supplierId="+supplierId,
		method : 'post',
		pageSize : 10,
		pageNumber : 1,
		pagination : true,
		singleSelect : false,
		frozenColumns : [ [ {
			field : 'merchandiseId',
			checkbox : true
		} ] ],
		columns : [ [  
 		    { title : '药品编码', field : 'orgMerchandiseCode', align : 'center', width:100, resizable : true}, 
 		    { title : '药品名称', field : 'merchandiseName', align : 'center', width:100, resizable : true}, 
 		    { title : '药品规格', field : 'merchandiseSpec', align : 'center', width:100, resizable : true}, 
 		    { title : '生产厂家', field : 'manufacturer', align : 'center', width:150, resizable : true},
 		    { title : '中包装', field : 'middlingPacking', align : 'center', width:50, resizable : true}, 
 		    { title : '单位', field : 'merchandiseUnit', align : 'center', width:50, resizable : true}
 		] ]
	});
}

/*
 *供应商维护界面.,添加药品, 打开药品搜搜界面
 * */
function merchandiseOpen(){
	$('#merchandiseSelectWindow').window({  
	    width:800,  
	    height:500,  
	    modal:true,
	    collapsible:false,
	    minimizable:false,
	    resizable:true,
	    maximizable:false,
	    closable:false,
	    closed:true,
	    position : 'fixed',
	    title:'选择药品',
	    shadow : false
	});	
	
	$('#merchandiseSelectTable').datagrid({
		fit : true,
		nowrap : true,
		striped : true,
		fitColumns : false,
		rownumbers: true,
		toolbar:'#merchandise_tb',
		loadMsg : '数据加载中请稍后……',
		url : '/search/supplierSearchMerchandise.htm?'+Math.random(),//供应商搜索药品,可以查到所有药品,不管是禁销还是状态为2,还是串货
		method : 'post',
		pageSize : 10,
		pageNumber : 1,
		pagination : true,
		singleSelect : false,
		queryParams: {
			keyword: null
		},
		idField : 'merchandise_id',
		frozenColumns : [ [ {
			field : 'merchandise_id',
			checkbox : true
		} ] ],
		columns : [ [
         	{
         		field : 'passfile_number',
         		hidden : true
         	},
			{
				field : 'orgmerchandise_code',
				title : '药品编码',
				align : 'left',
				resizable : true,
				width:100,
				formatter : function(value) { return value ? value : ""; }
			},
			{
				field : 'merchandise_name',
				title : '药品名称',
				align : 'left',
				resizable : true,
				width:150,
				formatter : function(value) { return value ? value : ""; }
			},
			{
				field : 'merchandise_spec',
				title : '规格',
				align : 'left',
				resizable : true,
				width:100,
				formatter : function(value) { return value ? value : ""; }
			},
			{
				field : 'manufacturer',
				title : '厂家',
				align : 'left',
				resizable : true,
				width:150,
				formatter : function(value) { return value ? value : ""; }
			},
			{
				field : 'packing_number',
				title : '中/大包装',
				align : 'left',
				resizable : true,
				width:60,
				formatter : function( value, row, index) { 
					return (row.middling_packing ? row.middling_packing:"") + "/" + (row.packing_number ? row.packing_number:"");
				}
			},
			{
				field : 'storage_number',
				title : '库存',
				align : 'left',
				resizable : true,
				width:60,
				formatter : function( value) { 
					return (value && value>0)? (value>100?">100":"有"):"无";
				}
			},
			{
				field : 'p3',
				title : '零售价',
				align : 'left',
				resizable : true,
				width:60,
				formatter : function(value) { return value ? value : ""; }
			},
			{
				field : 'merchandise_unit',
				title : '单位',
				align : 'left',
				resizable : true,
				width:50,
				formatter : function(value) { return value ? value : ""; }
			}
		] ]
		
	});
	$('#merchandiseSelectWindow').window('open');
	$('#merchandiseSelectWindow').css('display','');
}

//点击搜索界面的查询按钮
function merchandiseReLoad(){
    $("#merchandiseSelectTable").datagrid('load', {
    	keyword : $('#merchandise_keyword').val(),
	});
}



//确定选择搜搜出来的药品,把选择药品复制到供应添加药品商界面
/*function selectMerchandiseOK(){
	var flag = true;
	var selects = $("#merchandiseSelectTable").datagrid("getSelections");//搜索界面选中的列
	var rows = $("#merchandiseTable").datagrid('getRows');//添加界面已经有的列
	if(selects != null && selects.length >0){
		for(var i=0;i<selects.length;i++){
			flag = true;
			//如果选中的药品,已经存在,则不添加
			var selectId = selects[i].merchandise_id ;//选中的药品ID
			if(rows != null && rows.length >0){
				for(var j=0;j<rows.length;j++){
					var rowId = rows[j].merchandise_id;//页面上的药品
					if(rowId == selectId){
						flag = false;//存在,将falg设置为false
						break;
					}
				}
			}
			if(flag){
				$("#merchandiseTable").datagrid('appendRow',selects[i]);
			}
		}
		$('#merchandiseSelectWindow').window('close');
		$("#merchandiseSelectTable").datagrid("clearSelections");//清空搜索界面所有选择
	}else{
		$.messager.alert('提示','请先选择想要添加的药品');
		return false;
	}
}*/

//确定选择搜搜出来的药品,把选择的药品添加到供应商药品库
function selectMerchandiseOK(){
	//获取勾选的药品ID,供应商ID,发送请求到后台,添加药品
	var selects = $("#merchandiseSelectTable").datagrid("getSelections");//搜索界面选中的列
	var orgmerchandiseCodeS = null;
	if(selects != null && selects.length >0){
		$.messager.confirm('系统提示', '您确定添加选中的'+selects.length+'条数据吗?', function(flag) {
			if(flag){
				for(var i=0;i<selects.length;i++){
					if(orgmerchandiseCodeS!=null){
						orgmerchandiseCodeS = orgmerchandiseCodeS + "," + selects[i].orgmerchandise_code ;
					}else{
						orgmerchandiseCodeS = selects[i].orgmerchandise_code ;//选中的药品ID
					}
				}
				$.ajax({
					type: 'post',
					url:'/admin/supplier/addSupplierMerchandise.htm',
					cache:false ,
					data:{
							orgmerchandiseCodeS:orgmerchandiseCodeS,
							supplierId : $("#supplierId").val()
						},
					dataType:'json',
					success:function(result){
						if(result.success){
							$.messager.alert('提示',result.msg,'info');
							$("#merchandiseTable").datagrid("reload");//重新加载供应商拥有的药品
							$("#merchandise_keyword").val('');//清空药品搜索框
							$("#merchandiseSelectTable").datagrid("clearSelections");//清空搜索界面所有选择
							//$("#merchandiseSelectTable").datagrid("reload");
						}else{
							$.messager.alert('提示',result.msg,'error');
						}
					}
				});
			}
		});
	}else{
		$.messager.alert('提示','请先选择想要添加的药品');
		return false;
	}
}

//关闭药品搜索框
function selectMerchandiseCancle(){
	$('#merchandiseSelectWindow').window('close');
	$("#merchandise_keyword").val('');//清空药品搜索框
	$("#merchandiseSelectTable").datagrid("clearSelections");//清空搜索界面所有选择
	
}

//维护供应商时，验证供应商名称唯一性
var nameShowYanFlag = false;
function supplierNameYan2(){
	var newSupplierName = $.trim($("#supplierNameShow").val());//输入框的名称
	var oldSupplierName = $.trim($("#oldSupplierName").val());//原来的供应商名称
	if(oldSupplierName == newSupplierName){//没有改变，不验证
		$("#yanzhengNameShow").html("*");
		nameShowYanFlag = true;
		return false;
	}
	if(newSupplierName == null || newSupplierName==''){
		nameShowYanFlag = false;
		return false;
	}
	var url = "/admin/supplier/supplierNameValid.json?supplierName="+newSupplierName;
	$.get(url,function(data){
		if(data=="false"){//验证通过
			nameShowYanFlag = true;
			$("#yanzhengNameShow").html("*");
		}else{
			//验证失败,用户名已经存在
			nameShowYanFlag = false;
			$("#yanzhengNameShow").html("* 名称已经存在");
		}
	},"text");
}


//在维护供应商界面 点击查询药品按钮
function searchSupplierMerchandise(){
	$('#merchandiseTable').datagrid('options').queryParams={
		"merchandiseKeyword":$("#merchandisekeyword").val()
	};
	$("#merchandiseTable").datagrid('reload');
}

//供应商维护界面,删除选择的药品
function deleteSelectMed(){
	var selects = $('#merchandiseTable').datagrid('getSelections');
	var orgmerchandiseCodeS = null;
	if(selects && selects.length > 0){
		$.messager.confirm('系统提示', '您确定删除选中的'+selects.length+'条数据吗?', function(flag) {
			if(flag){
				//获取选中药品ID
				for(var i=0;i<selects.length;i++){
					if(orgmerchandiseCodeS!=null){
						orgmerchandiseCodeS = orgmerchandiseCodeS + "," + selects[i].orgMerchandiseCode ;
					}else{
						orgmerchandiseCodeS = selects[i].orgMerchandiseCode ;//选中的药品ID
					}
				}
				$.ajax({
					type: 'post',
					url:'/admin/supplier/deleteSupplierMerchandise.htm',
					cache:false ,
					data:{
							orgmerchandiseCodeS:orgmerchandiseCodeS,
							supplierId : $("#supplierId").val()
						},
					dataType:'json',
					success:function(result){
						if(result.success){
							$.messager.alert('提示',result.msg,'info');
							$("#merchandiseTable").datagrid("reload");//重新加载供应商拥有的药品
						}else{
							$.messager.alert('提示',result.msg,'error');
							return false;
						}
					}
				});
			}
		});
		
	}else{
		$.messager.alert('提示','请先选择想要删除的记录','info');
		return false;
	}
}


//确定修改供应商
function commitEditSupplier(){
	var newSupplierName = $.trim($("#supplierNameShow").val());//输入框的名称
	var oldSupplierName = $.trim($("#oldSupplierName").val());//原来的供应商名称
	var newlinkManName = $.trim($("#linkManShow").val());
	var oldlinkManName = $.trim($("#oldlinkManName").val());
	if(oldSupplierName == newSupplierName && newlinkManName == oldlinkManName){//没有改变，不提交，什么都不做
		return false;
	}else{
		supplierNameYan2();
		if(nameShowYanFlag){
			//3、发送请求到后台
			$.messager.confirm('系统提示', '您确定修改供应商信息吗？', function(flag) {
				if(flag){
					$.ajax({
						type: 'post',
						url:'/admin/supplier/editSupplier.htm',
						cache:false ,
						data:{
							supplierId : $("#supplierId").val(),
							supplierName : $("#supplierNameShow").val(),//输入框的名称
							linkMan : $("#linkManShow").val()//输入框的联系人
						},
						dataType:'json',
						success:function(result){
							$.messager.alert('提示',result.msg,'info');
						}
					});
				}else{
					return false;
				}
			});
			nameShowYanFlag = false;//全局变量，初始化nameShowYanFlag
		}else{
			$.messager.alert('提示','请填写正确的信息','info');
		}
	}
}

/*
 * excelImport excel导入yaopin
 * */
function excelImport(){
	$("#importFileName").val("");
	$('#excelImortMerchandise').window('center');
	$('#excelImortMerchandise').window('open');
}

//导入用数据，提交后验证,excel导入 验证
function submitMerchandiseForm(){
	//得到导入的文件名
	var importFileName = $("#importFileName").val();	
	if(0==importFileName.length)
	{
		$.messager.alert('警告', '选择Excel文件!');
		return;
	}else{
		$.messager.confirm('系统提示', '您确定要导入数据吗？', function(flag) {
			if(flag){
				$("#supplierIdExcel").val($("#supplierId").val());//业务员的id
				$("#importMerchandiseForm").form("submit",{
					url : '/admin/supplier/importSupplierMerchandise.htm',
					type : 'post',
					async : false,
					data : { 
					//	'importFileName':importFileName ,
					//	'supplierIdExcel' : $("#supplierId").val()
						},
					dataType : 'json',
					success:function(result){
						var data = parserToJson(result);
				    	if(data.success) {
				    		closeImport();
				    		$.messager.alert('提示',data.msg,'info');
				    	}else {
				    		$.messager.alert('错误',data.msg,'error');
				    	}
				    	$("#merchandiseTable").datagrid("reload");//重新加载供应商拥有的药品
					}
				});
			}else{
				return;
			}
		});
	}
}

//关闭导入按钮
function closeImport(){
	$("#importFileName").val("");
	$("#excelImortMerchandise").window('close');
}


/*
 * 点击维护供应商人员按钮
 * */
function editSupplierSalesMan(){
	var selects = $('#searchSupplierTable').datagrid('getSelections');//获取选择的供应商
	if(selects && selects.length == 1){
		supplierId = selects[0].supplierId;	//选中的供应商ID
		supplierName = selects[0].supplierName;//选中的供应商名称
		linkMan = selects[0].linkMan;			//选中的供应商联系人

		$("#linkManShowTwo").val(linkMan);
		$("#supplierNameShowTwo").val(supplierName);
		$("#supplierId").val(supplierId);
		
		loadSupplierSlaesManTable(supplierId);//加载供应商已经有的人员列表
		$("#editSupplierSalesMan").window('open');
	}else{
		$.messager.alert('提示','请先选择一条记录','info');
	}
}

//加载供应商已经有的人员列表
function loadSupplierSlaesManTable(supplierId){
	$("#supplierSalesManTable").datagrid({
		nowrap : true,
		striped : true,
		fitColumns : true,
		rownumbers: true,
		url : "/admin/salesMan/salesMan/salesManList.json?supplierId="+supplierId,
		method : 'post',
		pageSize : 10,
		pageNumber : 1,
		pagination : true,
		singleSelect : false,
		columns : [ [  
		 		    { title : '业务员ID', field : 'userSupplierId', align : 'center', resizable : true,checkbox:true }, 
		 		    { title : '登录账号', field : 'loginName', align : 'center', resizable : true}, 
		 		    { title : '登录密码', field : 'loginPass', align : 'center', resizable : true}, 
		 		    { title : '联系人', field : 'linkMan', align : 'center', resizable : true}, 
		 		    { title : '联系电话', field : 'linkPhone', align : 'center', resizable : true}, 
		 		    { title : '供应商名称', field : 'supplierName', align : 'center', resizable : true}, 
		 		    { title : '所属组织结构', field : 'structureName', align : 'center',resizable : true},
		 		    { title : '登记人', field : 'register', align : 'center', resizable : true}, 
		 		    { title : '创建时间', field : 'createTimeStr', align : 'center', resizable : true}
		] ]
	});
}


//点击添加人员按钮,弹出人员检索框
function supplierSalesManOpen(){
/*	$('#supplierSalesManWindow').window({  
	    width:800,  
	    height:460,  
	    modal:true,
	    collapsible:false,
	    minimizable:false,
	    resizable:true,
	    maximizable:false,
	    closable:true,
	    closed:true,
	    position : 'fixed',
	    title:'选择人员',
	    shadow : false
	});*/
	
	$('#supplierSalesManSelectTable').datagrid({
		fit : false,
		nowrap : true,
		striped : true,
		fitColumns : false,
		rownumbers: true,
		loadMsg : '数据加载中请稍后……',
		url : '/admin/salesMan/salesMan/salesManList.json',
		method : 'post',
		pageSize : 10,
		pageNumber : 1,
		pagination : true,
		singleSelect : false,
		columns : [ [  
 		    { title : '业务员ID', field : 'userSupplierId', align : 'center', resizable : true,checkbox:true }, 
 		    { title : '登录账号', field : 'loginName', align : 'center', resizable : true}, 
 		    { title : '登录密码', field : 'loginPass', align : 'center', resizable : true}, 
 		    { title : '联系人', field : 'linkMan', align : 'center', resizable : true}, 
 		    { title : '联系电话', field : 'linkPhone', align : 'center', resizable : true}, 
 		    { title : '供应商名称', field : 'supplierName', align : 'center', resizable : true}, 
 		    { title : '所属组织结构', field : 'structureName', align : 'center',resizable : true},
 		    { title : '登记人', field : 'register', align : 'center', resizable : true}, 
 		    { title : '创建时间', field : 'createTimeStr', align : 'center', resizable : true}
 		] ]
		
	});
	$('#supplierSalesManWindow').window('open');
	$('#supplierSalesManWindow').css('display','');
}

//点击搜索人员界面的查询按钮
function supplierSalesManReLoad(){
    $("#supplierSalesManSelectTable").datagrid('load', {
    	keyword : $('#supplierSalesMan_keyword').val(),
	});
}

//点击搜索人员界面的取消按钮
function selectsupplierSalesManCancle(){
	$('#supplierSalesManSelectTable').datagrid("clearSelections");
	$('#supplierSalesManWindow').window('close');
}

//点击搜索人员界面的 确定 按钮
function selectsupplierSalesManOK(){

	//获取勾选的人员ID,供应商ID,发送请求到后台,把这个人员的供应商ID改成对应的
	var selects = $("#supplierSalesManSelectTable").datagrid("getSelections");//搜索界面选中的列
	var salesManIdS = null;
	if(selects != null && selects.length >0){
		$.messager.confirm('系统提示', '您确定添加选中的'+selects.length+'条数据吗?', function(flag) {
			if(flag){
				for(var i=0;i<selects.length;i++){
					if(salesManIdS!=null){
						salesManIdS = salesManIdS + "," + selects[i].userSupplierId ;
					}else{
						salesManIdS = selects[i].userSupplierId ;//选中的药品ID
					}
				}
				$.ajax({
					type: 'post',
					url:'/admin/supplier/updateSupplierSalesMan.htm',
					cache:false ,
					data:{
							salesManIdS:salesManIdS,
							supplierId : $("#supplierId").val(),
							type : "add"
						},
					dataType:'json',
					success:function(result){
						if(result.success){
							$("#supplierSalesManTable").datagrid("reload");//重新加载供应商拥有的人员
							$.messager.alert('提示',result.msg,'info');
						}else{
							$.messager.alert('提示',result.msg,'error');
						}
					}
				});
			}
		});
	}else{
		$.messager.alert('提示','请先选择想要添加的人员');
		return false;
	}
}


//维护供应商人员界面,  删除选择的人员
function deleteSupplierSalesMan(){
	var selects = $('#supplierSalesManTable').datagrid('getSelections');
	var salesManIdS = null;
	if(selects && selects.length > 0){
		$.messager.confirm('系统提示', '您确定删除选中的'+selects.length+'条数据吗?', function(flag) {
			if(flag){
				//获取选中药品ID
				for(var i=0;i<selects.length;i++){
					if(salesManIdS!=null){
						salesManIdS = salesManIdS + "," + selects[i].userSupplierId ;
					}else{
						salesManIdS = selects[i].userSupplierId ;//选中的药品ID
					}
				}
				$.ajax({
					type: 'post',
					url:'/admin/supplier/updateSupplierSalesMan.htm',
					cache:false ,
					data:{
							salesManIdS:salesManIdS,
							supplierId : $("#supplierId").val(),
							type : "delete"
						},
					dataType:'json',
					success:function(result){
						if(result.success){
							$("#supplierSalesManTable").datagrid("reload");//重新加载供应商拥有的人员
							$.messager.alert('提示',result.msg,'info');
						}else{
							$.messager.alert('提示',result.msg,'error');
							return false;
						}
					}
				});
			}
		});
		
	}else{
		$.messager.alert('提示','请先选择想要删除的记录','info');
		return false;
	}
}


//批量指定组织结构 setSupplierStructureTree
function setSalesManStructure(){
	var selects = $('#supplierSalesManTable').datagrid('getSelections');
	if(selects && selects.length > 0){
		//加载这个选中供应商的组织结构
		$("#setSalesManStructure").tree({
			url : '/admin/supplier/getStructureList.json?supplierId='+$("#supplierId").val()
		});
		$("#setSalesManStructureWindow").window('center');
		$("#setSalesManStructureWindow").window('open');
	}else{
		$.messager.alert('提示','请先选择人员','info');
		return false;
	}
}

//确定设置组织结构
function setSalesManStructureOK(){
	//获取业务员ID, 组织结构ID, 提交修改这些业务员的组织结构ID即可
	var selects = $('#supplierSalesManTable').datagrid('getSelections');
	var salesManIdS = null;
	if(selects && selects.length > 0){
		//获取选中的组织结构
		var parent = $('#setSalesManStructure').tree('getSelected');
		if(parent != null){
			$.messager.confirm('系统提示', '您确定保存组织结构的设置吗?', function(flag) {
				if(flag){
					//获取选中药品ID
					for(var i=0;i<selects.length;i++){
						if(salesManIdS!=null){
							salesManIdS = salesManIdS + "," + selects[i].userSupplierId ;
						}else{
							salesManIdS = selects[i].userSupplierId ;//选中的药品ID
						}
					}
					$.ajax({
						type: 'post',
						url:'/admin/supplier/setSalesManStructure.htm',
						cache:false ,
						data:{
								salesManIdS:salesManIdS,
								structureId : parent.id,
								supplierId : $("#supplierId").val(),
							},
						dataType:'json',
						success:function(result){
							if(result.success){
								setSalesManStructureCancel();
								$("#supplierSalesManTable").datagrid("reload");//重新加载供应商拥有的人员
								$.messager.alert('提示',result.msg,'info');
							}else{
								$.messager.alert('提示',result.msg,'error');
								return false;
							}
						}
					});
				}
			});
		}else{
			$.messager.alert('提示','请先指定一个组织结构','error');
			return false;
		}
	}else{
		$.messager.alert('提示','请先选择人员','info');
		return false;
	}
}


//关闭指定组织结构窗口
function setSalesManStructureCancel(){
	$("#setSalesManStructureWindow").window('close');
}


//供应商订单审核设置
function editSupplierExamineOrder(){
	var selects = $('#searchSupplierTable').datagrid('getSelections');//获取选择的供应商
	if(selects && selects.length == 1){
		supplierId = selects[0].supplierId;	//选中的供应商ID
		supplierName = selects[0].supplierName;//选中的供应商名称
		linkMan = selects[0].linkMan;			//选中的供应商联系人

		$("#linkManShowThree").val(linkMan);
		$("#supplierNameShowThree").val(supplierName);
		$("#isOpenExamineOrder").val(selects[0].isOpenExamineOrder);
		$("#supplierId").val(supplierId);
		
		loadsupplierExamineOrderSalesManTable(supplierId);//加载供应商审核订单的人员列表
		$("#editSupplierExamineOrder").window('open');
	}else{
		$.messager.alert('提示','请先选择一条记录','info');
	}

}

//加载这个供应商下面审核订单的人员列表--订单审核
function loadsupplierExamineOrderSalesManTable(supplierId){
	$("#supplierExamineOrderSalesManTable").datagrid({
		nowrap : true,
		striped : true,
		fitColumns : true,
		rownumbers: true,
		url : "/admin/supplier/examineOrderSalesManList.json?supplierId="+supplierId,
		method : 'post',
		pageSize : 10,
		pageNumber : 1,
		pagination : true,
		singleSelect : false,
		columns : [ [  
		 		    { title : '业务员ID', field : 'userSupplierId', align : 'center', resizable : true,checkbox:true }, 
		 		    { title : '登录账号', field : 'loginName', align : 'center', resizable : true}, 
		 		    { title : '登录密码', field : 'loginPass', align : 'center', resizable : true}, 
		 		    { title : '联系人', field : 'linkMan', align : 'center', resizable : true}, 
		 		    { title : '联系电话', field : 'linkPhone', align : 'center', resizable : true}, 
		 		    { title : '供应商名称', field : 'supplierName', align : 'center', resizable : true}, 
		 		    { title : '所属组织结构', field : 'structureName', align : 'center',resizable : true},
		 		    { title : '登记人', field : 'register', align : 'center', resizable : true}, 
		 		    { title : '创建时间', field : 'createTimeStr', align : 'center', resizable : true}
		] ]
	});
}

//打开供应商下面已经存在的业务员 -- 订单审核
function supplierExistsSalesManOpen(){
	var selects = $('#searchSupplierTable').datagrid('getSelections');//获取选择的供应商
	var supplierId = selects[0].supplierId;	//选中的供应商ID
	loadSupplierExistsSlaesManTable(supplierId);//加载供应商已经有的人员列表
	$('#supplierExistsSalesManWindow').window('open');
	$('#supplierExistsSalesManWindow').css('display','');
}

function editSupplierSalesManCancel(){
	$('#editSupplierExamineOrder').window('close');	
}

//加载供应商已经有的人员列表--订单审核,只显示没有被添加到审核列表中的人员
function loadSupplierExistsSlaesManTable(supplierId){
	$("#supplierExistsSalesManTable").datagrid({
		nowrap : true,
		striped : true,
		fitColumns : true,
		rownumbers: true,
		url : "/admin/salesMan/salesMan/salesManList.json?supplierId="+supplierId+'&examineOrder=1',
		method : 'post',
		pageSize : 10,
		pageNumber : 1,
		pagination : true,
		singleSelect : false,
		columns : [ [  
		 		    { title : '业务员ID', field : 'userSupplierId', align : 'center', resizable : true,checkbox:true }, 
		 		    { title : '登录账号', field : 'loginName', align : 'center', resizable : true}, 
		 		    { title : '登录密码', field : 'loginPass', align : 'center', resizable : true}, 
		 		    { title : '联系人', field : 'linkMan', align : 'center', resizable : true}, 
		 		    { title : '联系电话', field : 'linkPhone', align : 'center', resizable : true}, 
		 		    { title : '供应商名称', field : 'supplierName', align : 'center', resizable : true}, 
		 		    { title : '所属组织结构', field : 'structureName', align : 'center',resizable : true},
		 		    { title : '登记人', field : 'register', align : 'center', resizable : true}, 
		 		    { title : '创建时间', field : 'createTimeStr', align : 'center', resizable : true}
		] ]
	});
}

//点击搜索人员界面的查询按钮--供应商订单审核功能
function supplierExistsSalesManReLoad(){
    $("#supplierExistsSalesManTable").datagrid('load', {
    	keyword : $('#supplierExistsSalesMan_keyword').val(),
	});
}

//确定添加订单审核业务员 --订单审核
function addExamineOrderSalesManOK(){
	//获取勾选的人员ID,供应商ID,发送请求到后台,把这个人员的供应商ID改成对应的
	var selects = $("#supplierExistsSalesManTable").datagrid("getSelections");//搜索界面选中的列
	var salesManIdS = null;
	if(selects != null && selects.length >0){
		$.messager.confirm('系统提示', '您确定添加选中的'+selects.length+'条数据吗?', function(flag) {
			if(flag){
				for(var i=0;i<selects.length;i++){
					if(salesManIdS!=null){
						salesManIdS = salesManIdS + "," + selects[i].userSupplierId ;
					}else{
						salesManIdS = selects[i].userSupplierId ;//选中的药品ID
					}
				}
				$.ajax({
					type: 'post',
					url:'/admin/supplier/updateExamineOrderSalesMan.htm?'+Math.random(),
					cache:false ,
					data:{
							salesManIdS:salesManIdS,
							supplierId : $("#supplierId").val(),
							type : "add"
						},
					dataType:'json',
					success:function(result){
						if(result.success){
							$("#supplierExistsSalesManTable").datagrid("reload");
							$("#supplierExamineOrderSalesManTable").datagrid("reload");//重新加载供应商拥有的人员
							$.messager.alert('提示',result.msg,'info');
						}else{
							$.messager.alert('提示',result.msg,'error');
						}
					}
				});
			}
		});
	}else{
		$.messager.alert('提示','请先选择想要添加的人员');
		return false;
	}
}

//关闭 添加审核订单人员的窗口
function addExamineOrderSalesManCancle(){
	$('#supplierExistsSalesManTable').datagrid("clearSelections");
	$('#supplierExistsSalesManWindow').window('close');
}

//删除审核人员
function deleteSupplierExamineOrderSalesMan(){
	var selects = $("#supplierExamineOrderSalesManTable").datagrid("getSelections");//搜索界面选中的列
	var salesManIdS = null;
	if(selects != null && selects.length >0){
		$.messager.confirm('系统提示', '您确定删除选中的'+selects.length+'条数据吗?', function(flag) {
			if(flag){
				for(var i=0;i<selects.length;i++){
					if(salesManIdS!=null){
						salesManIdS = salesManIdS + "," + selects[i].userSupplierId ;
					}else{
						salesManIdS = selects[i].userSupplierId ;//选中的药品ID
					}
				}
				$.ajax({
					type: 'post',
					url:'/admin/supplier/updateExamineOrderSalesMan.htm?'+Math.random(),
					cache:false ,
					data:{
							salesManIdS:salesManIdS,
							supplierId : $("#supplierId").val(),
							type : "delete"
						},
					dataType:'json',
					success:function(result){
						if(result.success){
							$("#supplierExamineOrderSalesManTable").datagrid("reload");//重新加载供应商拥有的审核人员
							$.messager.alert('提示',result.msg,'info');
						}else{
							$.messager.alert('提示',result.msg,'error');
						}
					}
				});
			}
		});
	}else{
		$.messager.alert('提示','请先选择想要删除的人员');
		return false;
	}
}

//确定开启或者关闭订单审核功能,
function commitOpenExamineOrder(){
	var isOpenExamineOrder = $("#isOpenExamineOrder").val();
	if(isOpenExamineOrder == null || isOpenExamineOrder == ''){
		return false;
	}
	if(isOpenExamineOrder == 1){
		//判断是否添加了人员 getRows
		var selects = $("#supplierExamineOrderSalesManTable").datagrid("getRows");
		if(selects == null || selects.length <= 0){
			//不能修改
			$.messager.alert('提示','请先添加人员','info');
			return false;
		}
	}
	//可以修改,把这个业务员开启订单审核
	$.ajax({
		type: 'post',
		url:'/admin/supplier/updateSupplierExamineOrder.htm?'+Math.random(),
		cache:false ,
		data:{
				supplierId : $("#supplierId").val(),
				isOpenExamineOrder:isOpenExamineOrder
			},
		dataType:'json',
		success:function(result){
			if(result.success){
				$("#editSupplierExamineOrder").window('close');
				$('#searchSupplierTable').datagrid('reload');
				
			}
			$.messager.alert('提示',result.msg,'info');
		}
	});
	
}
