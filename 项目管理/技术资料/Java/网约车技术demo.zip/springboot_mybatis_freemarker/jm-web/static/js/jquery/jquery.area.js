/**
 * jQuery : 城市联动插件
 * 
 * @author fusheng
 * @example $("#fs").ProvinceCity();
 * @params 暂无
 */
$.fn.ProvinceCity = function(options) {
	var defaults = {
		firstselectid : 'firstselect',
		secondselectid : 'secondselect'
	};

	var opts = $.extend(defaults, options);
	var _self = this;
	var _self1 = $("#" + opts.firstselectid);
	var _self2 = $("#" + opts.secondselectid);
	_self1.data("province", [ "请选择", "请选择" ]);
	_self2.data("city1", [ "请选择", "请选择" ]);
	// 分别获取3个下拉框
	// var $sel1 = _self1.eq(0);
	// var $sel2 = _self2.eq(0);
	// 默认省级下拉
	if (_self1.data("province")) {
		_self1.append("<option value='" + _self1.data("province")[1] + "'>"
				+ _self1.data("province")[0] + "</option>");
	}
	$.each(GC, function(index, data) {
		if (data[1] == 0) {
			_self1.append("<option value='" + data[0] + "'>" + data[2]
					+ "</option>");
		}
	});
	// 默认的1级城市下拉
	if (_self2.data("city1")) {
		_self2.append("<option value='" + _self2.data("city1")[1] + "'>"
				+ _self2.data("city1")[0] + "</option>");
	}

	if (opts.selectvalone) {
		setTimeout(
				function() { // 解决IE6不兼容问题
					_self1.val(opts.selectval);
					$(
							"#" + opts.firstselectid + " option[value="
									+ opts.selectvalone + "]").attr("selected",
							"true");
					_self1.change();
					if (opts.selectvaltwo) {
						setTimeout(function() { // 解决IE6不兼容问题
												// _self2.val(opts.selectvaltwo);
							$(
									"#" + opts.secondselectid
											+ " option[value="
											+ opts.selectvaltwo + "]").attr(
									"selected", "true");
						}, 0);
					}
				}, 0);
	}

	// 省级联动 控制
	var index1 = "";
	var val1 = "";
	_self1.change(function() {
		// 清空其它2个下拉框
		_self2[0].options.length = 0;
		index1 = this.selectedIndex;
		val1 = _self1.val();// this.options[index1].value;
		if (index1 == 0) { // 当选择的为 “请选择” 时
			if (_self2.data("city1")) {
				_self2.append("<option value='" + _self2.data("city1")[1]
						+ "'>" + _self2.data("city1")[0] + "</option>");
			}
		} else {
			$.each(GG, function(index, data) {
				if (data[1] == val1) {
					_self2.append("<option value='" + data[0] + "'>" + data[2]
							+ "</option>");
				}
			});
		}
	});
	return _self;
};
