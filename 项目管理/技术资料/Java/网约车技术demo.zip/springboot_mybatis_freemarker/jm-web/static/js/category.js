
$(document).ready(function() {
	//appendCateoryLevel(p);
	//getStaticCategoryJSP(p);
});

function appendCateoryLevel(data){
	
	var returnStr='';
    
	
	var newlist ;
	//获取药品一级类别对应的促销信息
	$.ajax({
		type : "GET",
		url : "/categoryNews/listNewsForCategoryLevel1.json",
		async : false,
		success:function(data){
			//newlist = JSON.parse(data);
			newlist = parserToJson(data);
		}
	});
	
	$(data).each(function(k,v){
			var str ='<ul><li><a needcode=true href="'+v.categoryLink+'"><b>'+v.categoryName+'</b></a></li><li class="clearit12" ></li><li>';

			var mi_str='';
			var tr_str='';
			var nl_str='';
			$(v.child).each(function(w,y){
				if(y.categoryName !='其他类用药' && y.categoryName !='循环系统'){
					mi_str +='<a needcode=true href="'+y.categoryLink+'">'+y.categoryName+'</a>';
				}
				
				
				tr_str +='<dd><div class="a_f fl"><a needcode=true href="'+y.categoryLink+'"><b>'+y.categoryName+'</b></a></div><div class="z_f fl">';
				$(y.child).each(function(b,n){
					tr_str +='<em><a needcode=true href="'+n.categoryLink+'">'+n.categoryName+'</a></em>'
				});
				tr_str +='</div><div class="clearit"></div></dd>'
				
			});
			
			//此处进行添加商品类别促销信息
			$(newlist).each(function(j,o) {
				if(o.categoryName == v.categoryName){
					$(o.categoryNews).each(function(r, s ){
						nl_str +='<dd><a title="" href="'+s.newsLink+'">'+s.titles+'</a></dd>';
					});
				}
	        });
			
			//调试
			returnStr += str+mi_str+'</li></ul><div class="dis none u1" ><div class="fl dis_left"><dl>'
						 +tr_str+ '</dl></div><div class="fr dis_right"><div class="you"><div class="biaoti">'
						 +'活动政策</div><div class="pp_box hd_box"><dl>'
						 +nl_str+'</dl></div></div></div></div>';
	});
	
	
	$(".nav_it").append(returnStr);
	$(".nav_it").append('<ul class="categorys_bottom"><li><a href="/indexforallcategory.htm" style="width:150px;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></li></ul>');
}


//此方法备用，用于生成静态的药瓶类别页面，只允许手动调用，勿删
function getStaticCategoryJSP(data){
	var str = '';
	var classforlevel2 = '';
	$(data).each(function(k,v){
		str = '<div class="class_main">';
		
		if(v.categoryName == '西药'){
			str += '<div class="class_tit">  西<br> 药<br> </div>' ; 
			classforlevel2 = '<div class="i-mc">';
		}
		if(v.categoryName == '中药产品'){
			str += '<div class="class_tit1">  中<br> 药<br> 产<br> 品<br> </div>' ; 
			classforlevel2 = '<div class="i-mc3">';
		}
		if(v.categoryName == '医疗器械'){
			str += '<div class="class_tit">  医<br> 疗<br> 器<br> 械<br> </div>' ; 
			classforlevel2 = '<div class="i-mc1">';
		}
		if(v.categoryName == '计生用品'){
			str += '<div class="class_tit1">  计<br> 生<br> 用<br> 品<br> </div>' ; 
			classforlevel2 = '<div class="i-mc4">';
		}
		if(v.categoryName == '非药产品'){
			str += '<div class="class_tit">  非<br> 药<br> 产<br> 品<br> </div>' ; 
			classforlevel2 = '<div class="i-mc2">';
		}
		
		str += '<div class="class_left"> <div class="class_m"> ';
		$(v.child).each(function(w,y){
			str += classforlevel2;  
			str += '<div class="subitem"> <dl class="fore"> ';
			str += '<dt> '+ '<a target="_blank" href="'+y.categoryLink+'"> '+y.categoryName+'</a> </dt>' ;
			str += '<dd>';
			$(y.child).each(function(b,n){
				str += '<em><a target="_blank" href="'+n.categoryLink+'">'+n.categoryName+'</a></em>' ;
			});
			str += '</dd> </dl> </div> </div>';
		});
		str += '</div> </div> </div>';
		//$(".limingshuai").append(str);
	});
	
}



var p=[
{
    "categoryName": "西药",
    "categoryLink": "/search/merchandise.htm?level1_name=西药",
    "child": [
        {
            "categoryName": "解热镇痛",
            "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=解热镇痛&fromLevel2=true",
            "child": [
                {
                    "categoryName": "非成瘾性镇痛药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=解热镇痛&level3_name=非成瘾性镇痛药",
                    "child": null
                },
                {
                    "categoryName": "非甾体抗炎药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=解热镇痛&level3_name=非甾体抗炎药",
                    "child": null
                },
                {
                    "categoryName": "抗偏头痛药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=解热镇痛&level3_name=抗偏头痛药",
                    "child": null
                },
                {
                    "categoryName": "抗痛风药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=解热镇痛&level3_name=抗痛风药",
                    "child": null
                },
                {
                    "categoryName": "解热止痛药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=解热镇痛&level3_name=解热止痛药",
                    "child": null
                },
                {
                    "categoryName": "其它解热镇痛药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=解热镇痛&level3_name=其它解热镇痛药",
                    "child": null
                }
            ]
        },
        {
            "categoryName": "非抗生素",
            "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=非抗生素&fromLevel2=true",
            "child": [
                {
                    "categoryName": "磺胺类药及增效剂",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=非抗生素&level3_name=磺胺类药及增效剂",
                    "child": null
                },
                {
                    "categoryName": "天然来源抗感染药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=非抗生素&level3_name=天然来源抗感染药",
                    "child": null
                },
                {
                    "categoryName": "其它非抗生素类抗感染药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=非抗生素&level3_name=其它非抗生素类抗感染药",
                    "child": null
                },
                {
                    "categoryName": "抗病毒类药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=非抗生素&level3_name=抗病毒类药",
                    "child": null
                },
                {
                    "categoryName": "抗螺旋体类药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=非抗生素&level3_name=抗螺旋体类药",
                    "child": null
                },
                {
                    "categoryName": "硝基呋喃类",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=非抗生素&level3_name=硝基呋喃类",
                    "child": null
                },
                {
                    "categoryName": "喹诺酮类",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=非抗生素&level3_name=喹诺酮类",
                    "child": null
                },
                {
                    "categoryName": "抗真菌类药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=非抗生素&level3_name=抗真菌类药",
                    "child": null
                },
                {
                    "categoryName": "抗结核麻风分枝杆菌类药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=非抗生素&level3_name=抗结核麻风分枝杆菌类药",
                    "child": null
                }
            ]
        },
        {
            "categoryName": "消化系统",
            "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=消化系统&fromLevel2=true",
            "child": [
                {
                    "categoryName": "其它消化系统用药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=消化系统&level3_name=其它消化系统用药",
                    "child": null
                },
                {
                    "categoryName": "止吐催吐药及促胃肠动力药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=消化系统&level3_name=止吐催吐药及促胃肠动力药",
                    "child": null
                },
                {
                    "categoryName": "泻药及止泻药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=消化系统&level3_name=泻药及止泻药",
                    "child": null
                },
                {
                    "categoryName": "食欲抑制药及其它减肥药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=消化系统&level3_name=食欲抑制药及其它减肥药",
                    "child": null
                },
                {
                    "categoryName": "肝胆疾病用药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=消化系统&level3_name=肝胆疾病用药",
                    "child": null
                },
                {
                    "categoryName": "胃肠解痉及肠胃炎药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=消化系统&level3_name=胃肠解痉及肠胃炎药",
                    "child": null
                },
                {
                    "categoryName": "抗酸药及治疗消化性溃疡药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=消化系统&level3_name=抗酸药及治疗消化性溃疡药",
                    "child": null
                },
                {
                    "categoryName": "助消化药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=消化系统&level3_name=助消化药",
                    "child": null
                }
            ]
        },
        {
            "categoryName": "维生素及微量元素缺乏用药",
            "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=维生素及微量元素缺乏用药&fromLevel2=true",
            "child": [
                {
                    "categoryName": "复合维生素类",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=维生素及微量元素缺乏用药&level3_name=复合维生素类",
                    "child": null
                },
                {
                    "categoryName": "维生素Ｃ属及其它属药物",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=维生素及微量元素缺乏用药&level3_name=维生素Ｃ属及其它属药物",
                    "child": null
                },
                {
                    "categoryName": "滋补营养药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=维生素及微量元素缺乏用药&level3_name=滋补营养药",
                    "child": null
                },
                {
                    "categoryName": "其它营养用药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=维生素及微量元素缺乏用药&level3_name=其它营养用药",
                    "child": null
                },
                {
                    "categoryName": "微量元素与矿物质",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=维生素及微量元素缺乏用药&level3_name=微量元素与矿物质",
                    "child": null
                },
                {
                    "categoryName": "维生素Ｂ属药物",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=维生素及微量元素缺乏用药&level3_name=维生素Ｂ属药物",
                    "child": null
                },
                {
                    "categoryName": "维生素Ａ、Ｄ属药物",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=维生素及微量元素缺乏用药&level3_name=维生素Ａ、Ｄ属药物",
                    "child": null
                }
            ]
        },
        {
            "categoryName": "血液系统",
            "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=血液系统&fromLevel2=true",
            "child": [
                {
                    "categoryName": "抗贫血药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=血液系统&level3_name=抗贫血药",
                    "child": null
                },
                {
                    "categoryName": "促凝血药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=血液系统&level3_name=促凝血药",
                    "child": null
                },
                {
                    "categoryName": "其它血液系统用药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=血液系统&level3_name=其它血液系统用药",
                    "child": null
                },
                {
                    "categoryName": "血浆及血容量扩充剂",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=血液系统&level3_name=血浆及血容量扩充剂",
                    "child": null
                },
                {
                    "categoryName": "抗凝血及溶栓药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=血液系统&level3_name=抗凝血及溶栓药",
                    "child": null
                },
                {
                    "categoryName": "促白细胞增生药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=血液系统&level3_name=促白细胞增生药",
                    "child": null
                },
                {
                    "categoryName": "促血小板增生药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=血液系统&level3_name=促血小板增生药",
                    "child": null
                }
            ]
        },
        {
            "categoryName": "抗寄生虫",
            "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=抗寄生虫&fromLevel2=true",
            "child": [
                {
                    "categoryName": "抗吸虫病药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=抗寄生虫&level3_name=抗吸虫病药",
                    "child": null
                },
                {
                    "categoryName": "抗疟药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=抗寄生虫&level3_name=抗疟药",
                    "child": null
                },
                {
                    "categoryName": "抗阿米巴及抗滴虫病药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=抗寄生虫&level3_name=抗阿米巴及抗滴虫病药",
                    "child": null
                },
                {
                    "categoryName": "其它抗寄生虫病药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=抗寄生虫&level3_name=其它抗寄生虫病药",
                    "child": null
                },
                {
                    "categoryName": "驱肠虫药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=抗寄生虫&level3_name=驱肠虫药",
                    "child": null
                },
                {
                    "categoryName": "抗丝虫病及抗黑热病药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=抗寄生虫&level3_name=抗丝虫病及抗黑热病药",
                    "child": null
                }
            ]
        },
        {
            "categoryName": "呼吸系统",
            "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=呼吸系统&fromLevel2=true",
            "child": [
                {
                    "categoryName": "其他呼吸系统用药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=呼吸系统&level3_name=其他呼吸系统用药",
                    "child": null
                },
                {
                    "categoryName": "平喘药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=呼吸系统&level3_name=平喘药",
                    "child": null
                },
                {
                    "categoryName": "镇咳药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=呼吸系统&level3_name=镇咳药",
                    "child": null
                },
                {
                    "categoryName": "祛痰药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=呼吸系统&level3_name=祛痰药",
                    "child": null
                }
            ]
        },
        {
            "categoryName": "泌尿系统",
            "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=泌尿系统&fromLevel2=true",
            "child": [
                {
                    "categoryName": "其它泌尿系统用药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=泌尿系统&level3_name=其它泌尿系统用药",
                    "child": null
                },
                {
                    "categoryName": "尿崩症用药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=泌尿系统&level3_name=尿崩症用药",
                    "child": null
                },
                {
                    "categoryName": "利尿药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=泌尿系统&level3_name=利尿药",
                    "child": null
                },
                {
                    "categoryName": "脱水药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=泌尿系统&level3_name=脱水药",
                    "child": null
                }
            ]
        },
        {
            "categoryName": "抗肿瘤药",
            "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=抗肿瘤药&fromLevel2=true",
            "child": [
                {
                    "categoryName": "抗肿瘤药物",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=抗肿瘤药&level3_name=抗肿瘤药物",
                    "child": null
                }
            ]
        },
        {
            "categoryName": "神经系统用药",
            "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=神经系统用药&fromLevel2=true",
            "child": [
                {
                    "categoryName": "其它神经系统用药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=神经系统用药&level3_name=其它神经系统用药",
                    "child": null
                },
                {
                    "categoryName": "脑代谢调节药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=神经系统用药&level3_name=脑代谢调节药",
                    "child": null
                },
                {
                    "categoryName": "作用于植物神经系统用药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=神经系统用药&level3_name=作用于植物神经系统用药",
                    "child": null
                },
                {
                    "categoryName": "抗震颤麻痹药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=神经系统用药&level3_name=抗震颤麻痹药",
                    "child": null
                },
                {
                    "categoryName": "镇静催眠药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=神经系统用药&level3_name=镇静催眠药",
                    "child": null
                },
                {
                    "categoryName": "中枢兴奋药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=神经系统用药&level3_name=中枢兴奋药",
                    "child": null
                },
                {
                    "categoryName": "抗癫痫及抗惊厥药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=神经系统用药&level3_name=抗癫痫及抗惊厥药",
                    "child": null
                },
                {
                    "categoryName": "抗焦虑药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=神经系统用药&level3_name=抗焦虑药",
                    "child": null
                },
                {
                    "categoryName": "抗抑郁躁狂药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=神经系统用药&level3_name=抗抑郁躁狂药",
                    "child": null
                },
                {
                    "categoryName": "抗精神病药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=神经系统用药&level3_name=抗精神病药",
                    "child": null
                }
            ]
        },
        {
            "categoryName": "抗生素",
            "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=抗生素&fromLevel2=true",
            "child": [
                {
                    "categoryName": "其他-内酰胺酶类",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=抗生素&level3_name=其他-内酰胺酶类",
                    "child": null
                },
                {
                    "categoryName": "头孢菌素类",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=抗生素&level3_name=头孢菌素类",
                    "child": null
                },
                {
                    "categoryName": "氨基糖醇类",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=抗生素&level3_name=氨基糖醇类",
                    "child": null
                },
                {
                    "categoryName": "大环内酯类",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=抗生素&level3_name=大环内酯类",
                    "child": null
                },
                {
                    "categoryName": "林可胺类",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=抗生素&level3_name=林可胺类",
                    "child": null
                },
                {
                    "categoryName": "酰胺醇类",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=抗生素&level3_name=酰胺醇类",
                    "child": null
                },
                {
                    "categoryName": "其他抗生素类",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=抗生素&level3_name=其他抗生素类",
                    "child": null
                },
                {
                    "categoryName": "多烯类",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=抗生素&level3_name=多烯类",
                    "child": null
                },
                {
                    "categoryName": "利福霉素类",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=抗生素&level3_name=利福霉素类",
                    "child": null
                },
                {
                    "categoryName": "四环素类",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=抗生素&level3_name=四环素类",
                    "child": null
                },
                {
                    "categoryName": "多肽类",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=抗生素&level3_name=多肽类",
                    "child": null
                },
                {
                    "categoryName": "青霉素类",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=抗生素&level3_name=青霉素类",
                    "child": null
                }
            ]
        },
        {
            "categoryName": "循环系统",
            "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=循环系统&fromLevel2=true",
            "child": [
                {
                    "categoryName": "周围血管扩张药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=循环系统&level3_name=周围血管扩张药",
                    "child": null
                },
                {
                    "categoryName": "防治心绞痛药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=循环系统&level3_name=防治心绞痛药",
                    "child": null
                },
                {
                    "categoryName": "抗心律失常药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=循环系统&level3_name=抗心律失常药",
                    "child": null
                },
                {
                    "categoryName": "强心药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=循环系统&level3_name=强心药",
                    "child": null
                },
                {
                    "categoryName": "其它循环系统用药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=循环系统&level3_name=其它循环系统用药",
                    "child": null
                },
                {
                    "categoryName": "调节血脂及抗动脉粥样硬化药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=循环系统&level3_name=调节血脂及抗动脉粥样硬化药",
                    "child": null
                },
                {
                    "categoryName": "抗休克血管活性药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=循环系统&level3_name=抗休克血管活性药",
                    "child": null
                },
                {
                    "categoryName": "抗高血压病药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=循环系统&level3_name=抗高血压病药",
                    "child": null
                }
            ]
        },
        {
            "categoryName": "其他类用药",
            "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=其他类用药&fromLevel2=true",
            "child": [
                {
                    "categoryName": "其它调节免疫功能药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=其他类用药&level3_name=其它调节免疫功能药",
                    "child": null
                },
                {
                    "categoryName": "免疫抑制剂",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=其他类用药&level3_name=免疫抑制剂",
                    "child": null
                },
                {
                    "categoryName": "生物反应调节剂",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=其他类用药&level3_name=生物反应调节剂",
                    "child": null
                },
                {
                    "categoryName": "血液制品",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=其他类用药&level3_name=血液制品",
                    "child": null
                },
                {
                    "categoryName": "细胞因子",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=其他类用药&level3_name=细胞因子",
                    "child": null
                },
                {
                    "categoryName": "菌苗",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=其他类用药&level3_name=菌苗",
                    "child": null
                },
                {
                    "categoryName": "抗毒素、抗血清",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=其他类用药&level3_name=抗毒素、抗血清",
                    "child": null
                },
                {
                    "categoryName": "诊断用生物制品",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=其他类用药&level3_name=诊断用生物制品",
                    "child": null
                },
                {
                    "categoryName": "类毒素",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=其他类用药&level3_name=类毒素",
                    "child": null
                },
                {
                    "categoryName": "其他生物制品",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=其他类用药&level3_name=其他生物制品",
                    "child": null
                },
                {
                    "categoryName": "疫苗",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=其他类用药&level3_name=疫苗",
                    "child": null
                },
                {
                    "categoryName": "过敏反应介质阻滞剂",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=其他类用药&level3_name=过敏反应介质阻滞剂",
                    "child": null
                },
                {
                    "categoryName": "抗组织胺药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=其他类用药&level3_name=抗组织胺药",
                    "child": null
                },
                {
                    "categoryName": "其它抗变态反应药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=其他类用药&level3_name=其它抗变态反应药",
                    "child": null
                },
                {
                    "categoryName": "A葡萄糖类药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=其他类用药&level3_name=A葡萄糖类药",
                    "child": null
                },
                {
                    "categoryName": "B电解质平衡调节药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=其他类用药&level3_name=B电解质平衡调节药",
                    "child": null
                },
                {
                    "categoryName": "C酸碱平衡调节药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=其他类用药&level3_name=C酸碱平衡调节药",
                    "child": null
                },
                {
                    "categoryName": "其它睡、电解质及酸碱平衡调节药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=其他类用药&level3_name=其它睡、电解质及酸碱平衡调节药",
                    "child": null
                },
                {
                    "categoryName": "其它麻醉用药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=其他类用药&level3_name=其它麻醉用药",
                    "child": null
                },
                {
                    "categoryName": "局部麻醉药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=其他类用药&level3_name=局部麻醉药",
                    "child": null
                },
                {
                    "categoryName": "麻醉辅助药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=其他类用药&level3_name=麻醉辅助药",
                    "child": null
                },
                {
                    "categoryName": "全身麻醉药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=其他类用药&level3_name=全身麻醉药",
                    "child": null
                },
                {
                    "categoryName": "器官功能检查剂",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=其他类用药&level3_name=器官功能检查剂",
                    "child": null
                },
                {
                    "categoryName": "其它诊断用药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=其他类用药&level3_name=其它诊断用药",
                    "child": null
                },
                {
                    "categoryName": "X线造影剂",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=其他类用药&level3_name=X线造影剂",
                    "child": null
                },
                {
                    "categoryName": "氨基酸及蛋白质类药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=其他类用药&level3_name=氨基酸及蛋白质类药",
                    "child": null
                },
                {
                    "categoryName": "酶及辅酶类药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=其他类用药&level3_name=酶及辅酶类药",
                    "child": null
                },
                {
                    "categoryName": "核酸类药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=其他类用药&level3_name=核酸类药",
                    "child": null
                },
                {
                    "categoryName": "多糖及脂类药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=其他类用药&level3_name=多糖及脂类药",
                    "child": null
                },
                {
                    "categoryName": "其它生化药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=其他类用药&level3_name=其它生化药",
                    "child": null
                },
                {
                    "categoryName": "前列腺素类药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=其他类用药&level3_name=前列腺素类药",
                    "child": null
                },
                {
                    "categoryName": "甲状腺激素及抗甲状腺药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=其他类用药&level3_name=甲状腺激素及抗甲状腺药",
                    "child": null
                },
                {
                    "categoryName": "其它激素及调节内分泌功能类药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=其他类用药&level3_name=其它激素及调节内分泌功能类药",
                    "child": null
                },
                {
                    "categoryName": "性激素及促性激素类药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=其他类用药&level3_name=性激素及促性激素类药",
                    "child": null
                },
                {
                    "categoryName": "肾上腺皮质激素类药及促肾上腺皮质激素类药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=其他类用药&level3_name=肾上腺皮质激素类药及促肾上腺皮质激素类药",
                    "child": null
                },
                {
                    "categoryName": "胰腺激素及其它调节血糖药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=其他类用药&level3_name=胰腺激素及其它调节血糖药",
                    "child": null
                },
                {
                    "categoryName": "计生用药",
                    "categoryLink": "/search/merchandise.htm?level1_name=西药&level2_name=其他类用药&level3_name=计生用药",
                    "child": null
                }
            ]
        }
        
    ]
},

{
    "categoryName": "中药产品",
    "categoryLink": "/search/merchandise.htm?level1_name=中药产品",
    "child": [
        {
            "categoryName": "中成药",
            "categoryLink": "/search/merchandise.htm?level1_name=中药产品&level2_name=中成药&fromLevel2=true",
            "child": [
                {
                    "categoryName": "皮肤科用药",
                    "categoryLink": "/search/merchandise.htm?level1_name=中药产品&level2_name=中成药&level3_name=皮肤科用药",
                    "child": null
                },
                {
                    "categoryName": "杀虫剂",
                    "categoryLink": "/search/merchandise.htm?level1_name=中药产品&level2_name=中成药&level3_name=杀虫剂",
                    "child": null
                },
                {
                    "categoryName": "治痰剂",
                    "categoryLink": "/search/merchandise.htm?level1_name=中药产品&level2_name=中成药&level3_name=治痰剂",
                    "child": null
                },
                {
                    "categoryName": "治燥剂",
                    "categoryLink": "/search/merchandise.htm?level1_name=中药产品&level2_name=中成药&level3_name=治燥剂",
                    "child": null
                },
                {
                    "categoryName": "治风剂",
                    "categoryLink": "/search/merchandise.htm?level1_name=中药产品&level2_name=中成药&level3_name=治风剂",
                    "child": null
                },
                {
                    "categoryName": "祛湿药",
                    "categoryLink": "/search/merchandise.htm?level1_name=中药产品&level2_name=中成药&level3_name=祛湿药",
                    "child": null
                },
                {
                    "categoryName": "消导化积药",
                    "categoryLink": "/search/merchandise.htm?level1_name=中药产品&level2_name=中成药&level3_name=消导化积药",
                    "child": null
                },
                {
                    "categoryName": "化痰止咳平喘药",
                    "categoryLink": "/search/merchandise.htm?level1_name=中药产品&level2_name=中成药&level3_name=化痰止咳平喘药",
                    "child": null
                },
                {
                    "categoryName": "外用药",
                    "categoryLink": "/search/merchandise.htm?level1_name=中药产品&level2_name=中成药&level3_name=外用药",
                    "child": null
                },
                {
                    "categoryName": "和解及表里双解药",
                    "categoryLink": "/search/merchandise.htm?level1_name=中药产品&level2_name=中成药&level3_name=和解及表里双解药",
                    "child": null
                },
                {
                    "categoryName": "清热药",
                    "categoryLink": "/search/merchandise.htm?level1_name=中药产品&level2_name=中成药&level3_name=清热药",
                    "child": null
                },
                {
                    "categoryName": "解表药",
                    "categoryLink": "/search/merchandise.htm?level1_name=中药产品&level2_name=中成药&level3_name=解表药",
                    "child": null
                },
                {
                    "categoryName": "泻下药",
                    "categoryLink": "/search/merchandise.htm?level1_name=中药产品&level2_name=中成药&level3_name=泻下药",
                    "child": null
                },
                {
                    "categoryName": "理气药",
                    "categoryLink": "/search/merchandise.htm?level1_name=中药产品&level2_name=中成药&level3_name=理气药",
                    "child": null
                },
                {
                    "categoryName": "理血药",
                    "categoryLink": "/search/merchandise.htm?level1_name=中药产品&level2_name=中成药&level3_name=理血药",
                    "child": null
                },
                {
                    "categoryName": "开窍药",
                    "categoryLink": "/search/merchandise.htm?level1_name=中药产品&level2_name=中成药&level3_name=开窍药",
                    "child": null
                },
                {
                    "categoryName": "收敛固涩药",
                    "categoryLink": "/search/merchandise.htm?level1_name=中药产品&level2_name=中成药&level3_name=收敛固涩药",
                    "child": null
                },
                {
                    "categoryName": "补益药",
                    "categoryLink": "/search/merchandise.htm?level1_name=中药产品&level2_name=中成药&level3_name=补益药",
                    "child": null
                },
                {
                    "categoryName": "安神药",
                    "categoryLink": "/search/merchandise.htm?level1_name=中药产品&level2_name=中成药&level3_name=安神药",
                    "child": null
                },
                {
                    "categoryName": "祛暑湿药",
                    "categoryLink": "/search/merchandise.htm?level1_name=中药产品&level2_name=中成药&level3_name=祛暑湿药",
                    "child": null
                },
                {
                    "categoryName": "温里药",
                    "categoryLink": "/search/merchandise.htm?level1_name=中药产品&level2_name=中成药&level3_name=温里药",
                    "child": null
                }
            ]
        },
        {
            "categoryName": "中药饮片",
            "categoryLink": "/search/merchandise.htm?level1_name=中药产品&level2_name=中药饮片&fromLevel2=true",
            "child": [
                {
                    "categoryName": "其他类",
                    "categoryLink": "/search/merchandise.htm?level1_name=中药产品&level2_name=中药饮片&level3_name=其他类",
                    "child": null
                },
                {
                    "categoryName": "贵细类",
                    "categoryLink": "/search/merchandise.htm?level1_name=中药产品&level2_name=中药饮片&level3_name=贵细类",
                    "child": null
                },
                {
                    "categoryName": "动物类",
                    "categoryLink": "/search/merchandise.htm?level1_name=中药产品&level2_name=中药饮片&level3_name=动物类",
                    "child": null
                },
                {
                    "categoryName": "矿物类",
                    "categoryLink": "/search/merchandise.htm?level1_name=中药产品&level2_name=中药饮片&level3_name=矿物类",
                    "child": null
                },
                {
                    "categoryName": "其他类",
                    "categoryLink": "/search/merchandise.htm?level1_name=中药产品&level2_name=中药饮片&level3_name=其他类",
                    "child": null
                },
                {
                    "categoryName": "保健品",
                    "categoryLink": "/search/merchandise.htm?level1_name=中药产品&level2_name=中药饮片&level3_name=保健品",
                    "child": null
                },
                {
                    "categoryName": "成方药",
                    "categoryLink": "/search/merchandise.htm?level1_name=中药产品&level2_name=中药饮片&level3_name=成方药",
                    "child": null
                },
                {
                    "categoryName": "用品类（包装、器械、设备器械）",
                    "categoryLink": "/search/merchandise.htm?level1_name=中药产品&level2_name=中药饮片&level3_name=用品类（包装、器械、设备器械）",
                    "child": null
                },
                {
                    "categoryName": "叶类",
                    "categoryLink": "/search/merchandise.htm?level1_name=中药产品&level2_name=中药饮片&level3_name=叶类",
                    "child": null
                },
                {
                    "categoryName": "炮制辅料类",
                    "categoryLink": "/search/merchandise.htm?level1_name=中药产品&level2_name=中药饮片&level3_name=炮制辅料类",
                    "child": null
                },
                {
                    "categoryName": "毒性中药材、中药饮片",
                    "categoryLink": "/search/merchandise.htm?level1_name=中药产品&level2_name=中药饮片&level3_name=毒性中药材、中药饮片",
                    "child": null
                },
                {
                    "categoryName": "果实类",
                    "categoryLink": "/search/merchandise.htm?level1_name=中药产品&level2_name=中药饮片&level3_name=果实类",
                    "child": null
                },
                {
                    "categoryName": "全草类",
                    "categoryLink": "/search/merchandise.htm?level1_name=中药产品&level2_name=中药饮片&level3_name=全草类",
                    "child": null
                },
                {
                    "categoryName": "根茎类",
                    "categoryLink": "/search/merchandise.htm?level1_name=中药产品&level2_name=中药饮片&level3_name=根茎类",
                    "child": null
                },
                {
                    "categoryName": "藤木树脂类",
                    "categoryLink": "/search/merchandise.htm?level1_name=中药产品&level2_name=中药饮片&level3_name=藤木树脂类",
                    "child": null
                },
                {
                    "categoryName": "菌藻类",
                    "categoryLink": "/search/merchandise.htm?level1_name=中药产品&level2_name=中药饮片&level3_name=菌藻类",
                    "child": null
                },
                {
                    "categoryName": "花类",
                    "categoryLink": "/search/merchandise.htm?level1_name=中药产品&level2_name=中药饮片&level3_name=花类",
                    "child": null
                },
                {
                    "categoryName": "树皮类",
                    "categoryLink": "/search/merchandise.htm?level1_name=中药产品&level2_name=中药饮片&level3_name=树皮类",
                    "child": null
                }
            ]
        }
    ]
},

{
    "categoryName": "医疗器械",
    "categoryLink": "/search/merchandise.htm?level1_name=医疗器械",
    "child": [
        {
            "categoryName": "进口医用器械",
            "categoryLink": "/search/merchandise.htm?level1_name=医疗器械&level2_name=进口医用器械&fromLevel2=true",
            "child": [
                {
                    "categoryName": "手术器械",
                    "categoryLink": "/search/merchandise.htm?level1_name=医疗器械&level2_name=进口医用器械&level3_name=手术器械",
                    "child": null
                },
                {
                    "categoryName": "软件",
                    "categoryLink": "/search/merchandise.htm?level1_name=医疗器械&level2_name=进口医用器械&level3_name=软件",
                    "child": null
                },
                {
                    "categoryName": "医用材料",
                    "categoryLink": "/search/merchandise.htm?level1_name=医疗器械&level2_name=进口医用器械&level3_name=医用材料",
                    "child": null
                },
                {
                    "categoryName": "一次性无菌器械",
                    "categoryLink": "/search/merchandise.htm?level1_name=医疗器械&level2_name=进口医用器械&level3_name=一次性无菌器械",
                    "child": null
                },
                {
                    "categoryName": "医用设备",
                    "categoryLink": "/search/merchandise.htm?level1_name=医疗器械&level2_name=进口医用器械&level3_name=医用设备",
                    "child": null
                },
                {
                    "categoryName": "普通诊察器械",
                    "categoryLink": "/search/merchandise.htm?level1_name=医疗器械&level2_name=进口医用器械&level3_name=普通诊察器械",
                    "child": null
                },
                {
                    "categoryName": "临床检验器械",
                    "categoryLink": "/search/merchandise.htm?level1_name=医疗器械&level2_name=进口医用器械&level3_name=临床检验器械",
                    "child": null
                },
                {
                    "categoryName": "放射设备及用品",
                    "categoryLink": "/search/merchandise.htm?level1_name=医疗器械&level2_name=进口医用器械&level3_name=放射设备及用品",
                    "child": null
                }
            ]
        },
        {
            "categoryName": "医疗设备",
            "categoryLink": "/search/merchandise.htm?level1_name=医疗器械&level2_name=医疗设备&fromLevel2=true",
            "child": [
                {
                    "categoryName": "体外诊断试剂",
                    "categoryLink": "/search/merchandise.htm?level1_name=医疗器械&level2_name=医疗设备&level3_name=体外诊断试剂",
                    "child": null
                },
                {
                    "categoryName": "临床检验分析仪器",
                    "categoryLink": "/search/merchandise.htm?level1_name=医疗器械&level2_name=医疗设备&level3_name=临床检验分析仪器",
                    "child": null
                },
                {
                    "categoryName": "医用化验和基础设备器具",
                    "categoryLink": "/search/merchandise.htm?level1_name=医疗器械&level2_name=医疗设备&level3_name=医用化验和基础设备器具",
                    "child": null
                },
                {
                    "categoryName": "医用高能射线设备",
                    "categoryLink": "/search/merchandise.htm?level1_name=医疗器械&level2_name=医疗设备&level3_name=医用高能射线设备",
                    "child": null
                },
                {
                    "categoryName": "医用核素设备",
                    "categoryLink": "/search/merchandise.htm?level1_name=医疗器械&level2_name=医疗设备&level3_name=医用核素设备",
                    "child": null
                },
                {
                    "categoryName": "医用射线防护用品、装置",
                    "categoryLink": "/search/merchandise.htm?level1_name=医疗器械&level2_name=医疗设备&level3_name=医用射线防护用品、装置",
                    "child": null
                },
                {
                    "categoryName": "医用磁共振设备",
                    "categoryLink": "/search/merchandise.htm?level1_name=医疗器械&level2_name=医疗设备&level3_name=医用磁共振设备",
                    "child": null
                },
                {
                    "categoryName": "医用X射线设备",
                    "categoryLink": "/search/merchandise.htm?level1_name=医疗器械&level2_name=医疗设备&level3_name=医用X射线设备",
                    "child": null
                },
                {
                    "categoryName": "医用X射线附属设备及部件",
                    "categoryLink": "/search/merchandise.htm?level1_name=医疗器械&level2_name=医疗设备&level3_name=医用X射线附属设备及部件",
                    "child": null
                },
                {
                    "categoryName": "中医器械",
                    "categoryLink": "/search/merchandise.htm?level1_name=医疗器械&level2_name=医疗设备&level3_name=中医器械",
                    "child": null
                }
            ]
        },
        {
            "categoryName": "注射输液",
            "categoryLink": "/search/merchandise.htm?level1_name=医疗器械&level2_name=注射输液&fromLevel2=true",
            "child": [
                {
                    "categoryName": "一次性注射用品",
                    "categoryLink": "/search/merchandise.htm?level1_name=医疗器械&level2_name=注射输液&level3_name=一次性注射用品",
                    "child": null
                }
            ]
        },
        {
            "categoryName": "医疗辅助用品",
            "categoryLink": "/search/merchandise.htm?level1_name=医疗器械&level2_name=医疗辅助用品&fromLevel2=true",
            "child": [
                {
                    "categoryName": "介入器材",
                    "categoryLink": "/search/merchandise.htm?level1_name=医疗器械&level2_name=医疗辅助用品&level3_name=介入器材",
                    "child": null
                },
                {
                    "categoryName": "医用高分子材料及制品（避孕器械、一次性无菌器械除外）",
                    "categoryLink": "/search/merchandise.htm?level1_name=医疗器械&level2_name=医疗辅助用品&level3_name=医用高分子材料及制品（避孕器械、一次性无菌器械除外）",
                    "child": null
                },
                {
                    "categoryName": "口腔科材料",
                    "categoryLink": "/search/merchandise.htm?level1_name=医疗器械&level2_name=医疗辅助用品&level3_name=口腔科材料",
                    "child": null
                },
                {
                    "categoryName": "植入材料和人工器官",
                    "categoryLink": "/search/merchandise.htm?level1_name=医疗器械&level2_name=医疗辅助用品&level3_name=植入材料和人工器官",
                    "child": null
                },
                {
                    "categoryName": "医用缝合材料及粘合剂",
                    "categoryLink": "/search/merchandise.htm?level1_name=医疗器械&level2_name=医疗辅助用品&level3_name=医用缝合材料及粘合剂",
                    "child": null
                },
                {
                    "categoryName": "医用卫生材料及敷料",
                    "categoryLink": "/search/merchandise.htm?level1_name=医疗器械&level2_name=医疗辅助用品&level3_name=医用卫生材料及敷料",
                    "child": null
                }
            ]
        },
        {
            "categoryName": "家用器械",
            "categoryLink": "/search/merchandise.htm?level1_name=医疗器械&level2_name=家用器械&fromLevel2=true",
            "child": [
                {
                    "categoryName": "化学试剂及器皿",
                    "categoryLink": "/search/merchandise.htm?level1_name=医疗器械&level2_name=家用器械&level3_name=化学试剂及器皿",
                    "child": null
                },
                {
                    "categoryName": "仿真性辅助器具",
                    "categoryLink": "/search/merchandise.htm?level1_name=医疗器械&level2_name=家用器械&level3_name=仿真性辅助器具",
                    "child": null
                },
                {
                    "categoryName": "医疗用品",
                    "categoryLink": "/search/merchandise.htm?level1_name=医疗器械&level2_name=家用器械&level3_name=医疗用品",
                    "child": null
                },
                {
                    "categoryName": "保健用品",
                    "categoryLink": "/search/merchandise.htm?level1_name=医疗器械&level2_name=家用器械&level3_name=保健用品",
                    "child": null
                },
                {
                    "categoryName": "家庭日用品",
                    "categoryLink": "/search/merchandise.htm?level1_name=医疗器械&level2_name=家用器械&level3_name=家庭日用品",
                    "child": null
                }
            ]
        },
        {
            "categoryName": "其他用品 ",
            "categoryLink": "/search/merchandise.htm?level1_name=医疗器械&level2_name=其他用品 &fromLevel2=true",
            "child": [
                {
                    "categoryName": "其他",
                    "categoryLink": "/search/merchandise.htm?level1_name=医疗器械&level2_name=其他用品 &level3_name=其他",
                    "child": null
                },
                {
                    "categoryName": "国产体外诊断试剂",
                    "categoryLink": "/search/merchandise.htm?level1_name=医疗器械&level2_name=其他用品 &level3_name=国产体外诊断试剂",
                    "child": null
                },
                {
                    "categoryName": "进口体外诊断试剂",
                    "categoryLink": "/search/merchandise.htm?level1_name=医疗器械&level2_name=其他用品 &level3_name=进口体外诊断试剂",
                    "child": null
                }
            ]
        }
    ]
},

{
    "categoryName": "计生用品",
    "categoryLink": "/search/merchandise.htm?level1_name=计生用品",
    "child": [
        {
            "categoryName": "计生试剂",
            "categoryLink": "/search/merchandise.htm?level1_name=计生用品&level2_name=计生试剂&fromLevel2=true",
            "child": [
                {
                    "categoryName": "其他3类",
                    "categoryLink": "/search/merchandise.htm?level1_name=计生用品&level2_name=计生试剂&level3_name=其他3类",
                    "child": null
                },
                {
                    "categoryName": "计生试纸",
                    "categoryLink": "/search/merchandise.htm?level1_name=计生用品&level2_name=计生试剂&level3_name=计生试纸",
                    "child": null
                },
                {
                    "categoryName": "计生试剂",
                    "categoryLink": "/search/merchandise.htm?level1_name=计生用品&level2_name=计生试剂&level3_name=计生试剂",
                    "child": null
                }
            ]
        },
        {
            "categoryName": "计生器械",
            "categoryLink": "/search/merchandise.htm?level1_name=计生用品&level2_name=计生器械&fromLevel2=true",
            "child": [
                {
                    "categoryName": "计生器械2类",
                    "categoryLink": "/search/merchandise.htm?level1_name=计生用品&level2_name=计生器械&level3_name=计生器械2类",
                    "child": null
                },
                {
                    "categoryName": "计生器具",
                    "categoryLink": "/search/merchandise.htm?level1_name=计生用品&level2_name=计生器械&level3_name=计生器具",
                    "child": null
                }
            ]
        },
        {
            "categoryName": "进口计生用品",
            "categoryLink": "/search/merchandise.htm?level1_name=计生用品&level2_name=进口计生用品&fromLevel2=true",
            "child": [
                {
                    "categoryName": "计生试剂3类",
                    "categoryLink": "/search/merchandise.htm?level1_name=计生用品&level2_name=进口计生用品&level3_name=计生试剂3类",
                    "child": null
                },
                {
                    "categoryName": "计生药品",
                    "categoryLink": "/search/merchandise.htm?level1_name=计生用品&level2_name=进口计生用品&level3_name=计生药品",
                    "child": null
                },
                {
                    "categoryName": "计生器械",
                    "categoryLink": "/search/merchandise.htm?level1_name=计生用品&level2_name=进口计生用品&level3_name=计生器械",
                    "child": null
                }
            ]
        }
    ]
},
{
    "categoryName": "非药产品",
    "categoryLink": "/search/merchandise.htm?level1_name=非药产品",
    "child": [
        {
            "categoryName": "生活用品",
            "categoryLink": "/search/merchandise.htm?level1_name=非药产品&level2_name=生活用品&fromLevel2=true",
            "child": [
                {
                    "categoryName": "进口生活用品",
                    "categoryLink": "/search/merchandise.htm?level1_name=非药产品&level2_name=生活用品&level3_name=进口生活用品",
                    "child": null
                },
                {
                    "categoryName": "国产生活用品",
                    "categoryLink": "/search/merchandise.htm?level1_name=非药产品&level2_name=生活用品&level3_name=国产生活用品",
                    "child": null
                }
            ]
        },
        {
            "categoryName": "食品",
            "categoryLink": "/search/merchandise.htm?level1_name=非药产品&level2_name=食品&fromLevel2=true",
            "child": [
                {
                    "categoryName": "国产食品",
                    "categoryLink": "/search/merchandise.htm?level1_name=非药产品&level2_name=食品&level3_name=国产食品",
                    "child": null
                },
                {
                    "categoryName": "进口食品",
                    "categoryLink": "/search/merchandise.htm?level1_name=非药产品&level2_name=食品&level3_name=进口食品",
                    "child": null
                },
                {
                    "categoryName": "国产保健品",
                    "categoryLink": "/search/merchandise.htm?level1_name=非药产品&level2_name=食品&level3_name=国产保健品",
                    "child": null
                },
                {
                    "categoryName": "进口保健品",
                    "categoryLink": "/search/merchandise.htm?level1_name=非药产品&level2_name=食品&level3_name=进口保健品",
                    "child": null
                }
            ]
        },
        {
            "categoryName": "消毒用品",
            "categoryLink": "/search/merchandise.htm?level1_name=非药产品&level2_name=消毒用品&fromLevel2=true",
            "child": [
                {
                    "categoryName": "国产消毒用品",
                    "categoryLink": "/search/merchandise.htm?level1_name=非药产品&level2_name=消毒用品&level3_name=国产消毒用品",
                    "child": null
                },
                {
                    "categoryName": "进口消毒用品",
                    "categoryLink": "/search/merchandise.htm?level1_name=非药产品&level2_name=消毒用品&level3_name=进口消毒用品",
                    "child": null
                }
            ]
        },
        {
            "categoryName": "化妆品",
            "categoryLink": "/search/merchandise.htm?level1_name=非药产品&level2_name=化妆品&fromLevel2=true",
            "child": [
                {
                    "categoryName": "国产化妆品",
                    "categoryLink": "/search/merchandise.htm?level1_name=非药产品&level2_name=化妆品&level3_name=国产化妆品",
                    "child": null
                },
                {
                    "categoryName": "进口化妆品",
                    "categoryLink": "/search/merchandise.htm?level1_name=非药产品&level2_name=化妆品&level3_name=进口化妆品",
                    "child": null
                }
            ]
        }
    ]
}

];
