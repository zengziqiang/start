
var isFromUpdate=false;

//添加药品div层确定选中药品信息
$(document).ready(function() {
	initAmountOrCount();
	
	//merchandiseInit 药品查询的初始化，参数是一个回调方法
	merchandiseInit(function(data){
		//data是被选择的药品的对象集合,对象方式访问
		
		var originalMerchandises = $('#merchandiselist').datagrid('getRows');  
		$.each(data, function(i, row){
			var isExist = false;
			if(originalMerchandises != null && originalMerchandises.length >0 ){
				//避免将药品数据重复加入显示
				for(var i=0;i<originalMerchandises.length;i++){
					var merchandise_id = originalMerchandises[i].merchandise_id;
					if(row.merchandise_id == merchandise_id){
						isExist = true;
						break;
					}
				}
			}
			
			if(!isExist){
				$("#merchandiselist").datagrid("insertRow", {
					index : 0,
					row :row
				});
			}
			
		});
	});
	
	
	$("#jyjm").combobox({
		onUnselect: function(){
			showMerchandiseListModelForJyjm();
		}
	});
	$("#jyjm").combobox({
		onSelect: function(){
			showMerchandiseListModelForJyjm();
		}
	});
});
 
$(function(){
	$("#purchaselisttable").datagrid({
		fit : true,
		width:'auto',
		striped: true,
		fitColumns:false,
		toolbar:"#toolbar",
		url:'/admin/purchase/listpurchase.htm',
		pagination:true,
		singleSelect:false,
		rownumbers:true,
		pageSize:10,
		idField:'purchaseId',
		frozenColumns:[[
		    	        {field:'id',checkbox:true}
		           ]],
		    		columns:[[ 
		    			{field:'purchaseId',title:'',hidden:true},
		    			{field:'purchaseName',title:'策略名称',width:100},
		    			{field:'areaStr',title:'客户区域',width:200},
		    			{field:'custTypeStr',title:'客户类型',width:200},
		    			{field:'custStr',title:'补充客户',width:200},
		    			{field:'monthAmount',title:'每月限量',width:80},
		    			{field:'monthCount',title:'每月限次',width:80},
		    			
		    			{field:'dayAmount',title:'每日限量',width:80},
		    			{field:'dayCount',title:'每日限次',width:80},
		    			{field:'orderAmount',title:'每笔订单限量',width:80},
		    			{field:'merchandisType',title:'药品限购类型',width:100,
		    				formatter:function(value, row, index){
		    					if(row.merchandisType==1){
		    						return "部分药品";
		    					}else if(row.merchandisType==2){
		    						return "经营简码";
		    					}
		    				}
		    			},
		    			{field:'modifyDateStr',title:'最后更新时间',width:150}
		    		]]
	});
	loadArea();
	loadArea(null,"custAreaSe");
	loadCustType();
	loadCustType(null,"custTypeSe");
	loadCustMain(false);
	loadJyjm();
	showMerchandiseListModel(null);
 });
 
 


//添加药品限购信息
function addMerchandisePurchase(){
	
	isFromUpdate =false;
	clearTheValueAfterSubmit();
	
	//显示药品列表页面
	loadArea();
	loadCustType();
	loadCustMain();
	loadJyjm();
	$("#editpage").window("open");
	showMerchandiseListModel(null);
	$('#merchandiselist').datagrid('loadData', { total: 0, rows: [] });
}


function updateMerchandisePurchase(){
	isFromUpdate = true;
	var purchaserows = $('#purchaselisttable').datagrid('getSelections');
	if (purchaserows.length == 0 || purchaserows.length > 1) {
		$.messager.alert('警告', '请选择一条限购药品信息');
		return;
	}
	loadJyjm(purchaserows[0].purchaseId, updateMerchandisePurchase2());
}

//修改药品限购信息
function updateMerchandisePurchase2(){
	isFromUpdate = true;
	
	var purchaserows = $('#purchaselisttable').datagrid('getSelections');
	loadArea(purchaserows[0].purchaseId);
 	loadCustType(purchaserows[0].purchaseId);
 	var custMainStr = getCustMainInfoByPurchaseId(purchaserows[0].purchaseId);
 	$('#purchaseId').val(purchaserows[0].purchaseId);
 	
 	$('#custNumberId').val(custMainStr[0]);
	$('#custNumber').val(custMainStr[1]);
	
	$("#monthAmount").val(purchaserows[0].monthAmount);
	$("#monthCount").val(purchaserows[0].monthCount);
	$("#dayAmount").val(purchaserows[0].dayAmount);
	$("#dayCount").val(purchaserows[0].dayCount);
	$("#orderAmount").val(purchaserows[0].orderAmount);
	$("#purchaseName").val(purchaserows[0].purchaseName);
	
	
	
	var purchaseType = purchaserows[0].merchandisType;
	if(purchaseType != undefined && purchaseType ==1){
		$("#merchandisType1").attr("checked","checked");
		$("#operateMerchandise").attr("style","");
		$("#chooseJyjm").attr("style","display:none;");
		
		$("#merchandiselist").datagrid('clearSelections');
		$('#merchandiselist').datagrid('loadData', { total: 0, rows: [] });
		showMerchandiseListModel("/search/pick_merchandise.htm?merchandisePurchaseId="+purchaserows[0].purchaseId);
	}else if(purchaseType != undefined && purchaseType ==2){
		$("#merchandisType2").attr("checked","checked");
		$("#operateMerchandise").attr("style","display:none;");
		$("#chooseJyjm").attr("style","");
		
		$("#merchandiselist").datagrid('clearSelections');
		$('#merchandiselist').datagrid('loadData', { total: 0, rows: [] });
		showMerchandiseListModelForJyjm("/search/pick_merchandise.htm");
	}
	
	
	
	
	$("#editpage").window("open");
 	//$("#addbutton").linkbutton('disable'); 
	
	
	
}




//根据限购id获得客户的基本信息
function getCustMainInfoByPurchaseId(purchaseId){
	var url = "/admin/purchase/" + purchaseId + "/?" + Math.random();
 	var data = $.ajax({
 		url : url,
 		async : false
 	}).responseText;
 	var custMainData = (new Function("return " + data))();
 	var strCustName="";
 	var strCustId="";
 	$.each(custMainData, function(i, row){
 		strCustName+=row.custName+",";
 		strCustId+=row.custId+",";
 	});
 	var reg=/,$/gi;
 	strCustName=strCustName.replace(reg,"");
 	
 	var str=[strCustId,strCustName];
 	return str;
}

//提交编辑串货信息
function submitMerchandisePurchase(){
	
	    if($("#custtype").combotree('getValues')==""&&$("#custNumberId").val()==""&&$("#areatree").combotree('getValues')==""){
	    	$.messager.alert('警告', '客户区域、客户类型，补充客户，至少填写一种客户类型！');
	    	return;
	    }
	    var monthAmount = $("#monthAmount").val();
	    var monthCount =  $("#monthCount").val();
	    var dayAmount = $("#dayAmount").val();
	    var dayCount = $("#dayCount").val();
	    var orderAmount = $("#orderAmount").val();
	    if((monthAmount ==undefined || monthAmount =="" ) && (monthCount ==undefined || monthCount =="" )  && (dayAmount ==undefined || dayAmount =="" )
	    		&& (dayCount ==undefined || dayCount =="" ) && (orderAmount ==undefined || orderAmount =="" )){
	    	$.messager.alert('警告', '请至少填写一项购买限制！');
	    	return;
	    }
	    if((monthAmount =="0" || monthAmount =="") &&  (monthCount =="0" || monthCount == "")  && (dayAmount =="0" || dayAmount == "") 
	    		&& (dayCount ==""  || dayCount == "0") && (orderAmount =="" || orderAmount == "0")){
	    	$.messager.alert('警告', '购买限制条件不能全部为零！');
	    	return;
	    }
	    
	    var purchaseName = $("#purchaseName").val();
	    if(purchaseName  == undefined || purchaseName ==""){
	    	$.messager.alert('警告', '请输入策略名称');
	    	return;
	    }
	    
	    //判断限购药品类型
	   
	    
	    var purchaseType = $(":radio[name=merchandisType][checked]").val();
	    if(purchaseType ==1 ){
	    	var rows = $('#merchandiselist').datagrid('getSelections');  
		    if (rows == null || rows.length == 0) {
				$.messager.alert('警告', '请选择一个药品');
				return;
		    } else{
		    	var merchandiseids=[];
		   	    for(var i=0; i<rows.length; i++){  
		            var row = rows[i];  
		            merchandiseids.push(row.merchandise_id);
		        } 
		   	    $("#merchanids").val(merchandiseids);
		    }
	    }else if(purchaseType ==2){
	    	var jyjmValues = $("#jyjm").combobox('getValues');
	    	if(jyjmValues == undefined || jyjmValues ==""){
	    		$.messager.alert('警告', '请选择经营简码类型');
	    		return;
	    	}
	    	$("#jyjmValues").val(jyjmValues);
	    	
	    }else{
	    	return;
	    }
	    
	    
		if($("#editform").form("validate")){
		    $('#editform').form('submit',{
		       url:"/admin/purchase/save.htm",
		       onSubmit:function(){
		    	   $("#custTypeId").val($("#custtype").combotree('getValues'));
		    	   $("#areaIds").val($("#areatree").combotree('getValues'));
		       },
		       success:function(data){  
		    	   var text = parserToJson(data);
		    	   if(text.success) {
					   	$("#purchaselisttable").datagrid('reload');
					   	if(!isFromUpdate){
					   		$.messager.alert('提示',"限购药品添加成功",'info');
					   		clearTheValueAfterSubmit();
					   	}else{
					   		$.messager.alert('提示',"限购药品修改成功",'info');
					   	}
			    	   
			    	   	
			    	}
			    	else {
			    		$.messager.alert('发生错误',text.msg,'error');
			    	}
		    	} 

		   });
		}
 }


//取消提交药品限购请求
function cancleMerchandisePurchase(){
	clearTheValueAfterSubmit();
	$("#editpage").window("close");
	
}


//清楚提交页面后的数据
function clearTheValueAfterSubmit(){
	$("#purchaseId").val('');
	
	$("#custTypeId").val('');
	$("#custtype").combobox('setValues','');
	
	$("#areaIds").val('');
	$('#areatree').combotree('setValues','');
	
	$("#custNumberId").val('');
	$("#custNumber").val('');
	
	$("#monthAmount").val('');
	$("#monthCount").val('');
	$("#dayAmount").val('');
	$("#dayCount").val('');
	$("#orderAmount").val('');
	
	$("#purchaseName").val('');
	
	$("#merchanids").val('');
	$("#merchandisType1").attr('checked','checked');
	$("#merchandisType1").attr('checked','');
	$("#jyjm").combobox("setValues","");
	$("#chooseJyjm").attr('style','display:none;');
	$("#jyjmValues").val('');
	
	$("#operateMerchandise").attr('style','');
	
	$("#merchandiselist").datagrid('clearSelections');
	showMerchandiseListModel(null);
	$("#merchandiselist").datagrid('loadData', { total: 0, rows: [] });
}

//添加药品限购信息页面 显示药品列表  默认来自部分药品
function showMerchandiseListModel(url){
	 //$('#merchandiselist').datagrid('loadData', { total: 0, rows: [] });
	
	 $("#merchandiselist").datagrid({
			striped: true,
			fitColumns:true,
			method:'get',
			url:url,
			pagination:true,
			singleSelect:false,
			rownumbers:true,
			idField:'merchandise_id',
			frozenColumns:[[
			    	        {field:'id',checkbox:true}
			           ]],
			    		columns:[[ 
								{field:'merchandise_id',title:'',hidden:true},
								{field:'orgmerchandise_code',title:'药品编码',width:100},
								{field:'merchandise_name',title:'药品名称',width:100},
								{field:'merchandise_spec',title:'品名/规格',width:100},
								{field:'middling_packing',title:'中包装数量',width:60},
								{field:'manufacturer',title:'厂家',width:100},
								{field:'merchandise_unit',title:'单位',width:40}	
			    		]]
		});
}

//添加药品限购信息页面 显示药品列表  默认来自经营简码药品
function showMerchandiseListModelForJyjm(url){
	 $('#merchandiselist').datagrid('loadData', { total: 0, rows: [] }); 
	
	
	 var jyjmValues = $("#jyjm").combobox('getValues');
	 if(url == undefined || url ==null){
		 if(jyjmValues != undefined && jyjmValues.length > 0){
			 url="/search/pick_merchandise.htm?jyjm="+jyjmValues;
		 }
	 }else{
		 if(jyjmValues != undefined && jyjmValues.length > 0){
			 url = url+"?jyjm="+jyjmValues;
		 }
	 }
	
	 if(url != undefined && url != null && url !=""){
	 $("#merchandiselist").datagrid({
			striped: true,
			fitColumns:true,
			url:url,
			pagination:true,
			singleSelect:false,
			rownumbers:true,
			idField:'merchandise_id',
			frozenColumns:[[
			    	        {field:'id',checkbox:false}
			           ]],
						 columns:[[ 
									{field:'orgmerchandise_code',title:'药品编码',width:100},
									{field:'merchandise_name',title:'药品名称',width:100},
									{field:'merchandise_spec',title:'品名/规格',width:100},
									{field:'middling_packing',title:'中包装',width:60},
									{field:'manufacturer',title:'厂家',width:100},
									{field:'merchandise_unit',title:'单位',width:40}	
							]]
	 
		});
	 }
	 
	 $("#merchandiselist").datagrid('hideColumn','id');
}
 
function lms(){
	var jyjmValues = $("#jyjm").combobox('getValues');
	 var url=null;
	 if(jyjmValues != undefined && jyjmValues.length > 0){
		 url="/search/pick_merchandise.htm?jyjm="+jyjmValues;
	 }
	 
	 $.messager.alert('提示',jyjmValues);
}
 
//自动加载区域信息
function loadArea(purchaseId,targetId){
	 var areurl;
	 if(!isFromUpdate){
		 //areurl = '/basic/get_all_area.json';
		 areurl = '/basic/cust_areanew.json?level=2';
	 }else{
		 areurl = '/admin/purchase/'+purchaseId+'/get_all_area.json';
	 }
	 if(targetId == undefined || targetId == null){
		 targetId = "areatree";
	 }
	 $('#'+targetId).combotree({  
		    url:areurl ,  
		    multiple:true,
		    onLoadSuccess: function (row, data) {
		    	    $('#areatree').combotree('tree').tree("collapseAll"); 
		    }  
		  }); 
}



//自动加载客户单位类型
function loadCustType(purchaseId,targetId){
	 var areurl;
	 if(!isFromUpdate){
		 areurl = '/basic/get_cust_type.json';
	 }else{
		 areurl = '/admin/purchase/'+purchaseId+'/get_cust_type.json';
	 }
	 if(targetId == undefined || targetId == null){
		 targetId = "custtype";
	 }
	 $('#'+targetId).combobox({  
		    url:areurl ,  
		    multiple:true,
		    valueField:'id',  
			textField:'text'
	}); 
}


//自动加载客户单位类型
function loadJyjm(purchaseId,updatePurchase){
	 var areurl;
	 if(!isFromUpdate){
		 areurl ='/admin/purchase/getjyjm.json';
	 }else{
		 areurl = '/admin/purchase/'+purchaseId+'/getjyjm.json';
	 }
	 $('#jyjm').combobox({  
		    url:areurl ,  
		    multiple:true,
		    valueField:'id',  
			textField:'text',
			onLoadSuccess:function(){
				if(isFromUpdate){
					updateMerchandisePurchase2();
				}
			}
	}); 
}




 
//清空限制客户单位
function clearCustNumber(){
    $("#custNumber").val('');	 
    $("#custNumberId").val('');
}

//切换限购药品的类型，比如针对部分药品或是经营简码药品
function exchangeTheType(purchaseType){
	if(purchaseType == 1){
		//部分药品
		$("#chooseJyjm").attr("style","display:none;");
		$("#operateMerchandise").attr("style","");
		
		$("#jyjm").combobox("setValues","");
		
		
		//showMerchandiseListModel("/search/pick_merchandise.htm?keyword=amxl");
		showMerchandiseListModel(null);
		$('#merchandiselist').datagrid('loadData', { total: 0, rows: [] });
		
	}else if(purchaseType == 2){
		//经营简码药品
		$("#chooseJyjm").attr("style","");
		$("#operateMerchandise").attr("style","display:none;");
		
		$('#merchandiselist').datagrid('loadData', { total: 0, rows: [] });
		showMerchandiseListModelForJyjm();
		
	}
}
 
//删除限购药品信息
function deleteMerchandisePurchase(merchandisePurchaseIds){
	var rows = $('#purchaselisttable').datagrid('getSelections');
	if (rows == null || rows.length == 0) {
		$.messager.alert('警告', '请选择至少一条限购信息');
		return;
	}
	var purchaseids="";
	for ( var i = 0; i < rows.length; i++) {
		purchaseids = purchaseids+rows[i].purchaseId+",";
	}
	
	$.messager.confirm('删除限购信息', '你确定要删除 所选的限购信息?',
			function(ok) {
				if (ok) {
					var url = "/admin/purchase/" + purchaseids	
							+ "/delete.htm";
					$.ajax({
						url : url,
						async : false,
						type : 'post',
						data : {
							'_method' : 'put'
						},
						dataType : 'json',
						success : function(data) {
							if (data.success) {
								
								if (!(rows == null || rows.length == 0)) {
									$('#purchaselisttable').datagrid('clearSelections');		
								}
								
								$.messager.alert('警告',data.msg);
								$('#purchaselisttable').datagrid("reload");
							} else {
								$.messager.alert('警告', data.msg);
							}

						}
					});
				}
			});
}


//删除被选中的药品
function deleteTheMerchandiseList(){
	var rows = $('#merchandiselist').datagrid('getSelections');
	if (rows == null || rows.length == 0) {
		$.messager.alert('警告', '请选择至少一条药品信息');
		return;
	}
	var lenght = rows.length;
	for(var i=0;i<lenght;i++){
		var rowsTemp = $('#merchandiselist').datagrid('getSelections');
		var index =  $('#merchandiselist').datagrid('getRowIndex',rowsTemp[0]);
		$('#merchandiselist').datagrid('deleteRow',index);
	}
}

//清空选中的药品
function clearTheMerchandiseList(){
	var rows = $('#merchandiselist').datagrid('clearSelections');
	$('#merchandiselist').datagrid('loadData',{total:0,rows:[]});
}

//查看限购药品逻辑说明
function operationExplanOpen(){
	 $("#operationExplainDiv").window("open");
}

//excel导入药品信息
function excelMerchandiseOpen(){
	 $("#import").window("open");
}

function importMerchandise(){
	var url = "/admin/merchandise/import.json?"+Math.random();;
	$("#importForm").form("submit",{
		url:url,
	    success:function(text){  
	    	var data = parserToJson(text);
	    	if(data.success == undefined) {
	    		$('#import').window('close');
	    		importMerchandiseSelected(data);
	    		$.messager.alert('提示','导入成功','info');
	    	}
	    	else {
	    		$.messager.alert('发生错误',data.msg,'error');
	    	}
	    }
	});
}
function importMerchandiseSelected(data){
	
	var originalMerchandises = $('#merchandiselist').datagrid('getRows');
	$.each(data, function(i, row){
		var isExist = false;
		if(originalMerchandises != null && originalMerchandises.length >0 ){
			//避免将药品数据重复加入显示
			for(var i=0;i<originalMerchandises.length;i++){
				var merchandise_id = originalMerchandises[i].merchandise_id;
				if(row.merchandiseId == merchandise_id){
					isExist = true;
					break;
				}
			}
		}
		if(!isExist){
			var rowTemp = {
					   merchandise_id:row.merchandiseId,	
					   orgmerchandise_code:row.orgmerchandiseCode,
					   merchandise_name:row.merchandiseName,
					   merchandise_spec:row.merchandiseSpec,
					   packing_number:row.currencyName,
					   manufacturer:row.manufacturer,
					   merchandise_unit:row.merchandiseUnit
					   
					  };
			$('#merchandiselist').datagrid('appendRow',  rowTemp);
		}
	});
} 
function closeImport(){
	$('#import').window("close");
} 


function searchMerchandise(){
	var name= $("#purchaseNameSe").val();
	
	var area= $("#custAreaSe").combotree('getValues');  
	var custType= $("#custTypeSe").combotree('getValues') ; 
	var custMain= $("#custMainSe").val();
	
	
	var org= $("#orgMerchandiseCodeSe").val();
	var merchandiseName= $("#merchandiseNameSe").val();
	
	var manu= $("#manufacturerSe").val();
	var begindate= $("#beginDateSe").datebox('getValue');
	var enddate= $("#endDateSe").datebox('getValue');
	
	$('#purchaselisttable').datagrid('options').queryParams={
        "purchaseName":name,
        "area":area+"",
        "custType":custType+"",
        "custMain":custMain,
        "orgmerchandiseCode":org,
        
        "merchandiseName":merchandiseName,
        "manufacturer":manu,
        
        "begindate":begindate,
        "enddate":enddate
        
        
      };
	$('#purchaselisttable').datagrid('clearChecked'); 
	$("#purchaselisttable").datagrid('reload');
	
}





//客户单位excel导入成功调用此方法
function importCustSelected(data){
	var ss = []; 
	var sss=[];
	$.each(data, function(i, row){
		var exists = false;
		ss.push(row.custName);
	    sss.push(row.custId);
	});

	$("#custNumberId").val(sss);
	$("#custNumber").val(ss);
} 




function initAmountOrCount() {
	// 添加、减少数量
	$("input.amountOrCount")
			.live(
					'keydown',
					function(e) {
						var keyCode = e.keyCode ? e.keyCode : e.which ? e.which
								: e.charCode;
						if (keyCode == 13) {
							return true;
						}
						sk = e.shiftKey ? e.shiftKey : ((keyCode == 16) ? true
								: false);
						if (sk)
							return false;
					
					}).live('focus', function(event) {

				//$(this).val('');

			}).live('blur', function(event) {
//				this.value=this.value.replace(/\D/g,'');
//
//				$(this).val(Math.round(this.value));
//				if ($(this).val() < 0)
//					$(this).val(0);
//				if ($(this).val() > 99999)
//					$(this).val(99999);
			}).live('keyup', function() {
				this.value=this.value.replace(/\D/g,'');

				if ($(this).val() > 99999)
					$(this).val(99999);
			});

	

}
