
$(document).ready(function() {
	
	$('.tabus_box div a img,.left_img a img').hover(function(){
		$(this).css('opacity',0.7);	
	},function(){
		$(this).css('opacity',1);	
	});
	$('.all_product_imglist:odd').addClass('h');
	$('.product_imglist,.all_product_imglist').hover(function(){
		$(this).addClass('o');
		},function(){
		$(this).removeClass('o');
			
	});
	$('li.morevalue').hide();
	$('div.prop-item_title').each(function(){
		
		var th=$(this).height();
		var nh=$(this).next('div').height();
		if(th<nh){
			$(this).height(nh);
		}else{
		$(this).next('div').height(th);
			
		};
	});
	$('li.morevalue ul li:first-child').css('clear','both');
	$('.item_box_r p a').live('click',function(){
		var demo_a=$(this).parent('p').parent('div').prev('.item_box_l').children('ul').children('li.morevalue');
		if(demo_a.children('ul').children('li').length!=0)
			if(demo_a.css('display')=='none'){
				demo_a.css('display','inline');
				$(this).parents('.prop-item_box').css('height','auto');
				$('div.prop-item_title').each(function(){
					var th=$(this).height();
					var nh=$(this).next('div').height();
				if(th<nh){
					$(this).height(nh);
				}else{
					$(this).next('div').height(th);
				};
			});
				$(this).parent('p').html('<span class="posl"></span><a href="javascript:void(0);">收起</a>');
				}else{
				demo_a.css('display','none');
				$('div.prop-item_title').each(function(){
						var th=$(this).height();
						var nh=$(this).next('div').height();
					if(th<nh){
					$(this).height(nh);
					}else{
						$(this).next('div').height(th);
			
					};
				});
				$(this).parent('p').html('<span></span><a href="javascript:void(0);">更多</a>');
				
			};
		
	});
	$('.all_title p a').mousemove(function(e){
		
		var newtop=(e.pageY+12)+'px';	
		var newleft=(e.pageX+12)+'px';
		$('.all_product_div').css('left',newleft).css('top',newtop).fadeIn('fast');
	});
	$('.all_title p a,.all_title p,.all_title').mouseout(function(){
		$('.all_product_div').hide();
	});
	$('.product_main_title_all,.product_title,.all_product_left,.bottom').mouseover(function(){
		$('.all_product_div').hide();
		
		
	});
	$('.product_gl:eq(2),.product_gl:eq(3),.product_gl:eq(6),.product_gl:eq(7)').css('background-color','#F5F5F5');
	
	
	$('#zyaoone').click(function(){
		$('.item_box_l span a').removeClass('nowon');
		$(this).addClass('nowon');
		$('#yaof').show();
		$('#yaos').hide();
		$('div.prop-item_title').each(function(){
				$(this).next('.prop-item_box').css('height','auto');
				var th=$(this).height();
				var nh=$(this).next('div').height();
				if(th<nh){
			
					$(this).height(nh);
				}else{
					$(this).next('div').height(th);
			
				};
		});		
		$('.prop-item_select p a').remove();
		$('.prop_select').css('display','none');
		
	})
	$('#zyaotwo').click(function(){
		$('.item_box_l span a').removeClass('nowon');
		$(this).addClass('nowon');
		$('#yaof').hide();
		$('#yaos').show();
		
		$('.prop-item_select p a').remove();
		$('.prop_select').css('display','none');
		
		$('div.prop-item_title').each(function(){
					$(this).next('.prop-item_box').css('height','auto');
					var th=$(this).height();
					var nh=$(this).next('.prop-item_box').height();
					
				
			if(th<nh){
				
				$(this).height(nh);
			}else{
			
				$(this).next('div').height(th);
			};
		
		});
		
		
	})
	
	$('.prop-item_box .item_box_l ul li a').click(function(){
	var nowk='true';
	var child_zhi=$(this).html();
	var parent_zhi=$(this).parents('.prop-item').children('.prop-item_title').children('p').children('a').html();
	
		if($('.prop_select').css('display')=='block'){
			$('.prop-item_select p a em small').each(function(){
				var ni=$(this).html();
				if(ni==parent_zhi){
				$(this).parent('em').children('span').html(child_zhi);
					nowk='false';
				}
				
			});
			if(nowk=='true'){$('.prop-item_select p').append('<a href="#"><em><small>'+parent_zhi+'</small>：<span>'+child_zhi+'</span></em></a>')};
			
			
		};
		if($('.prop_select').css('display')=='none'){
			$('.prop_select').fadeIn("qucik");;
			$('.prop-item_select p').append('<a href="#"><em><small>'+parent_zhi+'</small>：<span>'+child_zhi+'</span></em></a>');
		};
	
	
	});
	$('.prop-item_select p a').live('click',function(){
		$(this).remove();
		if($('.prop-item_select p a').length==0){$('.prop_select').css('display','none')}
		
		});
	
	//小输入框
	if ($('.s_tt').val()==''){
			$('span.s_label_tip').animate({opacity: 1},120);
		}else{
			$('span.s_label_tip').animate({opacity: 0},100,function(){$(this).css('visibility','hidden');});
		}

	
	$('.s_tt').focus(function(){
		if ($(this).val()==''){
			$('span.s_label_tip').animate({opacity: 0.3},120);
		}else{
			$('span.s_label_tip').animate({opacity: 0},100,function(){$(this).css('visibility','hidden')		  	;});
		}
		}).blur(function(){
			var hidev=function(){$('.suggest').hide();}
			
			var kl=setTimeout(hidev,200);
		
			if ($(this).val()==''){
				$('span.s_label_tip').css('visibility','visible').animate({opacity: 1},120);
			}else{
				$('span.s_label_tip').animate({opacity: 0},100,function(){$(this).css('visibility','hidden')			        ;});
		}
		}).keydown(function(){
		$(this).siblings('span.s_label_tip').animate({opacity: 0},100,function(){$(this).css('visibility		','hidden');});
	
	});
		$('span.s_label_tip').click(function(){$('.s_tt').focus();});
	
});		  

$(document).ready(function(){
  $(".prop_btn_zk").toggle(function(){
   $(this).val("收起");
  $(".Classified1").show();
   },function(){   
  
  $(this).val("展开");
  $(".Classified1").hide();
});
});

