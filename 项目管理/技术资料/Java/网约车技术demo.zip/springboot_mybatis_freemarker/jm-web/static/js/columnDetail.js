﻿var picIndex = 5;
$(document).ready(function(){
	//pageInit(getColumnInfo,20);
	init();
	initTitle(2);
});

function setFenleiId(fenleiId,obj){
	$('#fenlei').val(fenleiId);
	var columnId = $('#columnId').val();
	var fenleiId = $('#fenlei').val();
	var level1Name = $('#jztSupportLevel1Name').val();
	var name =$(obj).html();
	window.location.href="/front/info/columnInfo/columnDetail.htm?columnId="+columnId+"&fenleiId="+fenleiId+"&level1Name="+level1Name+"&name="+encodeURI(name);
//	pageInit(getColumnInfo,20);
}

function setLevel1Code(level1Name,obj){
	$('#jztSupportLevel1Name').val(level1Name);
	var columnId = $('#columnId').val();
	var fenleiId = $('#fenlei').val();
	var level1Name = $('#jztSupportLevel1Name').val();
	var name =$(obj).html();
	window.location.href="/front/info/columnInfo/columnDetail.htm?columnId="+columnId+"&fenleiId"+fenleiId+"&level1Name="+level1Name+"&name="+encodeURI(name);
	//pageInit(getColumnInfo,20);
}


//加载首页栏目信息
function getColumnInfo(pageNum,pageSize){
	var columnId = $('#columnId').val();
	var fenleiId = $('#fenlei').val();
	var level1Name = $('#jztSupportLevel1Name').val();
	var data = getcolumnInfoByColumnId(columnId,pageNum,pageSize,fenleiId,level1Name);
	$('#tr_tit').nextAll().remove()
	$.each(data.list,function(i,row){
		innerHtmlColumnInfo(i,row);
	});
	return data.pagination;
}


//得到栏目下的药品信息
function getcolumnInfoByColumnId(columnId,pageNum,pageSize,fenleiId,level1Name){
	var url = '/front/info/columnInfo/selectColumnInfoByColumnId.json';
	var columnList;
	$.ajax({   
		type : "get",   
		url : url,   
		data:{columnId:columnId,page:pageNum,size:pageSize,chuffl:fenleiId,level1Name:level1Name},
		async : false,   
		success : function(data){   
			columnList = parserToJson(data);
		}   
	}); 
	return columnList;
}

//库存值格式化
function formatStorageNumber(number){
	if(number == null){
		return 0;
	}else if(number>100){
		return '>100';
	}else {
		return number;
	}
}

//将栏目明细数据加入到区域4的栏目
function innerHtmlColumnInfo(index,column){
	var columnInfoHtml=
		'<div class="product_imglist">'+
		'<div class="blank10 clearit"></div>'+
		'<div class="imgbox"><a target="blank" href="/front/merchandise/detail.htm?id='+column.merchandiseId+'"><img onerror="this.src=\'/static/images/nophoto.png\'" src="'+merchandiseImagePath+substrVal2(column.orgMerchandiseCode,11)+'/'+substrVal2(column.orgMerchandiseCode,11)+'.JPG" width="90" height="90" /></a></div>'+
		'<div class="fontbox"><p><a target="blank" href="/front/merchandise/detail.htm?id='+column.merchandiseId+'">'+column.currencyName+'</a></p><p>'+column.passfileNumber+'</p><p >药品编码：'+column.orgMerchandiseCode+'</p></div>'+
		'<div class="s_num">'+column.middlingPacking+'</div>';
		 if(isCustLogin){
       	  columnInfoHtml=columnInfoHtml+
       	  	'<div class="pricehnum">'+column.formatMermberPrice+'</div>';
         }else {
        	 columnInfoHtml=columnInfoHtml+
        	  	'<div class="pricehnum">--</div>';
		}
		 columnInfoHtml=columnInfoHtml+
		'<div class="pricelnum">'+column.formatRetailPrice+'</div>'+
		'<div class="k_num">'+(column.storage!=null?formatStorage(column.storage.storageNumber,column.merchandiseId):formatStorage(0,column.merchandiseId))+'</div>'+
		'<div class="now_num"><a href="javascript:void(0);" class="minus"><img src="/static/images/minus.gif"></a>';
		 if(column.isDecimal){
			columnInfoHtml=columnInfoHtml+
			' <input value="1" name="buyNumber" class="price1" style="ime-mode: disabled;"> ';
		}else {
			columnInfoHtml=columnInfoHtml+
			' <input value="1" name="buyNumber" class="price" style="ime-mode: disabled;"> ';
		}
		 columnInfoHtml=columnInfoHtml+
		 '<a href="javascript:void(0);" class="plus"><img src="/static/images/plus.gif"></a></div>'+
		'<div class="small_buy"><button class="small_btn" onclick="localAddCart('+column.merchandiseId+',this)"></button></div>'+
		'<div class="blank10 clearit"></div>'+
		'</div>';		
$('#columnInfoDIV').append(columnInfoHtml);
}


function substrVal(val,length){
	if(val.length>length){
		return val.substr(0,length-1)+'...';
	}else {
		return val;
	}
}	

function localAddCart(merchandiseId,obj){
	var buyNumber = $(($(obj).parent().parent().find('[name=buyNumber]'))[0]).val();
	add_one_merchandise_to_cart2(merchandiseId,buyNumber)
}

function localAddCart1(merchandiseId,obj){
	var buyNumber = $(($(obj).parent().parent().parent().find('[name=buyNumber]'))[0]).val();
	add_one_merchandise_to_cart2(merchandiseId,buyNumber);
}



