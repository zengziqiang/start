﻿$(document).ready(function(){
	//加载栏目信息
//	getColumnInfo();
	initTitle(3);
});



//加载首页栏目信息
function getColumnInfo(){
	var data = getAllColumn();
	$.each(data['typeFourList'],function(i,row){
		innerHtmlColumnInfo(i,row);
	});
}

//得到所有栏目
function getAllColumn(){
	var url = '/front/info/column/selectAllColumnGroupByType.json';
	var columnList;
	$.ajax({   
		type : "get",   
		url : url,   
		async : false,   
		success : function(data){   
			columnList = parserToJson(data);
		}   
	}); 
	return columnList;
}

//得到栏目下的药品信息
function getcolumnInfoByColumnId(columnId,size){
	var url = '/front/info/columnInfo/selectColumnInfoByColumnIdForIndex.json';
	var columnList;
	$.ajax({   
		type : "get",   
		url : url,   
		data:{columnId:columnId,size:size},
		async : false,   
		success : function(data){   
			columnList = parserToJson(data);
		}   
	}); 
	return columnList;
}

//库存值格式化
function formatStorageNumber(number){
	if(number == null){
		return 0;
	}else if(number>100){
		return '>100';
	}else {
		return number;
	}
}

//将栏目明细数据加入到区域4的栏目
function innerHtmlColumnInfo(index,column){
	var columnInfoHtml= 
		'<div class="tg_main">'+
	    '<div class="tg_tit">'+
	    '<h4>'+column.name+'</h4>'+
	    '<div class="fenlei"><span><a href="/front/info/columnInfo/columnDetail.htm?columnId='+column.columnId+'">更多>></a></span></div>'+
	    '</div>'+
	    '<div class="tr_tit">'+
	    '<div class="fontbox1">药品名称/规格</div>'+
	    '<div class="s_num1">中包装</div>'+
	  	'<div class="pricehnum1">会员价</div>'+
	    '<div class="pricelnum1">零售价</div>'+
	    '<div class="k_num1">库存</div>'+
	    '<div class="now_num1">购买数量</div>'+
	    '<div class="small_buy1">操作</div>'+
	    '</div>';
		var columnInfos = 5(column.columnId,5);
		$.each(columnInfos,function(i,row){
			columnInfoHtml = columnInfoHtml +
			'<div class="product_imglist">'+
			'<div class="blank10 clearit"></div>'+
			'<div class="imgbox"><a target="blank" href="/front/merchandise/detail.htm?id='+row.merchandiseId+'"><img onerror="this.src=\'/static/images/nophoto.png\'" src="'+merchandiseImagePath+substrVal2(row.orgMerchandiseCode,11)+'/'+substrVal2(row.orgMerchandiseCode,11)+'.JPG" width="90" height="90" /></a></div>'+
			'<div class="fontbox"><p><a target="blank" href="/front/merchandise/detail.htm?id='+row.merchandiseId+'">'+row.currencyName+'</a></p><p>'+row.passfileNumber+'</p><p >药品编码：'+row.orgMerchandiseCode+'</p></div>'+
			'<div class="s_num">'+row.middlingPacking+'</div>';
			if(isCustLogin){
	      	  columnInfoHtml=columnInfoHtml+
	      	'<div class="pricehnum">'+row.formatMermberPrice+'</div>';
	        }else {
	        	  columnInfoHtml=columnInfoHtml+
	  	      	'<div class="pricehnum">--</div>';
			}
			columnInfoHtml=columnInfoHtml+
			'<div class="pricelnum">'+row.formatRetailPrice+'</div>'+
			'<div class="k_num">'+formatStorage(row.storageNumber,row.merchandiseId)+'</div>'+
			'<div class="now_num"><a href="javascript:void(0);" class="minus"><img src="/static/images/minus.gif"></a>';
			if(row.isDecimal){
				columnInfoHtml=columnInfoHtml+
				' <input name="buyNumber" value="1" class="price1" style="ime-mode: disabled;"> ';
			}else {
				columnInfoHtml=columnInfoHtml+
				' <input name="buyNumber" value="1" class="price" style="ime-mode: disabled;"> ';
			}
			columnInfoHtml=columnInfoHtml+
			'<a href="javascript:void(0);" class="plus"><img src="/static/images/plus.gif"></a></div>'+
			'<div class="small_buy"><button class="small_btn" onclick="localAddCart('+row.merchandiseId+',this)"></button></div>'+
			'<div class="blank10 clearit"></div>'+
			'</div>';		
		});
		columnInfoHtml = columnInfoHtml +
		'</div>';
$('#columnAreaFour').append(columnInfoHtml);
}


function substrVal(val,length){
	if(val.length>length){
		return val.substr(0,length-1)+'...';
	}else {
		return val;
	}
}	

function localAddCart(merchandiseId,obj){
	var buyNumber = $(($(obj).parent().parent().find('[name=buyNumber]'))[0]).val();
	add_one_merchandise_to_cart2(merchandiseId,buyNumber)
}
