////////保存操作记录////////////////////////
function recordOpt(id){
	var clickMerchandiseRecordUrl = "/front/info/optRecord/recordClickMerchandiseOpt.json?"+Math.random();
	$.ajax({   
		type : "get",   
		url : clickMerchandiseRecordUrl, 
		data:{relateId:id},
		async : false 
	}); 
}

//跳转
function gotoUrl(url){
	window.location.href=url;
}


//新页面打开
function openUrl(url){
	window.open(url);
}

//点击药品
function clickMerchandise(id){
	//屏蔽药品被点击之后，往数据库里面插入记录 2015-04-01 limingshuai
	//recordOpt(id);
	openUrl('/front/merchandise/detail.htm?id='+id);
}


function addDBasketItem(merchandiseId) {
	
	var url = '/purchase/add_dbaket.json?' + Math.random();
	var isOK = window.confirm("由于该药品库存不足，是否添加到缺货篮");
	if(isOK){
		$.ajax({
			type : "get",
			data : {
				merchandiseId : merchandiseId
			},
			url : url,
			async : true,
			success : function(data) {
				result = parserToJson(data);
				if(result.success == false){
					window.location = "/user/login.htm?from=" + window.location;
				}else{
					 var isf = window.confirm("已经为您添加到缺货栏中！是否进入我的缺货篮?");
					  if(isf){
						  window.location.href="/member/purchase/dbasket_item.htm";
					  }
				}
			}
		});
	}
	
	
}



function add_one_merchandise_to_cart1(merchandiseId,obj,buyNumber){
//	var checkBoxValue = $(obj).attr('checked');
//	if(checkBoxValue == undefined){
//		$(obj).attr('checked','checked');
//		return ;
//	}
	
	
	var merchandiseNumber = buyNumber;
	var array = "[{merchandiseId:"+merchandiseId+",merchandiseNumber:"+merchandiseNumber+"}]";
	//add_cart(array);
	
	var json = check_cart(array);
	if(json ==undefined){
		$("#checkbox"+merchandiseId).removeAttr('checked');
	}
	//if(returnValue != null && returnValue!=""){
	//	alert(returnValue);
	//}
	//if(returnValue=="添加失败"){
	//	$("#checkbox"+merchandiseId).removeAttr('checked');
	//}
}

//添加药品到购物车（非勾选框形式）
function add_one_merchandise_to_cart2(merchandiseId,buyNumber){
	var merchandiseNumber = buyNumber;
	var array = "[{merchandiseId:"+merchandiseId+",merchandiseNumber:"+merchandiseNumber+"}]";
	//退货品种提示
	var json = isReturnMerchandise(merchandiseId);
	if(json.isNotReturnType && (!confirm(json.message))){
		return;
	}
	var json = check_cart(array);
	if(json ==undefined){
	}else{
		
		closeBg(tan_box);
	}
	//if(returnValue != null && returnValue!=""){
	//	alert(returnValue);
	//	if(returnValue=='添加到购物车成功'){
	//		closeBg(tan_box);
	//	}
	//}
}

//PC新版添加品种到购物车方法
function add_one_merchandise_to_cart3_fast(prodno,buyNumber,requestFrom){
	var array = "[{\"prodno\":\""+prodno+"\",\"merchandiseNumber\":\""+buyNumber+"\"}]";
	//退货品种提示
	var json = isReturnMerchandise(prodno+":"+buyNumber);
	if(json.isNotReturnType && (!confirm(json.message))){
		return;
	}
	var result = check_cart(array,requestFrom,'',"true");
	return result;
}

function add_one_merchandise_to_cart(merchandiseId,isFlyToCart,fbox){
//	var checkBoxValue = $("#checkbox"+merchandiseId).attr('checked');
//	if(checkBoxValue == undefined){
//		$("#checkbox"+merchandiseId).attr('checked','checked');
//		return ;
//	}
	var merchandiseNumber = $("#merchandiseNumber"+merchandiseId).val();
	//退货品种提示
	var json = isReturnMerchandise(merchandiseId);
	if(json.isNotReturnType && (!confirm(json.message))){
		return;
	}
	var array = "[{merchandiseId:"+merchandiseId+",merchandiseNumber:"+merchandiseNumber+"}]";
	//add_cart(array);
	check_cart(array,isFlyToCart,fbox,'');
	//if(returnValue != null && returnValue!=""){
	//	alert(returnValue);
	//}
	
	//快速下单，添加购物车有消息提示时，重新获取焦点。
	var num=$("#merchandiseNumber"+merchandiseId).val();
	$("#merchandiseNumber"+merchandiseId).focus();
	$("#merchandiseNumber"+merchandiseId).val(num);
}

var returnValue='';


/*
 * 添加购物车js  传递数据格式:{}
 * 不支持前台调用EXCEL方式,
 */
function add_cart(array){
	/*
	 * 举例: 
	 * array =[{merchandiseId:4885,merchandiseNumber:60},{merchandiseId:4886,merchandiseNumber:30}];
	 * OR  array =[{merchandiseId:4885,merchandiseNumber:60,agentPrice:30},{merchandiseId:4886,merchandiseNumber:30,agentPrice:30}];
	 */
	//array ="[{merchandiseId:4885,merchandiseNumber:60},{merchandiseId:4886,merchandiseNumber:30}]";
	//storageNumber=[{storageNumber:1},{storageNumber:2}];
	var url = "/cartCommon/add_cart.json?"+Math.random();
	var jsonData =  "array="+array;
	$.ajax({
		 type : "GET",                 
		  url: url,
		  data:jsonData,
		  async:false,
		  success: function(data){
			  show_cart();
			  var json = $.parseJSON(data);
			  if(json.success==true){
				  returnValue = json.msg;
			  }else{
				  if(json.msg == "login"){
					  var loc = window.location+'';
					  var links = '/user/login.htm?from=' +loc.replace(/&/g,encodeURIComponent('&'));
					 // alert(encodeURI(links));
					  location.href=encodeURI(links);
					  return false;
				  }
				  returnValue = json.msg;
			  }
		  }
		});

};

function show_cart(){
	if($('#top_cart_count').length==0){
		return false;
	}
	var  url  ="/cartCommon/show_cart.json?rand"+Math.random();
	if(typeof(isFastSearch)!="undefined" && isFastSearch=="true"){//是否是快速下单功能的购物车
		 url="/cartCommon/show_cart.json?isFastSearch=true&"+Math.random();
	}
		$.ajax({
		 type : "GET",                 
		  url: url,
		  async:true,
		  success:function(data){
			  var result='';
			  var json = $.parseJSON(data);
			  var merchandiseList = json.merchandiseList;
			  var totalRecord =  json.totalRecord;
			  var totalPrice = json.totalPrice;
//			  var merchandiseName = json.merchandiseName;
//			  var merchandiseNumber =json.merchandiseNumber;
		//	  href="#" onclick="clickMerchandise('+row.merchandiseId+')"
			 // alert(merchandiseList.length);
			  if(json.msg == "login"){
				  return false;
			  }
			  if(merchandiseList==undefined||merchandiseList.length==0){
				  		$(".car #top_cart_count").html(0);
				  		$('#express_cart .count').html(0);
						$('#express_cart .cartotal').hide();
						$('#express_cart .box_cont').html('<dl class="load blank">购物车中还没有商品，赶快选择心爱的商品吧！</dl>');
			  }else
			  if(merchandiseList.length>0){
				  //是否是快速下单功能的购物车
				  if(typeof(isFastSearch)!="undefined" && isFastSearch=="true"){
					  for(var index=0;index<merchandiseList.length;index++){
							//  alert(merchandiseList[index].merchandiseId);
							  result+='<dl style="height: 20px!important;">'+
							    '<dt style="height: 20px!important;width: 180px !important;"><a  href="#" onclick="clickMerchandise('+merchandiseList[index].merchandiseId+')" title="'+merchandiseList[index].merchandiseName+'">'+merchandiseList[index].merchandiseName+
								'</a></dt><dd class="cost" style="height: 20px!important;"><strong>'+merchandiseList[index].merchandisePrice+
				                '</strong><i>X</i>'+"<p onclick='deleteCartFromExpress("+merchandiseList[index].cartId+")'></p>"
								+merchandiseList[index].merchandiseNumber+'</dd>'+
								'</dl>';  
						  }
					}else{
						  for(var index=0;index<merchandiseList.length;index++){
							//  alert(merchandiseList[index].merchandiseId);
							  result+='<dl>'+
				            	'<dd><a  href="#" onclick="clickMerchandise('+merchandiseList[index].merchandiseId+')" title="'+merchandiseList[index].merchandiseName+'">'+
				            	'<img alt="'+merchandiseList[index].merchandiseName+'"'+'onerror=this.src="/static/images/nophoto.png" src="'+merchandiseList[index].merchandisePath+'" width="50" height="50" /></a></dd>'+
							    '<dt><a  href="#" onclick="clickMerchandise('+merchandiseList[index].merchandiseId+')" title="'+merchandiseList[index].merchandiseName+'">'+merchandiseList[index].merchandiseName+
								'</a></dt><dd class="cost"><strong>'+merchandiseList[index].merchandisePrice+
				                '</strong><i>X</i>'+"<p onclick='deleteCartFromExpress("+merchandiseList[index].cartId+")'></p>"
								+merchandiseList[index].merchandiseNumber+'</dd>'+
								'</dl>';  
						  }
					}
			  		$(".car #top_cart_count").html(json.totalItem);
			  		$("#shopping-amount").html(json.totalItem);
			  		$('#express_cart .box_cont').html(result);
					$('#express_cart .count').html(json.totalItem);
					$('#express_cart .sum').html(json.totalPrice);
					$('#express_cart .cartotal').show(); 
			  }
		  }
		  /**
		  success: function(data){
			  var json = JSON.parse(data);
			// 数组类型 前四种药品图片的路径
			  var merchandisePath = json.merchandisePath;
			  //总记录数
			  var totalRecord =  json.totalRecord;
			  //总金额
			  var totalPrice = json.totalPrice;
			  // 数组类型 前四种药品名称
			  var merchandiseName = json.merchandiseName;
			  alert(totalRecord+","+merchandisePath[0]+","+totalPrice+","+merchandiseName[0]);
			  $("#json").append("<img  onerror=this.src='/static/images/nophoto.png'"+" src='"+merchandisePath[0]+"' width='70' height='70' />");
			//  callback();
		  }
		  */
		});
		/**
	$("#delShowCartId").bind("click",function(){
		if(confirm("是否删除该商品")){
			var cartId = $(this).nextAll("#cartId").val();
			var url ="/member/cart/delete.htm";
			$.ajax({
				 type : "GET",                 
				  url: url,
				  data:'formCartId='+cartId,
				  async:false,
				  success:function(data){
					  show_cart();  
				  }
			});
		}
		
		
	})
	<p id="delShowCartId"></p>'+
	                '<input type="hidden" id="cartId" value="'+merchandiseList[index].cartId+'" />
	*/
	}


/**
 * 删除头部导航购物车数据
 * @param cartId
 */
function deleteCartFromExpress(cartId){
	var url="/member/cart/delete.htm?cartId="+cartId;
	if(typeof(isFastSearch)!="undefined" && isFastSearch=="true"){
		url+="&cartState=3&"+Math.random();
	}
	$.ajax({
		  type : "GET",                 
		  url: url,
		  async:true,
		  success: function(data){
			  show_cart();
		  }
		});
}

function loadMerchandiseNameByAutoComplete(){
	var category = $("#category").val();
	var keyword = $("#keyword").val();
	url="/search/autoComplete.htm?category="+category+"&keyword="+keyword;
	$.ajax({
		  type : "GET",                 
		  url: url,
		  async:true,
		  success: function(data){
			  //return parserToJson(data);
			  return ["av","aa","ab","bb","bc"];
		  }
		});
}

function show_order(){
	var url ="/orderCommon/show_order.json?"+Math.random();
	$.ajax({
		 type : "GET",                 
		  url: url,
		  async:false,
		  success:function(data){
			  var one =0;
			  var six =0;
			  var json = $.parseJSON(data);
			  if(json.msg == "login"){
				  return false;
			  }
			$("#fineshOrder").html(json.six);
			$("#waitOrder").html(json.one);
	}
	})

}
//添加到订单
function add_order(array){ 
	 //array =[{merchandiseId:3,merchandiseNumber:0},{merchandiseId:198,merchandiseNumber:0}];
	var url ="/orderCommon/add_order.json?"+Math.random()+"&array="+array;
	$.post(
			url,
			function(text){
				try{
					var data = parserToJson(text);	
					showdemo('err',data.msg);
				}catch(exception){
					window.location.href = url;
				}
			},
			"text");
}

function formatStorage(number,merchandiseId){
	
	if(number == 0||number==null||number=="null"){
		return '<div class="no-storage-img"  title="库存为0" onclick="addDBasketItem('+merchandiseId+')"></div>';
	}else {
		return number;
	}
}

function encodeValue(){
	$.each($('[needcode=true]'),function(i,row){
		$(row).attr('href',encodeURI($(row).attr('href')));
	});
}

function check_order_detail(array){
	var json;
	var url ="/orderCommon/checkOrderDetail.json?"+Math.random();
	$.ajax({
		 type : "POST",                 
		  url: url,
		  data:"array="+array,
		  async:false,
		  success:function(data){
			   json = $.parseJSON(data); 
			   var conditionone = json.conditionone;
			   if(json.success=='false'){
				   var msg = eval('json.'+conditionone);
				   alert(msg);
				   json=undefined;
				   return;
				}
		  }
	})
	return callbackCart.success(json);
}


//加入购物车校验 2017年5月5日18:52:12 xp
function check_cart(array,isFlyToCart,fbox,isFastSearch){
	var json;
	var url="/cart/common/cartCheck.json?"+Math.random();;
	if(typeof(isFastSearch)!="undefined" &&isFastSearch=="true"){
		url="/cart/common/cartCheck.json?isFastSearch=true&"+Math.random();
	}
	//+"&array="+array
	$.ajax({
		 type : "POST",                 
		  url: url,
		  data:{
              cartJson:array,
              isFastSearch:isFastSearch
          },
		  async:false,
		  success:function(data){
			   //json = $.parseJSON(data);
			   json = data;
			   if(json.isdiaobo==1){
				   alert(json.diaobo);
			   }
			   var conditionone = json.conditionone;
			   var totalRecord = json.totalRecord;
			   if(json.success==false){
                   alert(json.message);
                   return false;

				}else if(json.success==true){
                    addCart(array,isFastSearch);

					//show_cart();
					if(totalRecord==1){
						var msg = eval('json.'+conditionone);
						if(json.slowOrder==undefined){
							if(isFlyToCart != null && (isFlyToCart == true || isFlyToCart == 'merchandiselist' || isFlyToCart == 'merchandisepic' ||isFlyToCart == 'newIndex')){
								//如果是来自于搜索结果列表也或是大图页，或是详情页面，就不弹出对话框
							}else if(typeof(isFastSearch)!="undefined" &&isFastSearch=="true"){
							}else{
								alert(msg);
								try{
								   addcarstyle();
								}catch(e){
									
								}
							}
							
						}else if(json.slowOrder='slowOrder'){
								if(confirm(msg)){
								
							}else{
								json = undefined;
							}
							//return;
						}
					}else{
						var msg = json.message;
						if(json.slowOrder==undefined){
							//alert(msg);
						}else if(json.slowOrder='slowOrder'){
							if(confirm(msg)){
								
							}else{
								json = undefined;
							}
							//return;
						}
					}
					
					if(isFlyToCart != null && isFlyToCart == true){
						//来自药品详情页面
						fly_cart(isFlyToCart);
					}else if(isFlyToCart != null && isFlyToCart == 'merchandiselist'){
						//来自搜索结果列表页面
						fly_cart_merchandiselist(fbox);
					}else if(isFlyToCart != null && isFlyToCart == 'merchandisepic'){
						//来自搜索结果大图页面
						fly_cart_merchandisepic(fbox);
					}
                   return true;
				}
		  }
	});
    if(!(typeof(isFastSearch)!="undefined" && isFastSearch=="true")) {
        try {
            var url = "/cart/common/show_cart_num.json?" + Math.random();
            $.ajax({
                type: "GET",
                url: url,
                async: true,
                success: function (data) {
                    //var json = $.parseJSON(data);
                    var json = data;
                    if (json.success != false) {
                        //alert(json.totalItem);
                        $("#cartNum").html(json.totalItem);
                        $("#barCartNum").html(json.totalItem);
                    } else {
                        $("#cartNum").html(0);
                        $("#barCartNum").html(0);
                    }
                }
            });
        } catch (e) {
        }
    }
	return json;
}

function check_cart_cart(array,obj){
	AjaxLoading.show();//等待文件读取完毕
	var json;
	var url ="/cartCommon/checkNewCart.json?"+Math.random();
	//+"&array="+array
	$.ajax({
		 type : "POST",                 
		  url: url,
		  data:"array="+array,
		  async:false,
		  success:function(data){
			   json = $.parseJSON(data); 
			   if(json.isdiaobo==1){
				   //alert(json.diaobo)1;
				   $.toset(json.diaobo, obj);
			   }
			   var conditionone = json.conditionone;
			   var totalRecord = json.totalRecord;
			   if(json.success=='false'){
					if(conditionone=='login'){
						//alert(json.login)1;
						 $.toset(json.login, obj);
						 var loc = window.location+'';
						  var links = '/user/login.htm?from=' +loc.replace(/&/g,encodeURIComponent('&'));
						 // alert(encodeURI(links));
						  location.href=encodeURI(links);
						  json =undefined;
						return callbackCart.success(json);
					}
					if(conditionone=='permission'){
						//alert(json.permission)1;
						 $.toset(json.permission, obj);
						json =undefined;
						return callbackCart.success(json);
					}
					
					if(conditionone=='error'){
						//alert(json.error)1;
						 $.toset(json.error, obj);
						json =undefined;
						return callbackCart.success(json);
					}
					//购物车品种校验，超过100个品种会提示
					if(conditionone == 'cartCountWarm'){
						//alert(json.message)1;
						 $.toset(json.message, obj);
						json = undefined;
						return;
					}
					
					if(totalRecord==undefined){
						var msg = eval('json.'+conditionone);
						//alert(msg)1;
						 $.toset(msg, obj);
						json =undefined;
						return callbackCart.success(json);
					}else if(totalRecord==1){
						var msg = eval('json.'+conditionone);
						//alert(msg)1;
						$.toset(msg, obj);
						json =undefined;
						return callbackCart.success(json);
					}else{
						var msg = json.message;
						//alert(msg)1;
						$.toset(msg, obj);
						json =undefined;
						return callbackCart.success(json);
					}
					json =undefined;
					return callbackCart.success(json);
				}else if(json.success=='true'){
					show_cart();
					if(totalRecord==1){
						var msg = eval('json.'+conditionone);
						if(json.slowOrder==undefined){
							//alert(msg)1;
							$.toset(msg, obj);
						}else if(json.slowOrder='slowOrder'){
								if(confirm(msg)){
								
							}else{
								json = undefined;
							}
							return callbackCart.success(json);
						}
					}else{
						var msg = json.message;
						if(json.slowOrder==undefined){
							//alert(msg)1;
							$.toset(msg, obj);
						}else if(json.slowOrder='slowOrder'){
							if(confirm(msg)){
								
							}else{
								json = undefined;
							}
							return callbackCart.success(json);
						}
					}
				}
		  }
	})
	return callbackCart.success(json);
	//return json;
	
}

//验证是否可以退货
function isReturnMerchandise(merchandiseId){
	var json;
	var url ="/cart/common/getInfoByID.json?"+Math.random();
	$.ajax({
        type : "GET",
        url: url,
        data:"merchandiseId="+merchandiseId,
        async:false,
        dataType:"json",
        success:function(data){
            //json = $.parseJSON(data);
            json = data;
        }
	});
	return json;
}




$.extend({      
    /** 
    * @see 将javascript数据类型转换为json字符串   
    * @param 待转换对象,支持  object,array,string,function,number,boolean,regexp   
    * @return 返回json字符串 
    */     
    toJSON:function(object){    
        var type = typeof object;        
        if ('object' == type) {          
            if (Array == object.constructor) 
                type = 'array';          
            else if (RegExp == object.constructor)   
                type = 'regexp';          
            else
                type = 'object';        
        }        
        switch (type) {        
            case 'undefined':        
            case 'unknown':          
                return;           
            case 'function':        
            case 'boolean':        
            case 'regexp':          
                return object.toString();          
            case 'number':          
                return isFinite(object) ?   object.toString() : 'null';          
            case 'string':          
                return '"' + object.replace(/(|")/g, "$1").replace(/n|r|t/g, function(){            
                            var a = arguments[0];           
                            return (a == 'n') ? 'n': (a == 'r') ? 'r': (a == 't') ? 't': ""         
                        }) + '"';          
            case 'object':          
                if (object === null) 
                    return 'null';          
                var results = [];  
                for (var property in object) {            
                    var value = $.toJSON(object[property]);            
                    if (value !== undefined) results.push(jQuery.toJSON(property) + ':' + value);          
                }          
                return '{' + results.join(',') + '}';          
            case 'array':          
                var results = [];          
                for (var i = 0; i < object.length; i++) {            
                    var value = $.toJSON(object[i]);            
                    if (value !== undefined) results.push(value);         
                }          
                return '[' + results.join(',') + ']';         
        }      
    }    
});

/**
 * 加入购物车
 * @param cartJson
 */
function addCart(cartJson,isFastSearch){
    var url = "/member/cart/add_cart.htm?" + Math.random();
    $.ajax({
        type : "POST",
        url : url,
        data:{
            cartJson:cartJson,
            isFastSearch:isFastSearch
        },
        success : function(data) {
            if(data.success){
                //layer.msg("添加成功");
            }else{
                alert(data.message);
            }
        }
    });
}