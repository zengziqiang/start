﻿
$(document).ready(function() {
	loadScoreInfo();
});		


function loadScoreInfo(){
	$('#scoreDiv').html('');
	var dataResult = selectScoreInfo();
	innerScore(dataResult.avgsScore);
	$('#scoreBt').click(function(){
		var sellingDegrees = $('input[name=radio]:checked').val();
		var priceFit = $('input[name=radio1]:checked').val();
		doScore(sellingDegrees,priceFit);
	});
}

function addPurchase(){
	var url = '/front/purchase/add_attention.json?'+Math.random();
	var merchandiseId = $('#merchandiseId').val();
	$.ajax({   
		type : "get",   
		url : url,   
		data:{merchandiseId:merchandiseId},
		async : false,   
		success : function(data){   
			data = parserToJson(data);
			if(data.success){
				showdemo('ok',data.msg+'!    <a href="/member/purchase/attention.htm" style="color: red;">进入我的关注</a>','no');
			}else {
				gotoUrl('/user/login.htm?from=/front/merchandise/detail.htm?id='+merchandiseId);
			}
		}   
	});
}

function selectScoreInfo(){
	var url = '/front/merchandiseScore/getScoreInfo.json?'+Math.random();
	var merchandiseId = $('#merchandiseId').val();
	$.ajax({   
		type : "get",   
		url : url,   
		data:{merchandiseId:merchandiseId},
		async : false,   
		success : function(data){   
			dataResult = parserToJson(data);
		}   
	});
	return dataResult;
}

function innerScore(avgScore){
	var innerHtml = 
		'<div class="pinfq">';
			innerHtml = innerHtml+
			'<p><span>我要评分</span>（5分为最高分，1分为最低分）</p>'+
			'<div class="pf_sale">药品畅销度：<span>'+(avgScore==undefined?0:avgScore.formatSellingDegrees)+'</span>分'+
			'<input name="radio" type="radio" value="5" checked="checked" /><label>5分</label>'+
			'<input name="radio" type="radio" value="4" /><label>4分</label>'+
			'<input name="radio" type="radio" value="3" /><label>3分</label>'+
			'<input name="radio" type="radio" value="2" /><label>2分</label>'+
			'<input name="radio" type="radio" value="1" /><label>1分</label>'+
		'</div>'+
		'<div class="pf_sale">价格适合度：<span>'+(avgScore==undefined?0:avgScore.formatPriceFit)+'</span>分'+
			'<input name="radio1" type="radio" value="5" checked="checked" /><label>5分</label>'+
			'<input name="radio1" type="radio" value="4" /><label>4分</label>'+
			'<input name="radio1" type="radio" value="3" /><label>3分</label>'+
			'<input name="radio1" type="radio" value="2" /><label>2分</label>'+
			'<input name="radio1" type="radio" value="1" /><label>1分</label>'+
		'</div>'+
		'</div>'+
			'<div class="pf_btn"><button  class="btn_big " id="scoreBt"></button></div>';
		$('#scoreDiv').append(innerHtml);
}

function doScore(sellingDegrees,priceFit){
	var url = '/front/merchandiseScore/doScore.json?'+Math.random();
	var merchandiseId = $('#merchandiseId').val();
	$.ajax({   
		type : "post",   
		url : url,   
		data:{merchandiseId:merchandiseId,sellingDegrees:sellingDegrees,priceFit:priceFit},
		async : true,   
		success : function(data){   
			dataResult = parserToJson(data);
			if(dataResult.success) {
				alert(dataResult.msg+"!");
				loadScoreInfo();
			}
			else {
				alert('评分失败:'+dataResult.msg);
			}
		}   
	});
}

function loadOtherMerchandise(pageNum,pageSize){
	$('#otherMerchandiseDiv').html('');
	var data = selectOtherMerchandise(pageNum,pageSize);
	innerOtherMerchandise(data);
}

function selectOtherMerchandise(pageNum,pageSize){
	var url = '/front/merchandise/otherMerchandise.json?'+Math.random();
	var dataResult;
	var id = $('#merchandiseId').val();
	var level3Name = $('#level3Name').val();
	var merchandiseName = $('#merchandiseName').val();
	$.ajax({   
		type : "get",   
		url : url,   
		data:{page:pageNum,rows:pageSize,level3Name:level3Name,id:id,merchandiseName:merchandiseName},
		async : false,   
		success : function(data){   
			dataResult = parserToJson(data);
		}   
	});
	return dataResult;
}

function innerOtherMerchandise(merchandiseList){
	$.each(merchandiseList,function(i,row){
		var innerHtml = 
		'<div class="product_gl">'+
		'<span class="sp_name"><a target="blank" href="/front/merchandise/detail.htm?id='+row.merchandise_id+'">'+row.currency_name+'</a></span>'+
		'<span class="sp_price">&nbsp;';
		 if(isCustLogin && row.member_price != null){
			 innerHtml=innerHtml+
			 '￥'+row.member_price.toFixed(2);
		 }else {
			 innerHtml=innerHtml+
			 '￥--';
		}
		 innerHtml=innerHtml+
		'</span><button  style="margin-top:6px;" class="small_btn" onclick="openBuyWindow('+row.merchandise_id+');"></button>'+
		'</div>';
		$('#otherMerchandiseDiv').append(innerHtml);
	});
}

//添加该药品到购物车
function localAddCart(){
	var buyNumber = $('#buyNumber').val();
	var merchandiseId = $('#merchandiseId').val();
	add_one_merchandise_to_cart2(merchandiseId,buyNumber);
}
//添加药品到购物车
function detailAddCart(isFlyToCart){
	var buyNumber = $('#buyNumber').val();
	var merchandiseId = $('#merchandiseId').val();
	var orgMerchandiseCode =$('#orgMerchandiseCode').val();
	var saleType = $('#saleType').val();
	var activityId = $('#activityId').val();
	var array = "[{merchandiseId:"+merchandiseId+",orgMerchandiseCode:\""+orgMerchandiseCode+"\",merchandiseNumber:"+buyNumber;
	if(activityId.length>0&&saleType.length>0){
		array = array + ",saleType:"+saleType+",activityId:"+activityId;
	}
	array+="}]";
	//退货品种提示
	var json = isReturnMerchandise(merchandiseId);
	if(json.isNotReturnType && (!confirm(json.message))){
		return;
	}
	var json = check_cart(array,isFlyToCart);
	//if(json ==undefined){
//	}else{
	///	closeBg(tan_box);
	//}
}
