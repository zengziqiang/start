$(document).ready(function() {
    

   $('.item_shu dl dt img').click(function(){

	   var boxm=$(this).parent('dt').parent('dl').children('dd');
	 
	   if(boxm.css('display')=='none'){ 
		  $(this).attr('src','images/user/jian.png')
		   boxm.show();
		   
		}else{
			$(this).attr('src','images/user/jia.png')
		  boxm.hide();
		}
	}); 
	
	//分类切换
	$('.danxuan input[type=radio]:eq(0)').attr('checked','checked');
	$('.danxuan input[type=radio]').click(function(){
		if($(this).attr('checked')=='checked'){
			if($('.cxcg_tit_bug a').length=='0'){
						$('.cxcg_tit_bug').css('display','none');
					}
			
			$('.cxcg_tit_bug a').each(function() {
				
				if($(this).children('em').children('small').html()!='医保分类'){
					$(this).remove();
					if($('.cxcg_tit_bug a').length=='0'){
						$('.cxcg_tit_bug').css('display','none');
					}
				}
                
            });
			
			if($(this).index()==0){
				$('.table').hide();
		
			} else{
				$('.table').hide();
				$('.table').eq($(this).index()-1).show();
				
			};
		
		}
		
		})
	
	//分类
		
		$('.user_fenlei tr td a').click(function(){
			var nowk='true';
			var child_zhi=$(this).html();
			if($(this).parents('table').attr('id')!='fenlei'){
				var parent_zhi=$('.danxuan input:checked').val()
			}else{
				var parent_zhi='医保分类'
			}
	
		if($('.cxcg_tit_bug').css('display')=='block'){
			$('.cxcg_tit_bug a em small').each(function(){
				var ni=$(this).html();
				if(ni==parent_zhi){
				$(this).parent('em').children('span').html(child_zhi);
					nowk='false';
				}
				
			});
			if(nowk=='true'){$('.cxcg_tit_bug').append('<a href="#"><em><small>'+parent_zhi+'</small>：<span>'+child_zhi+'</span></em></a>')};
			
			
		};
		if($('.cxcg_tit_bug').css('display')=='none'){
			$('.cxcg_tit_bug').fadeIn("qucik");;
			$('.cxcg_tit_bug').append('<a href="#"><em><small>'+parent_zhi+'</small>：<span>'+child_zhi+'</span></em></a>');
		};
	
	
	});
	$('.cxcg_tit_bug a').live('click',function(){
		$(this).remove();
		if($('.cxcg_tit_bug a').length==0){$('.cxcg_tit_bug').css('display','none')}
		
		});

	
	
	
	
});