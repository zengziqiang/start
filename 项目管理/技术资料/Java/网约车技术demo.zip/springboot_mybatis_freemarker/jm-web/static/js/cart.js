

/**
 * 显示购物车信息
 * {"msg":"[{\"merchandisePath\":[\"http:\/\/59.173.12.139:8010\/MedicinedePository\/manager\/upload\/Img\/HAG017010C\/HAG017010C.JPG\"],\"totalRecord\":60,\"totalPrice\":0}]"}
 */
function show_cart(){
	var url  ="/cartCommon/show_cart.json";
		$.ajax({
		 type : "GET",                 
		  url: url,
		  success: function(data){
			  var json = parserToJson(data);
			// 数组类型 前四种药品图片的路径
			  var merchandisePath = json.merchandisePath;
			  //总记录数
			  var totalRecord =  json.totalRecord;
			  //总金额
			  var totalPrice = json.totalPrice;
			  // 数组类型 前四种药品名称
			  var merchandiseName = json.merchandiseName;
			  alert(totalRecord+","+merchandisePath[0]+","+totalPrice+","+merchandiseName[0]);
			  $("#json").append("<img  onerror=this.src='/static/images/nophoto.png'"+" src='"+merchandisePath[0]+"' width='70' height='70' />");
			//  callback();
		  }
		});
	
}


/**
 * 加入购物车之前的校验
 * @param array
 * @param isFlyToCart
 * @param fbox
 * @returns {*}
 */
function check_cart(array,isFlyToCart,fbox,isFastSearch){
    var url="/cart/common/cartCheck.json?"+Math.random();
    $.ajax({
        type : "POST",
        url: url,
        data:{
            cartJson:array,
            isFastSearch:isFastSearch
        },
        async:false,
        success:function(data){
            if(data.success){
                //校验通过后才进行购物车的提交动作
                var flag = addCart(array,isFastSearch);
                return flag;
            } else {
                alert(data.message);
                if(data.isNotLogin){
                    window.location.href = "/user/login.htm";
                }
                return false;
            }
        }
    });
}

/**
 *加入购物车
 * @param cartJson
 */
function addCart(cartJson,isFastSearch){
    var url = "/member/cart/add_cart.htm?" + Math.random();
    $.ajax({
        type : "POST",
        url : url,
        data:{
            cartJson:cartJson,
            isFastSearch:isFastSearch
        },
        success : function(data) {
            if(data.success){
                if(isFastSearch!="true"){
                    layer.msg("添加成功");
                }
                return true;
            }else{
                alert(data.message);
                return false;
            }
        }
    });
}

/**
 * 单个品种加入购物车
 * @param merchandiseId
 * @param buyNumObj
 * @param retail
 * @param isDecimal
 * @param sourceFrom   购物车加入场景
 * @param purchasePrice
 */
function addOneToCart(prodno,prodId,buyNumObj, retail, isDecimal,sourceFrom,purchasePrice,isFastSearch) {
    var buyNum = $(buyNumObj).val();
    var reg = /^\d+(\.[05])?$/;
    if(typeof(retail) != "undefined" && typeof(isDecimal) != "undefined" && retail == 1 && isDecimal == 1) {
        if(!reg.test(buyNum)) {
            alert("该商品的采购数量必须是0.5的整数倍！ ");
            $(buyNumObj).focus();
            return;
        }
    }
    var json = add_one_merchandise_to_cart3(prodno,prodId, buyNum,sourceFrom,purchasePrice,isFastSearch);

    $(buyNumObj).focus();
    return json;
}

//PC新版添加品种到购物车方法,新增purchasePrice:购买是的价格
function add_one_merchandise_to_cart3(prodno,prodId,buyNumber,sourceFrom,purchasePrice,isFastSearch){
    var merchandiseNumber = buyNumber;
    var array;
    if(purchasePrice==null||purchasePrice==""||typeof(purchasePrice) == "undefined"){
        array= "[{\"prodno\":\""+prodno+"\",\"prodid\":\""+prodId+"\",\"merchandiseNumber\":"+merchandiseNumber+",\"sourceFrom\":\""+sourceFrom+"\"}]";
    }else{
        array= "[{\"prodno\":\""+prodno+"\",\"prodid\":\""+prodId+"\",\"merchandiseNumber\":"+merchandiseNumber+",\"sourceFrom\":\""+sourceFrom+",\"purchasePrice:\"" + purchasePrice + "}]";
    }
    //alert(array);
    //退货品种提示(未实现)
    //var json = isReturnMerchandise(merchandiseId);
    //if(json.isNotReturnType && (!confirm(json.message))){
    //    return;
    //}
    var result = check_cart(array,sourceFrom,'',isFastSearch);
    return result;
}



//验证是否可以退货
function isReturnMerchandise(merchandiseId){
    var json;
    var url ="/cartCommon/getInfoByID.json?"+Math.random();
    $.ajax({
        type : "GET",
        url: url,
        data:"merchandiseId="+merchandiseId,
        async:false,
        success:function(data){
            json = $.parseJSON(data);
        }
    });
    return json;
}


