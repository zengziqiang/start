﻿

/**
 * 专门针对需求： B2B  BB-110 B2B3.1版本二期需求 最终定版！ BB-117
 * 主要用来进行导航首页，让文字居中
 */
function danhangBB117(){
	var nice1 = $('.nav').width();//整体nav的宽度
	var nice2 = $('.categorys').width();//左边导航的宽度
	var nice3 = $('.nav .nav_m a').width()+10;//.nav_m 中的a标签的宽度(包含a中padding的值)
	var nice4 = $('.nav .nav_m').children('a').length;//计算.nav_m中的a标签的个数
	var nice5 = $('.nav .nav_m ').children('.na_h').index();//计算a标签所在元素中的位置的返回值

	$('.nav .nav_m').children('a').each(function(i){//i为序列值 each为对于每个匹配的元素所要执行的函数
	if(i>0){
	//alert(i);
	var nice6 = $('.nav .nav_m_d').eq(i).children('a').length;//计算.nav_m中div中的a标签的个数
	var nice7 = $('.nav .nav_m_d').eq(i).children('a').text().length;//计算.nav_m中div中的一个a标签的宽度
	var p1 = nice6*nice7;
	var p2 = nice1-nice2-nice3*i;

	$(this).next().css('padding-left',nice3*i);
	$(this).next().css('width',p2);

	if(nice7 > 24){
	$(this).next().css('margin-left','-170px','text-align','center','overflow','hidden');
	$(this).next().css('width','800px');
	}




	}else{$(this).next().css('width','720px');
	};

	});

	
}