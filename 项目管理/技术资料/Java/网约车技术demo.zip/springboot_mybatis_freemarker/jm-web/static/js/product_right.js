﻿
$(document).ready(function() {
//	loadHuodong(1,3);
//	loadRexiao(1,2);
//	loadRank(1,5);
});		 

function loadRexiao(pageIndex,pageSize){
	var data = selectRexiao(pageIndex,pageSize);
	innerRexiao(data);
}

function selectRexiao(pageIndex,pageSize){
	var url = '/sale/activity/serchPandect.json?'+Math.random();
	var dataResult;
	$.ajax({   
		type : "post",   
		url : url,   
		data:{activityType:2,page:pageIndex,rows:pageSize},
		async : false,   
		success : function(data){   
			dataResult = parserToJson(data);
		}   
	});
	return dataResult.rows;
}

function innerRexiao(merchandiseList){
	$.each(merchandiseList,function(i,row){
		var innerHtml = 
		'<div class="product_li_le">'+
		'<div class="left_img"><a target="blank" href="/front/merchandise/detail.htm?id='+row.merchandiseId+'"><img width="90" height="90" onerror="this.src=\'/static/images/nophoto.png\'" src="'+merchandiseImagePath+substrVal2(row.merchandiseCode,11)+'/'+substrVal2(row.merchandiseCode,11)+'.JPG" style="opacity: 1;"></a></div>'+
		'<div class="all_left_font">'+
		'<p><a target="blank" href="/front/merchandise/detail.htm?id='+row.merchandiseId+'" title="'+row.merchandiseName+'">'+substrVal(row.merchandiseName,7)+'</a></p>'+
		'<p class="yuanj">零售价:'+row.formatRetailPrice+'元</p>';
		if(isCustLogin){
			innerHtml=innerHtml+
			'<p class="xianj">会员价:'+row.formatMermberPrice+'元</p>';
		 }else {
			 innerHtml=innerHtml+
				'<p class="xianj">会员价:--</p>';
		}
		innerHtml=innerHtml+
		'<p><a href="javascript:void(0)" onclick="openBuyWindow('+row.merchandiseId+');">加入购物车<img width="5" height="10" src="/static/images/icon.gif"></a></p>'+
		'</div>'+
		'</div>'+
		'<div class="clearit"></div>';
		$('#huodongList').append(innerHtml);
	});
}

function loadHuodong(pageIndex,pageSize){
	$('#huodongList').html('');
	var data = selectHuodongList(pageIndex,pageSize);
	innerHuodong(data);
}

function selectHuodongList(pageIndex,pageSize){
	var url = '/sale/activity/serchPandect.json?'+Math.random();
	var dataResult;
	$.ajax({   
		type : "post",   
		url : url,   
		data:{activityType:1,page:pageIndex,rows:pageSize},
		async : false,   
		success : function(data){  
			dataResult = parserToJson(data);
		}   
	});
	return dataResult.rows;
}

function innerHuodong(merchandiseList){
	$.each(merchandiseList,function(i,row){
		var innerHtml = 
		'<div class="product_li_le">'+
		'<div class="left_img"><a target="blank" href="/front/merchandise/detail.htm?id='+row.merchandiseId+'"><img width="90" height="90" onerror="this.src=\'/static/images/nophoto.png\'" src="'+merchandiseImagePath+substrVal2(row.merchandiseCode,11)+'/'+substrVal2(row.merchandiseCode,11)+'.JPG" style="opacity: 1;"></a></div>'+
		'<div class="all_left_font">'+
		'<p><a target="blank" href="/front/merchandise/detail.htm?id='+row.merchandiseId+'" title="'+row.merchandiseName+'">'+substrVal(row.merchandiseName,7)+'</a></p>'+
		'<p class="yuanj">零售价:'+row.formatRetailPrice+'元</p>';
		if(isCustLogin){
			innerHtml=innerHtml+
			'<p class="xianj">会员价:'+row.formatMermberPrice+'元</p>';
		 }else {
			 innerHtml=innerHtml+
				'<p class="xianj">会员价:--</p>';
		}
		innerHtml=innerHtml+
		'<p><a href="javascript:void(0)" onclick="openBuyWindow('+row.merchandiseId+');">加入购物车<img width="5" height="10" src="/static/images/icon.gif"></a></p>'+
		'</div>'+
		'</div>'+
		'<div class="clearit"></div>';
		$('#huodongList').append(innerHtml);
	});
}

function loadRank(page,rows){
	list = getSaleRankInfo(page,rows);
	innerSaleRank(list);
}

function getSaleRankInfo(page,rows){
	var url = '/front/rank/selectMerchandiseForSaleRank.json';
	var list;
	$.ajax({   
		type : "get",   
		url : url, 
		data:{page:page,rows:rows},
		async : false,   
		success : function(data){   
			list = parserToJson(data);
		}   
	}); 
	return list;
}


function innerSaleRank(list){
	$.each(list,function(i,row){
		if(row.merchandiseName!=null && row.formatRetailPrice != null){
			var innerHtml= 
				'<div class="product_li_le">'+
				'<div class="left_img"><a target="blank" href="/front/merchandise/detail.htm?id='+row.merchandiseId+'"><img width="90"  height="90" onerror="this.src=\'/static/images/nophoto.png\'" src="'+merchandiseImagePath+substrVal2(row.orgmerchandiseCode,11)+'/'+substrVal2(row.orgmerchandiseCode,11)+'.JPG"></a></div>'+
				'<div class="all_left_font">'+
				'<p><a class="p_name" target="blank" href="/front/merchandise/detail.htm?id='+row.merchandiseId+'"  title="'+row.merchandiseName+'">'+substrVal(row.merchandiseName,7)+'</a></p>'+
				'<p class="yuanj">零售价:'+row.formatRetailPrice+'元</p>';
				if(isCustLogin){
					innerHtml=innerHtml+
					'<p class="xianj">会员价:'+row.formatMermberPrice+'元</p>'
				 }else {
					 innerHtml=innerHtml+
						'<p class="xianj">会员价:--</p>';
				}
				innerHtml=innerHtml+
				'<p><a href="javascript:void(0)" onclick="openBuyWindow('+row.merchandiseId+');">加入购物车<img width="5" height="10" src="/static/images/icon.gif"></a></p>'+
				'</div>'+
				'</div>'+
				'<div class="clearit"></div>';
				$('#rexiaoList').append(innerHtml);
		}
	});
	$('#rexiaoList').append('<div class="blank10"></div>');
}

