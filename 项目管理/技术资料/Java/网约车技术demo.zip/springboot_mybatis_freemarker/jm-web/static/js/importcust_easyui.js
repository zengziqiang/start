

//显示客户单位
function loadCustMain(isOpen){
	 if(isOpen != null && isOpen == "true"){
		 $("#addCustMain").window("open");
	 }else{
		 return;
	 }

	 $("#getCustMain").datagrid({
			striped: true,
			fitColumns:true,
			url:'/basic/get_cust_main.json',
			method:'post',
			pagination:true,
			singleSelect:false,
			pageSize:10,
			rownumbers:true,
			idField:'custId',
			frozenColumns:[[
			    	        {field:'id',checkbox:true}
			           ]],
			    		columns:[[ 
			    			{field:'custId',title:'',hidden:true},
			    			{field:'custName',title:'单位名称'},
			    			{field:'danwBh',title:'单位编码'},
			    		]]
		});
	 
	 var rows = $('#getCustMain').datagrid('getSelections');
	 if (!(rows == null || rows.length == 0)) {
			$('#getCustMain').datagrid('clearSelections');		
	 }
}


//确定选择客户单位
function getCustMain(){
	 var rows = $('#getCustMain').datagrid('getSelections'); 
	 var ss = []; 
	 var sss=[];
	 for(var i=0; i<rows.length; i++){  
        var row = rows[i];  
        ss.push(row.custName);
        sss.push(row.custId);
    } 
	 $("#custNumberId").val(sss);
	 $("#custNumber").val(ss);
	 $('#getCustMain').datagrid('clearSelections');
	 $("#addCustMain").window("close");
}


//取消客户单位选择
function closeCustMainWindow(){
	 $("#addCustMain").window("close");
}

//客户单位查询
function searchCust(){
		$('#getCustMain').datagrid('options').queryParams={"custName":$("#custName").val()};
	    $("#getCustMain").datagrid('reload');
}

function excelCustOpen(){
	 $("#importCust").window("open");
}

function importCust(){
		var url = "/admin/merchandise/importCust.json?"+Math.random();;
		$("#importFormCust").form("submit",{
			url:url,
		    success:function(text){  
		    	var data = parserToJson(text);
		    	if(data.success == undefined) {
		    		$('#importCust').window('close');
		    		$('#addCustMain').window('close');
		    		importCustSelected(data);
		    		$.messager.alert('提示','导入成功','info');
		    	}
		    	else {
		    		$.messager.alert('发生错误',data.msg,'error');
		    	}
		    }
		});
	}
 
 
 function closeImportCust(){
		$('#importCust').window("close");
	} 
 
 //这个方法需要在调用importcusteasyui.jsp页面处补充
// function importCustSelected(data){
//	 	var ss = []; 
//		var sss=[];
//		$.each(data, function(i, row){
//			var exists = false;
//			ss.push(row.custName);
//	        sss.push(row.custId);
//		});
//		
//		$("#custNumberId").val(sss);
//		$("#custNumber").val(ss);
//} 