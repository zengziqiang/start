﻿$(document).ready(function(){
	$('.easyui-window').show();
	$('.hideDiv').show();
	
});
