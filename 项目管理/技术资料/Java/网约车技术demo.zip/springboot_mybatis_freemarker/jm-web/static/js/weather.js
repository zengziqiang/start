// JavaScript Document

$(document).ready(function() {
//天气层 20130826 新增
$("#weather").addClass("weatherHide");
$("#dateNow").click(function(){
	$("#weather").removeClass();
	$("#weather").addClass("weatherShow");
	})
$("#weatherX").click(function(){
	$("#weather").removeClass();
	$("#weather").addClass("weatherHide");
	})

});