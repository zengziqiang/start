// 新品统计
function showProvince(beginDatex,endDatex){
	$('#searchProvinceTable').datagrid({
		nowrap: true,
		striped: true,
		fitColumns:true,
		toolbar:"#toolbar",
		url : '/salesman/province.json',
		method:'post',
		pagination:true,
		singleSelect:false,
		fit : true,
		rownumbers : true,
		//idField : 'newProductId',
		columns : [ [ 
		{
			title : '省',
			field : 'province',
			resizable : true,
			rowspan : 10,
			formatter: function(value,row,index){
				return "<a href='javascript:void(0)' onclick=containsCity()>"+value+"</a>"
			}
		},{
			title : '品种名称',
			field : 'merchandiseName',
			align : 'left',
			resizable : true,
		}, {
			title : '品种编码',
			field : 'orgmerchandiseCode',
			align : 'left',
			resizable : true,
		}, {
			title : '品种规格',
			field : 'merchandiseSpec',
			align : 'left',
			resizable : true,
		}, {
			title : '生产厂家',
			field : 'manufacturer',
			align : 'left',
			resizable : true,
		},{
			title : '销售金额',
			field : 'detail_price',
			align : 'left',
			resizable : true,
			sortable : true,
			sortName : 'detail_price',	
			sortOrder : 'DESC',	
		}, {
			title : '销售数量',
			field : 'detail_amount',
			align : 'left',
			resizable : true,
			sortable : true,
		}, {
			title : '订单数',
			field : 'order_id',
			align : 'left',
			resizable : true,
			sortable : true,
		}, {
			title : '客户数',
			field : 'cust_id',
			align : 'left',
			resizable : true,
			sortable : true,
		} ] ],
		onLoadSuccess:function(){
			$('#searchProvinceTable').datagrid("autoMergeCells", ['province']);
	    }
	});

}
	
function searchProvinceTable(){
	$('#searchProvinceTable').datagrid('options').queryParams={"beginDate":$("#beginDatex").datebox('getValue'),
	"endDate":$("#endDatex").datebox('getValue')},
	$("#searchProvinceTable").datagrid('reload');
}

//合并单元格
$('#searchProvinceTable').datagrid({
    onLoadSuccess:function(){
        var merges = [{
            index:0,
            rowspan:10
        }];
        for(var i=0; i<merges.length; i++)
            $('#searchProvinceTable').datagrid('mergeCells',{
                index:merges[i].index,
                field:'province',
                rowspan:merges[i].rowspan
            });
    }
});

function containsCity(){
	debugger;
	var beginDate = $("#beginDatex").datebox('getValue');
	var endDate = $("#endDatex").datebox('getValue');
	window.location.href="/salesman/city.htm?beginDate="+beginDate+"&endDate="+endDate;
}


//------------------------市--------------------------------


function showCity(beginDate,endDate){
	$("#beginDatex").datebox('setValue',beginDate);
	$("#endDatex").datebox('setValue',endDate);
	$('#searchCityTable').datagrid({
		nowrap: true,
		striped: true,
		fitColumns:true,
		toolbar:"#toolbar",
		url : '/salesman/city.json',
		method:'post',
		pagination:true,
		singleSelect:false,
		fit : true,
		rownumbers : true,
		//idField : 'newProductId',
		columns : [ [ 
		{
			title : '市',
			field : 'city',
			resizable : true,
			rowspan : 10,
			formatter: function(value,row,index){
				return "<a href='javascript:void(0)' onclick=\"containsArea('"+value+"')\">"+value+"</a>"
			}
		},{
			title : '品种名称',
			field : 'merchandiseName',
			align : 'left',
			resizable : true,
		}, {
			title : '品种编码',
			field : 'orgmerchandiseCode',
			align : 'left',
			resizable : true,
		}, {
			title : '品种规格',
			field : 'merchandiseSpec',
			align : 'left',
			resizable : true,
		}, {
			title : '生产厂家',
			field : 'manufacturer',
			align : 'left',
			resizable : true,
		},{
			title : '销售金额',
			field : 'detail_price',
			align : 'left',
			resizable : true,
			sortable : true,
			sortName : 'detail_price',	
			sortOrder : 'DESC',	
		}, {
			title : '销售数量',
			field : 'detail_amount',
			align : 'left',
			resizable : true,
			sortable : true,
		}, {
			title : '订单数',
			field : 'order_id',
			align : 'left',
			resizable : true,
			sortable : true,
		}, {
			title : '客户数',
			field : 'cust_id',
			align : 'left',
			resizable : true,
			sortable : true,
		} ] ],
		onLoadSuccess:function(){
			$('#searchCityTable').datagrid("autoMergeCells", ['city']);
	    }
	});
}

function containsArea(city){
	var beginDate = $("#beginDatex").datebox('getValue');
	var endDate = $("#endDatex").datebox('getValue');
	window.location.href="/salesman/area.htm?beginDate="+beginDate+"&endDate="+endDate+"&city="+city;
}

function searchCityTable(){
	$('#searchCityTable').datagrid('options').queryParams={"beginDate":$("#beginDatex").datebox('getValue'),
	"endDate":$("#endDatex").datebox('getValue')},
	$("#searchCityTable").datagrid('reload');
}

//------------------------区--------------------------------


function showArea(beginDate,endDate){
	$("#beginDatex").datebox('setValue',beginDate);
	$("#endDatex").datebox('setValue',endDate);
	$('#searchAreaTable').datagrid({
		nowrap: true,
		striped: true,
		fitColumns:true,
		toolbar:"#toolbar",
		url : '/salesman/area.json',
		method:'post',
		pagination:true,
		singleSelect:false,
		fit : true,
		rownumbers : true,
		//idField : 'newProductId',
		columns : [ [ 
		{
			title : '区',
			field : 'cantonname',
			resizable : true,
			rowspan : 10,
		},{
			title : '品种名称',
			field : 'merchandiseName',
			align : 'left',
			resizable : true,
		}, {
			title : '品种编码',
			field : 'orgmerchandiseCode',
			align : 'left',
			resizable : true,
		}, {
			title : '品种规格',
			field : 'merchandiseSpec',
			align : 'left',
			resizable : true,
		}, {
			title : '生产厂家',
			field : 'manufacturer',
			align : 'left',
			resizable : true,
		},{
			title : '销售金额',
			field : 'detail_price',
			align : 'left',
			resizable : true,
			sortable : true,
			sortName : 'detail_price',	
			sortOrder : 'DESC',	
		}, {
			title : '销售数量',
			field : 'detail_amount',
			align : 'left',
			resizable : true,
			sortable : true,
		}, {
			title : '订单数',
			field : 'order_id',
			align : 'left',
			resizable : true,
			sortable : true,
		}, {
			title : '客户数',
			field : 'cust_id',
			align : 'left',
			resizable : true,
			sortable : true,
		} ] ],
		onLoadSuccess:function(){
			$('#searchAreaTable').datagrid("autoMergeCells", ['cantonname']);
	    }
	});
}

function searchAreaTable(){
	$('#searchAreaTable').datagrid('options').queryParams={"beginDate":$("#beginDatex").datebox('getValue'),
	"endDate":$("#endDatex").datebox('getValue')},
	$("#searchAreaTable").datagrid('reload');
}



//-------------------------业务员销售数据汇总---------------------------------

function showSalesmanTotal(){
	$('#searchSalesmanTotalTable').datagrid({
		nowrap: true,
		striped: true,
		fitColumns:true,
		toolbar:"#toolbar",
		url : '/salesman/total.json',
		method:'post',
		pagination:true,
		singleSelect:false,
		fit : true,
		rownumbers : true,
		//idField : 'newProductId',
		columns : [ [ 
		{
			title : '业务员',
			field : 'loginName',
			resizable : true,
			rowspan : 10,
		},{
			title : '销售金额',
			field : 'detail_price',
			align : 'left',
			resizable : true,
			sortable : true,
			sortName : 'detail_price',	
			sortOrder : 'DESC',	
		},{
			title : '销售数量',
			field : 'detail_amount',
			align : 'left',
			resizable : true,
			sortable : true,
		},{
			title : '订单数',
			field : 'order_id',
			align : 'left',
			resizable : true,
			sortable : true,
		},{
			title : '客户数',
			field : 'cust_id',
			align : 'left',
			resizable : true,
			sortable : true,
		}]],
	});
}

function searchTotalTable(){
	$('#searchSalesmanTotalTable').datagrid('options').queryParams={"beginDate":$("#beginDatex").datebox('getValue'),
		"endDate":$("#endDatex").datebox('getValue')},
		$("#searchSalesmanTotalTable").datagrid('reload');
}


//-------------------------业务员销售数据明细---------------------------------

function showSalesmanDetail(){
	$('#searchSalesmanDetailTable').datagrid({
		nowrap: true,
		striped: true,
		fitColumns:true,
		toolbar:"#toolbar",
		url : '/salesman/detail.json',
		method:'post',
		pagination:true,
		singleSelect:false,
		fit : true,
		rownumbers : true,
		//idField : 'newProductId',
		columns : [ [ 
		{
			title : '单据日期',
			field : 'create_time',
			align : 'left',
			resizable : true,
			sortable : true,
		},{
			title : '业务员',
			field : 'login_name',
			align : 'left',
			resizable : true,
			sortable : true,
		},{
			title : '订单编号',
			field : 'orderCode',
			align : 'left',
			resizable : true,
			formatter: function(value,row,index){
				return "<a href='javascript:void(0)' onclick=\"detailByOrderCode('"+value+"')\">"+value+"</a>"
			}
		},{
			title : '客户名称',
			field : 'cust_name',
			align : 'left',
			resizable : true,
			sortable : true,
		},{
			title : '客户编码',
			field : 'danwBh',
			align : 'left',
			resizable : true,
			sortable : true,
		},{
			title : '订单金额',
			field : 'detail_price',
			align : 'left',
			resizable : true,
			sortable : true,
			//sortName : 'detail_price',	
		}]],
	});
}

function searchDetailTable(){
	$('#searchSalesmanDetailTable').datagrid('options').queryParams={"beginDate":$("#beginDatex").datebox('getValue'),
		"endDate":$("#endDatex").datebox('getValue')},
		$("#searchSalesmanDetailTable").datagrid('reload');
}

function detailByOrderCode(orderCode){
	window.location.href="/salesman/detailByOrderCode.htm?orderCode="+orderCode;
}

function showSalesmanDetailByOrderCode(){
	$('#searchSalesmanDetailTableByOrderCode').datagrid({
		nowrap: true,
		striped: true,
		fitColumns:true,
		toolbar:"#toolbar",
		url : '/salesman/detailByOrderCode.json',
		method:'post',
		pagination:true,
		singleSelect:false,
		fit : true,
		//idField : 'newProductId',
		columns : [ [ 
		{
			title : '药品编码',
			field : 'orgmerchandiseCode',
			align : 'left',
			resizable : true,
			rowspan : 10,
		},{
			title : '药品名称',
			field : 'merchandiseName',
			align : 'left',
			resizable : true,
			rowspan : 10,
		},{
			title : '药品规格',
			field : 'merchandiseSpec',
			align : 'left',
			resizable : true,
			sortOrder : 'DESC',	
		},{
			title : '生产厂家',
			field : 'manufacturer',
			align : 'left',
			resizable : true,
			sortable : true,
		},{
			title : '价格',
			field : 'memberPrice',
			align : 'left',
			resizable : true,
			sortable : true,
		},{
			title : '数量',
			field : 'purchase_amount',
			align : 'left',
			resizable : true,
			sortable : true,
			sortName : 'purchase_amount',	
		},{
			title : '订单金额',
			field : 'detail_price',
			align : 'left',
			resizable : true,
			sortable : true,
			//sortName : 'detail_price',	
		}]],
	});
}
