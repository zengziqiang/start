//----------------------------------------------------界面
//查询展销会展台


function loadst(){
	$('#stTable').datagrid({
		//fit : true,
		striped: true,
		fitColumns:true,
		toolbar:"#stToolbar",
		url:'/tacticsReport/st.htm',
		height:'325',
		method:'post',
		pageSize : 10,
		pageNumber : 1,
		pagination:true,
		singleSelect:true,
		rownumbers:true,
		idField:'aktionsprogrammId',
		frozenColumns:[[
            {field:'aktionsprogrammIds',checkbox:true}
		]],
		columns:[[
			{title:'活动名称', field:'aktionsprogrammName', align:'left', resizable:true,width:'120'},
			{title:'活动状态', field:'stateName', align:'left', resizable:true,width:'100'},
			{title:'活动类型', field:'aktionsprogrammTypeName', align:'left', resizable:true,width:'80'},
			{title:'产生九州币', field:'sumJZB', align:'left', resizable:true,width:'100'},
			{title:'参与人数', field:'sumUser', align:'left', resizable:true,width:'80'},
			{title:'开始时间', field:'startTime', align:'left', resizable:true,width:'70'},
			{title:'结束时间', field:'endTime', align:'left', resizable:true,width:'70'}
		]]
	});	
}
function loadTacticsItem(){
	loadst();
	$('#stdiv').window('open');
}
function cleanst(){
	
	$('#stStartDate1').datetimebox('setValue','');
	$('#stStartDate2').datetimebox('setValue','');
	$('#stEndDate1').datetimebox('setValue','');
	$('#stEndDate2').datetimebox('setValue','');
	$('#stName').val('');
	$('#stType').combobox('select',0);
	$('#stState').combobox('select',0);
	$('#searchTType').combobox('select',0);
	$('#stSumUser1').val('');
	$('#stSumUser2').val('');
	$('#stSumJZB1').val('');
	$('#stSumJZB2').val('');

}
function searchst(){
	 
	$('#stTable').datagrid('options').queryParams = {
		"startTime1":$('#stStartDate1').datetimebox('getValue'),
		"startTime2":$('#stStartDate2').datetimebox('getValue'),
		"endTime1":$('#stEndDate1').datetimebox('getValue'),
		"endTime2":$('#stEndDate2').datetimebox('getValue'),
		"aktionsprogrammName":$('#stName').val(),
		"aktionsprogrammType":$('#stType').datebox('getValue'),
	    "state":$('#stState').datebox('getValue'),
		"SumUser1":	$('#stSumUser1').val().trim()==''?0:$('#stSumUser1').val().trim(),
		"SumUser2":	$('#stSumUser2').val().trim()==''?0:$('#stSumUser2').val().trim(),
		"SumJZB1":	$('#stSumJZB1').val().trim()==''?0:$('#stSumJZB1').val().trim(),
		"SumJZB2":	$('#stSumJZB2').val().trim()==''?0:$('#stSumJZB2').val().trim()
	};
	$("#stTable").datagrid('uncheckAll');
	$("#stTable").datagrid('reload');
}

function loadstu(atid){
	$('#stuTable').datagrid({
		//fit : true,
		striped: true,
		height:'350',
		//fitColumns:true,
		toolbar:"#stuToolbar",
		queryParams:{"aktionsprogrammId":atid},
		url:'/tacticsReport/stu.htm',
		method:'post',
		pageSize : 15,
		pageNumber : 1,
		pagination:true,
		singleSelect:true,
		rownumbers:true,
		idField:'custId',
		frozenColumns:[[
            {field:'custIds',checkbox:true}
		]],
		columns:[[
			{title:'客户编码', field:'danwBh', align:'left', resizable:true,width:'120'},
			{title:'单位名称', field:'custName', align:'left', resizable:true,width:'100'},
			{title:'客户帐号', field:'userLogin', align:'left', resizable:true,width:'80'},
			{title:'订单出库总量', field:'sumOrder', align:'left', resizable:true,width:'70'},
			{title:'订单出库总额', field:'sumMoney', align:'left', resizable:true,width:'70'},
			{title:'获得九州币', field:'sumJZB', align:'left', resizable:true,width:'80'},
			{title:'电子商务员', field:'dzswUser', align:'left', resizable:true,width:'70'},
			{title:'开始时间', field:'startTime', align:'left', resizable:true,width:'70'},
			{title:'结束时间', field:'endTime', align:'left', resizable:true,width:'80'}
		]]
	});	
}
function stuOpen(){

	if($('#stTable').datagrid('getSelections').length!=1)
	{
		$.messager.alert('警告', '请填选择要查询的九州币策略!');
		return ;
	}
	loadstu($('#stTable').datagrid('getSelections')[0].aktionsprogrammId);
	$('#studiv').window('open');
}
function cleanstu(){
	$('#stuStartDate1').datetimebox('setValue','');
	$('#stuStartDate2').datetimebox('setValue','');
	$('#stuEndDate1').datetimebox('setValue','');
	$('#stuEndDate2').datetimebox('setValue','');
	$('#stuName').val('');
	$('#stuBh').val('');
	$('#stuLoginName').val('');
	$('#stuSumMoney1').val('');
	$('#stuSumMoney2').val('');
	$('#stuSumJZB1').val('');
	$('#stuSumJZB2').val('');
}
function searchstu(){
	$('#stuTable').datagrid('options').queryParams = {
		"aktionsprogrammId":$('#stTable').datagrid('getSelections')[0].aktionsprogrammId,
		"startTime1":$('#stuStartDate1').datetimebox('getValue'),
		"startTime2":$('#stuStartDate2').datetimebox('getValue'),
		"endTime1":$('#stuEndDate1').datetimebox('getValue'),
		"endTime2":$('#stuEndDate2').datetimebox('getValue'),
		"custName":$('#stuName').val(),
		"userLogin":$('#stuLoginName').val(),
	    "danwBh":$('#stuBh').val(),
		"sumMoney1":	$('#stuSumMoney1').val().trim()==''?0:$('#stuSumMoney1').val().trim(),
		"sumMoney2":	$('#stuSumMoney2').val().trim()==''?0:$('#stuSumMoney2').val().trim(),
		"sumJZB1":	$('#stuSumJZB1').val().trim()==''?0:$('#stuSumJZB1').val().trim(),
		"sumJZB2":	$('#stuSumJZB2').val().trim()==''?0:$('#stuSumJZB2').val().trim()
	};
	$("#stuTable").datagrid('uncheckAll');
	$("#stuTable").datagrid('reload');
}
function loadsto(atid,custid){
	$('#stoTable').datagrid({
		//fit : true,
		striped: true,
		//fitColumns:true,
		toolbar:"#stoToolbar",
		url:'/tacticsReport/sto.htm',
		method:'post',
		height:'400',
		pageSize : 15,
		pageNumber : 1,
		pagination:true,
		queryParams:{"aktionsprogrammId":atid,"custId":custid},
		singleSelect:true,
		rownumbers:true,
		idField:'orderId',
		frozenColumns:[[
            {field:'orderIds',checkbox:true}
		]],
		columns:[[
			{title:'订单编号', field:'orderBh', align:'left', resizable:true,width:'120'},
			{title:'订单金额', field:'sumMoney', align:'left', resizable:true,width:'120'},
			{title:'获得九州币', field:'sumJZB', align:'left', resizable:true,width:'80'},
			{title:'电子商务员', field:'danwBh', align:'left', resizable:true,width:'70'},
			{title:'订单出库时间', field:'modifyTime', align:'left', resizable:true,width:'80'}
		]]
	});	
}

function stoOpen(){
	if($('#stuTable').datagrid('getSelections').length!=1)
	{
		$.messager.alert('警告', '请填选择要查询的用户!');
		return ;
	}
	loadsto($('#stTable').datagrid('getSelections')[0].aktionsprogrammId,$('#stuTable').datagrid('getSelections')[0].custId);
	$('#stodiv').window('open');
}
function cleansto(){
	$('#stoDate1').datetimebox('setValue','');
	$('#stoDate2').datetimebox('setValue','');
	$('#stoOrderCode').val('');
}
function searchsto(){
	$('#stoTable').datagrid('options').queryParams = {
		"aktionsprogrammId":$('#stTable').datagrid('getSelections')[0].aktionsprogrammId,
		"modifyTime2":$('#stoDate2').datetimebox('getValue'),
		"modifyTime1":$('#stoDate1').datetimebox('getValue'),
		"custId":$('#stuTable').datagrid('getSelections')[0].custId,
	    "orderBh":$('#stoOrderCode').val()
	};
	$("#stoTable").datagrid('uncheckAll');
	$("#stoTable").datagrid('reload');
}

function loadstm(orderId){
	$('#stmTable').datagrid({
		fit : true,
		striped: true,
		fitColumns:true,
		toolbar:"#stmToolbar",
		url:'/tacticsReport/stm.htm',
		queryParams:{"orderId":orderId},
		method:'post',
		pageSize : 15,
		pageNumber : 1,
		pagination:true,
		singleSelect:true,
		rownumbers:true,
		idField:'merchandiseId',
		frozenColumns:[[
            {field:'merchandiseIds',checkbox:true}
		]],
		columns:[[
			{title:'单位名称', field:'custName', align:'left', resizable:true,width:'120'},
			{title:'单位编号', field:'danwBh', align:'left', resizable:true,width:'100'},
			{title:'单位类型', field:'custType', align:'left', resizable:true,width:'100'},
			{title:'药品名称', field:'mName', align:'left', resizable:true,width:'120'},
			{title:'药品规格', field:'mSpec', align:'left', resizable:true,width:'100'},
			{title:'药品编码', field:'mCode', align:'left', resizable:true,width:'100'},
			{title:'药品出库金额', field:'sumMoney', align:'left', resizable:true,width:'80'},
			{title:'获得九州币', field:'sumJZB', align:'left', resizable:true,width:'80'},
		//	{title:'电子商务员', field:'startTime', align:'left', resizable:true,width:'70'},
		//	{title:'开票员', field:'endTime', align:'left', resizable:true,width:'70'},
			{title:'药品出库时间', field:'createTime', align:'left', resizable:true,width:'80',editor:{type:'numberbox',options:{precision:0}}}
		]]
	});	
}

function stmOpen(){
	if($('#stoTable').datagrid('getSelections').length!=1)
	{
		$.messager.alert('警告', '请填选择要查询的订单!');
		return ;
	}
	loadstm($('#stoTable').datagrid('getSelections')[0].orderId);
	$('#stmdiv').window('open');
}
function cleanstm(){
	$('#stmDate1').datetimebox('setValue','');
	$('#stmDate2').datetimebox('setValue','');
	//$('#stmCustName').val('');
	//$('#stmDanwBh').val('');
	//$('#stmCustType').val('');
	//$('#stmDzswUser').val('');
	//$('#stmkpUser').val('');
}
function searchstm(){
	$('#stmTable').datagrid('options').queryParams = {
		"orderId":$('#stoTable').datagrid('getSelections')[0].orderId,
		"orderTime1":$('#stmDate1').datetimebox('getValue'),
		"orderTime2":$('#stmDate2').datetimebox('getValue'),
		"custId":$('#stuTable').datagrid('getSelections')[0].custId,
	    "orderBh":$('#stoOrderCode').val()
	};
	$("#stmTable").datagrid('uncheckAll');
	$("#stmTable").datagrid('reload');
}



function excelT(){
	
	$("#execlTForm").form("submit", {
		url : "/tacticsReport/excelT.htm?"+ Math.random(),
		onSubmit : function() {
			return $(this).form('validate');
		},
		success : function(text) {
			var data = (new Function("return " + text))();
			if (data.success) {
				//$.messager.alert('提示', data.msg, 'info');
			} else {
				$.messager.alert('发生错误', data.msg, 'error');
			}
		}
	});
}
function  excelU(){
	$("#stuaktionsprogrammId").val($('#stTable').datagrid('getSelections')[0].aktionsprogrammId);
	$("#execlUForm").form("submit", {
		url : "/tacticsReport/excelU.htm?="+Math.random(),
		onSubmit : function() {
			return $(this).form('validate');
		},
	//	data:{"aktionsprogrammId":$('#stTable').datagrid('getSelections')[0].aktionsprogrammId},
		success : function(text) {
			var data = (new Function("return " + text))();
			if (data.success) {
				//$.messager.alert('提示', data.msg, 'info');
			} else {
				$.messager.alert('发生错误', data.msg, 'error');
			}
		}
	});
}
function excelO(){
	$("#stoaktionsprogrammId").val($('#stTable').datagrid('getSelections')[0].aktionsprogrammId);
	$("#stocustId").val($('#stuTable').datagrid('getSelections')[0].custId);
	$("#execlOForm").form("submit", {
		url : "/tacticsReport/excelO.htm?"+ Math.random(),
		onSubmit : function() {
			return $(this).form('validate');
		},
		success : function(text) {
			var data = (new Function("return " + text))();
			if (data.success) {
				//$.messager.alert('提示', data.msg, 'info');
			} else {
				$.messager.alert('发生错误', data.msg, 'error');
			}
		}
	});
}
function excelM(){
	$("#stmorderId").val($('#stoTable').datagrid('getSelections')[0].orderId);
	$("#execlMForm").form("submit", {
		url : "/tacticsReport/excelM.htm?"+ Math.random(),
		onSubmit : function() {
			return $(this).form('validate');
		},
		data:{	
			"orderId":$('#stoTable').datagrid('getSelections')[0].orderId},
		success : function(text) {
			var data = (new Function("return " + text))();
			if (data.success) {
				//$.messager.alert('提示', data.msg, 'info');
			} else {
				$.messager.alert('发生错误', data.msg, 'error');
			}
		}
	});
}

//清空查询条件按钮


