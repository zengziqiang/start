﻿//检查格式,同时核实是否有货
function zhongxiaobao(c,z,k,id,r,purchaseAmount){
	if(!isNaN($(c).val())){
		if(r==0) $(c).val(parseInt($(c).val()/z)*z);
		$(c).val(parseInt($(c).val()));
		if($(c).val()==0){
			$(c).css("background-color","#FFCB99");
		}
	}else{
		showdemo('err',"输入格式错误");
		$(c).val(0);
		$(c).css("background-color","#FFCB99");
		
	}
}

//添加到缺货篮
function addDbasket(id,purchaseAmount){
	var url = "add_dbasket_item.json?id="+id+"&purchaseAmount="+purchaseAmount;
	$.get(url,function(data){
		var dataObj=eval("("+data+")");
		if(dataObj.success){
			showdemo('err',"库存不足,已添加至缺货篮");
		}else{
			showdemo('err',"库存不足");
		}
	},"text");
}
function tiaozhuanniao(){
	window.location.href = '/member/cart/index.htm';
}
//添加到订单
function adddingdan(){
	var array = "[";
	var pan = true;
	var i = 0;
	$('input:checkbox[name="checkbox"]:checked').each(function(){
		i++;
		var id=this.value;
		id = $("#merchandiseId"+id).val();
		var merchandiseNumber = $("#merchandiseNumber"+id).val();
		if(merchandiseNumber==0){showdemo('err','采购数量不能为0');pan = false;}
		var agentPrice = $("#agentPrice"+id).val();
		if(agentPrice != "" && typeof(agentPrice) != "undefined") array += "{merchandiseId:"+id+",merchandiseNumber:"+merchandiseNumber+",agentPrice:"+agentPrice+"},";
		else array += "{merchandiseId:"+id+",merchandiseNumber:"+merchandiseNumber+"},";
	});
	if(i==0){showdemo('err','请选择要添加的商品');pan = false;}
	array = array.substr(0,array.length-1);
	array += "]";
	if(pan) add_order(array);
}
function u(){
	window.top.location.reload();
}
//批量添加到购物车
function addCart(){
	var array = "[";
	var i= 0;
	var pan = true;
	var count = 0;//统计禁退品种数量
	var returnTypeStr = "";//禁退品种拼接字符串
	$('input:checkbox[name="checkbox"]:checked').each(function(){
		i++;
		var id=this.value;
		id = $("#merchandiseId"+id).val();
		var merchandiseNumber = $("#merchandiseNumber"+id).val();
		var agentPrice = $("#agentPrice"+id).val();
		var orgMerchandiseCode =$("#orgMerchandiseCode"+id).html();
		if(agentPrice != "" && typeof(agentPrice) != "undefined") array += "{merchandiseId:"+id+",orgMerchandiseCode:\""+orgMerchandiseCode+"\",merchandiseNumber:"+merchandiseNumber+",agentPrice:"+agentPrice+"},";
		else array += "{merchandiseId:"+id+",orgMerchandiseCode:\""+orgMerchandiseCode+"\",merchandiseNumber:"+merchandiseNumber+"},";
		//禁退药品提示的处理
		var json = isReturnMerchandise(id);
		if(json.isNotReturnType){
			if(returnTypeStr.length > 0){//中间用、分开
				returnTypeStr = returnTypeStr + "、";
				if(count%2 == 0){
					returnTypeStr = returnTypeStr + "\n";
				}
			} 
			
			returnTypeStr = returnTypeStr + json.returnTypeVO.merchandiseName+json.returnTypeVO.orgmerchandiseCode;
			count++;
		}
	});
	
	if(i==0){showdemo('err','请选择要添加的商品');pan = false;}
	array = array.substr(0,array.length-1);
	array += "]";

	//如果存在禁退药品，给出提示
	if(count > 0){
		var message = "共有" + count + "项商品（" + returnTypeStr + "）不支持退货，是否确认购买？";
		if(!confirm(message)){
			return;
		}
	}
	if(pan) {
		check_cart(array);//加入购物车
		//if(returnValue != null && returnValue!=""){
		//	if(returnValue=="库存不足,已添加到缺货篮,请少量采购")showdemo('err',"库存不足,已添加到缺货篮");
		//	else showdemo('ok',returnValue,tiaozhuanniao);
		//}else{
		//	showdemo('err',"添加失败");
		//}
	}
}
//添加单条商品到购物车
function addCartSingle(merchandiseId){
	var merchandiseNumber = $("#merchandiseNumber"+merchandiseId).val();
	var agentPrice = $("#agentPrice"+merchandiseId).val();
	var orgMerchandiseCode =$("#orgMerchandiseCode"+merchandiseId).html();
	if(agentPrice != "" && typeof(agentPrice) != "undefined") var array = "[{merchandiseId:"+merchandiseId+",orgMerchandiseCode:\""+orgMerchandiseCode+"\",merchandiseNumber:"+merchandiseNumber+",agentPrice:"+agentPrice+"}]";
	else var array = "[{merchandiseId:\""+merchandiseId+"\",orgMerchandiseCode:\""+orgMerchandiseCode+"\",merchandiseNumber:\""+merchandiseNumber+"\"}]";
	//退货品种提示
	var json = isReturnMerchandise(merchandiseId);
	if(json.isNotReturnType && (!confirm(json.message))){
		return;
	}
	check_cart(array);//加入购物车
	//if(returnValue != null && returnValue!=""){
	//	showdemo('ok',returnValue,tiaozhuanniao);
//	}else{
//		showdemo('err',"添加失败");
	//}
}