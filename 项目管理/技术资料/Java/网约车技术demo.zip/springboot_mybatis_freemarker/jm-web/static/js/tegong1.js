// JavaScript Document
$(document).ready(function() {
var k = $('.tgPorductBox .tgPorduct').length;
for(i=1;i<=k;i+=2){
	$('.tgPorductBox .tgPorduct').eq(i).css('float','right');	
}

$('.tgPorduct').hover(
	function(){$(this).removeClass('tgPorduct').addClass('tgPorductHover');},
	function(){$(this).removeClass('tgPorductHover').addClass('tgPorduct');}
);

$('.left:odd').removeClass().addClass('right')

});