// JavaScript Document
$(document).ready(function() {
		
		/*$('.p_r').click(function(){
			var index = $('.aa').index();
			//alert(aa);
			if(index<6){
				$('.w_content').hide();
				$('.aa').next().show().addClass('aa');
				$('.aa').eq(0).hide().removeClass('aa');
			}else{
				$('.w_content0').click();
				return false;
				}
			})
		$('.p_l').click(function(){
			$('w_content').hide();
			$('.aa').prev().show().addClass('aa');
			$('.aa').eq(1).hide().removeClass('aa');
			})	
		//鼠标点击事件（跳转到下一个元素）
		$('.w_content .w_img').click(function(){//鼠标点击w_content时触发的事件
			$(this).parent().hide().removeClass('aa');//隐藏
			$(this).parent().next().show().addClass('aa');//这个w_show01的父元素的下一个元素显示
		});
		//最后一页时触发事件
		//最后一样点击时触发事件
		$('.w_content0').click(function(){
			//赋值：重新浏览演示功能
			var find = "重新浏览";
			//赋值：回到首页
			var home = "返回首页";
			var te = "已是最后一页！";
			var title = "<div class='alert'>"+"<div class='te'>"+te+"</div><br />"+"<div class='one'><a href='help3.1.html'>"+find+"</a></div><div class='two'><a href='http://www.yyjzt.com'>"+home+"</a></div></div>";
			$('body').append(title);
			//计算窗口的高度和宽度
			var win_h = $(window).height();
			var win_w = $(window).width();
			//取得alert的高度和宽度
			var alert_h = $('.alert').height();
			var alert_w = $('.alert').width();
			//计算窗口的位置
			var x = win_w/2-alert_w;
			var y = win_h/2-alert_h;
			//alert(x);alert(y);
			$('.alert').css({top:y,left:x})
			})*/
});

