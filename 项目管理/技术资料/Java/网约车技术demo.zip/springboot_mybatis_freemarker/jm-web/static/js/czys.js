// JavaScript Document

$(document).ready(function(){
		
	$('.h2 ul li').each(function(){
		var $fun;
		var imgH1 = $('.num ul li:first').height();
		$('.num').css('height',imgH1);
		$('.h2 ul li:first').addClass('show');
		$(this).mouseover(function(){
			var x = $(this).index();
			var y = ($(this).parent().children().length)-1;
			var imgH = $('.num ul li').eq(x).height();
			$('.num').css('height',imgH);
			if(x<y){
				$('.h2 ul li').removeClass('show');
				$('.h2 ul li').removeClass('show0');
				$(this).addClass('show');
				var liW = $('.num ul li').width();
				var ulML = parseInt($('.num ul').css('left'));
				$('.num ul').animate({'left':-liW*x},400);
				
				}
			else if(x=y){
				var liW = $('.num ul li').width();
				$('.h2 ul li').removeClass('show');
				$(this).addClass('show0');
				$('.num ul').animate({'left':-x*liW},400);
				}
			})
		settime = window.setInterval(contentautoScroll,4000);
		})
	})
function contentautoScroll(){//自动滚动
	var liW = $('.num ul li:first').width();
	var liL = $('.num ul li').length;
	var ulML = parseInt($('.num ul').css('left'));
	if(ulML == -liW*(liL-1) && $('.num ul').is(":animated")==false){
		$('.num ul').animate({'left':0},300,function(){
			$('.h2 ul li').removeClass('show0');
			$('.h2 ul li').eq(0).addClass('show');
			});
		//alert('GO TO ONE PAGE');
		}
		else if($('.num ul').is(":animated")==false){
			$('.num ul').animate({'left':ulML-liW},300,function(){
				var x = -(ulML-liW)/liW;
				var y = liL-1;
				var imgH = $('.num ul li').eq(x).height();
				$('.num').css('height',imgH);
				//
				if(x<y){
					$('.h2 ul li').removeClass('show');
					$('.h2 ul li').removeClass('show0');
					$('.h2 ul li').eq(x).addClass('show');
					}
					else if(x=y){
					$('.h2 ul li').removeClass('show');
					$('.h2 ul li').eq(x).addClass('show0');
						}
				});
			}
	}	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	