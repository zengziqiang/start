
$(document).ready(function() {
	initAmountOrCount();
	
	$(function(){
		$("#feedsbacktable").datagrid({
			fit : true,
			width:'auto',
			striped: true,
			fitColumns:false,
			toolbar:"#toolbar",
			url:'/admin/goodsfeedback/feedsback.json',
			pagination:true,
			singleSelect:false,
			rownumbers:true,
			pageSize:10,
			idField:'newproductId',
			frozenColumns:[[
			    	        {field:'id',checkbox:true}
			           ]],
			    		columns:[[ 
			    			{field:'newproductId',title:'ID',hidden:false},
			    			{field:'status',title:'审核状态',width:80,
			    				formatter:function(value, row, index){
			    					if(row.status==1){
			    						return "未审核";
			    					}else if(row.status==2){
			    						return "已审核";
			    					}
			    				}
			    			},
			    			{field:'createTimeStr',title:'反馈时间',width:150},
			    			{field:'type',title:'反馈类型',width:80,
			    				formatter:function(value, row, index){
			    					if(row.type==1){
			    						return "新品需求";
			    					}else if(row.type==2){
			    						return "市场低价";
			    					}else if(row.type==3){
			    						return "缺货资源";
			    					}
			    				}
			    			},
			    			{field:'merchandiseName',title:'药品名称',width:120},
			    			{field:'manufacturerId',title:'生产厂家',width:100},
			    			{field:'jiangli',title:'奖励',width:150},
			    			
			    			{field:'custName',title:'客户单位',width:130},
			    			{field:'loginName',title:'客户账号',width:80},
			    			{field:'replayContent',title:'客户账号',width:80,hidden:true},
			    			
			    		]]
		});
	 });
	 
});	
	
function openSearchWindow(){
	$("#searchId").window("open");
}
//关闭查询窗口
function searchCancle(){
	$("#searchId").window("close");
}

function searchOk(){
	var typeSearch = $("#typeSearch").val();
	var statusSearch = $("#statusSearch").val();
	var beginDate = $("#beginDate").datebox('getValue');
	var endDate = $("#endDate").datebox('getValue');
	
	
	$('#feedsbacktable').datagrid('options').queryParams={
        "type":typeSearch,
        "status":statusSearch,
        "beginDate":beginDate,
        "endDate":endDate
      };
	$('#feedsbacktable').datagrid('clearChecked'); 
	$("#feedsbacktable").datagrid('reload');
	
	searchCancle();
	
}

function openCheckPublishWindow(){
	var rows = $('#feedsbacktable').datagrid('getSelections');
	if (rows == null || rows.length == 0) {
		$.messager.alert('警告', '请先选择一条记录再点击审核发布');
		return;
	}
	var length = rows.length;
	if(length == 1){
		var status = rows[0].status;
		if(status==2){
			$.messager.alert('警告', '请选择至少一条未审核信息');
			return;
		}
	}
	var newProductIds="";
	for ( var i = 0; i < length; i++) {
		if(rows[i].status == 1){
			newProductIds=newProductIds+rows[i].newproductId+",";
		}
	}
	if(newProductIds.length==0){
		$.messager.alert('警告', '请选择至少一条未审核信息');
		return;
	}
	
	$("#newProductIds").val(newProductIds);
	$("#checkPublishId").window("open");
}

function checkPublishCommit(){
	var jifen=$("#jifen").val();
	var jiuzhoubi=$("#jiuzhoubi").val();
	var cash=$("#cash").val();
	var newProductIds=$("#newProductIds").val();
	
	$.ajax({
		url : "/admin/goodsfeedback/checkPublish.htm",
		async : false,
		type : 'post',
		data : {
			'_method' : 'put',
			'jifen':jifen,
			'jiuzhoubi':jiuzhoubi,
			'cash':cash,
			'newProductIds':newProductIds
		},
		dataType : 'json',
		success : function(data) {
			if (data.success) {
				$.messager.alert('提示',data.msg);
				$('#feedsbacktable').datagrid('clearSelections');	
				$('#purchaselisttable').datagrid("reload");
			} else {
				$.messager.alert('警告', data.msg);
			}

			checkPublishCancle();
			$('#feedsbacktable').datagrid('clearChecked'); 
			$("#feedsbacktable").datagrid('reload');
		}
	});
	
}

//关闭发布窗口
function checkPublishCancle(){
	$("#newProductIds").val("");
	$("#jifen").val("");
	$("#jiuzhoubi").val("");
	$("#cash").val("");
	$("#checkPublishId").window("close");
}

//查看反馈详情总入口
function openDetailInfo(){
	var rows = $('#feedsbacktable').datagrid('getSelections');
	if (rows == null || rows.length != 1) {
		$.messager.alert('警告', '请选择一条记录点击查看');
		return;
	}
	var type= rows[0].type;
	if(type==1){
		openNewProductWindow();
	}else if(type==2){
		openLowerPriceWindow();
	}else if(type==3){
		openStockoutWindow();
	}
}

function openNewProductWindow(){
	var rows = $('#feedsbacktable').datagrid('getSelections');
	$("#merchandiseName1").val(rows[0].merchandiseName);
	$("#merchandiseSpec1").val(rows[0].merchandiseSpec);
	$("#manufacturerId1").val(rows[0].manufacturerId);
	$("#passfileNumber1").val(rows[0].passfileNumber);
	$("#price1").val(rows[0].price);
	$("#amount1").val(rows[0].amount);
	$("#goodsSource1").val(rows[0].goodsSource);
	
	$("#fileUrl1").attr("href",rows[0].fileUrl);
	$("#fileUrl1").html(rows[0].fileUrl);
	
	$("#replayContent1").val(rows[0].replayContent);
	$("#newproductId1").val(rows[0].newproductId);
	
	$("#detailForNewProductId").window("open");
}

function detailForNewProductCommit(){
	var replayContent  =  $("#replayContent1").val();
	var newproductId  = $("#newproductId1").val();
	
	apply(replayContent, newproductId);
	detailForNewProductCancle();
	$("#feedsbacktable").datagrid('reload');
}

//关闭新品详情窗口
function detailForNewProductCancle(){
	$("#detailForNewProductId").window("close");
}

function openLowerPriceWindow(){
	var rows = $('#feedsbacktable').datagrid('getSelections');
	$("#merchandiseName2").val(rows[0].merchandiseName);
	$("#merchandiseSpec2").val(rows[0].merchandiseSpec);
	$("#manufacturerId2").val(rows[0].manufacturerId);
	$("#passfileNumber2").val(rows[0].passfileNumber);
	$("#price2").val(rows[0].price);
	$("#goodsSource2").val(rows[0].goodsSource);
	
	$("#fileUrl2").attr("href",rows[0].fileUrl);
	$("#fileUrl2").html(rows[0].fileUrl);
	
	
	$("#replayContent2").val(rows[0].replayContent);
	$("#newproductId2").val(rows[0].newproductId);
	$("#detailForLowerPriceId").window("open");
}


function detailForLowerPriceCommit(){
	var replayContent  =  $("#replayContent2").val();
	var newproductId  = $("#newproductId2").val();
	
	apply(replayContent, newproductId);
	detailForLowerPriceCancle();
	$("#feedsbacktable").datagrid('reload');
}

//关闭市场低价详情窗口
function detailForLowerPriceCancle(){
	$("#detailForLowerPriceId").window("close");
}

function openStockoutWindow(){
	var rows = $('#feedsbacktable').datagrid('getSelections');
	$("#merchandiseName3").val(rows[0].merchandiseName);
	$("#merchandiseSpec3").val(rows[0].merchandiseSpec);
	$("#manufacturerId3").val(rows[0].manufacturerId);
	$("#passfileNumber3").val(rows[0].passfileNumber);
	$("#goodsSource3").val(rows[0].goodsSource);
	
	$("#fileUrl3").attr("href",rows[0].fileUrl);
	$("#fileUrl3").html(rows[0].fileUrl);
	
	
	$("#replayContent3").val(rows[0].replayContent);
	$("#newproductId3").val(rows[0].newproductId);
	
	$("#detailForStockoutId").window("open");
}

function detailForStockoutCommit(){
	var replayContent  =  $("#replayContent3").val();
	var newproductId  = $("#newproductId3").val();
	
	apply(replayContent, newproductId);
	detailForStockoutCancle();
	$("#feedsbacktable").datagrid('reload');
}
//关闭缺货货源详情窗口
function detailForStockoutCancle(){
	$("#detailForStockoutId").window("close");
};


function apply(replayContent, newproductId){
	
	$.ajax({
		url : "/admin/goodsfeedback/apply.htm",
		async : false,
		type : 'post',
		data : {
			'_method' : 'put',
			'replayContent':replayContent,
			'newproductId':newproductId
		},
		dataType : 'json',
		success : function(data) {
			if (data.success) {
				$.messager.alert('提示',data.msg);
			} else {
				$.messager.alert('警告', data.msg);
			}
		}
	});
	
}


function deleteGoodsFeedsbackProduct(){
	var rows = $('#feedsbacktable').datagrid('getSelections');
	if (rows == null || rows.length == 0) {
		$.messager.alert('警告', '请先选择一条记录再点击删除');
		return;
	}
	
	var newProductIds="";
	for ( var i = 0; i < rows.length; i++) {
		if(rows[i].status == 1){
		}
		newProductIds=newProductIds+rows[i].newproductId+",";
	}
	
	$.messager.confirm('系统提示', '你确定要删除该记录吗?',
			function(ok) {
				if (ok) {
					$.ajax({
						url : "/admin/goodsfeedback/delete.htm",
						async : false,
						type : 'post',
						data : {
							'_method' : 'put',
							'newproductIds':newProductIds
						},
						dataType : 'json',
						success : function(data) {
							if (data.success) {
								$.messager.alert('提示',data.msg);
							} else {
								$.messager.alert('警告', data.msg);
							}
						}
					});
					
					$("#feedsbacktable").datagrid('reload');
				}
	});	
}




function initAmountOrCount() {
	// 添加、减少数量
	$("input.amountOrCount")
			.live(
					'keydown',
					function(e) {
						var keyCode = e.keyCode ? e.keyCode : e.which ? e.which
								: e.charCode;
						if (keyCode == 13) {
							return true;
						}
						sk = e.shiftKey ? e.shiftKey : ((keyCode == 16) ? true
								: false);
						if (sk)
							return false;
					
					}).live('focus', function(event) {

				//$(this).val('');

			}).live('blur', function(event) {
//				this.value=this.value.replace(/\D/g,'');
//
//				$(this).val(Math.round(this.value));
//				if ($(this).val() < 0)
//					$(this).val(0);
//				if ($(this).val() > 99999)
//					$(this).val(99999);
			}).live('keyup', function() {
				this.value=this.value.replace(/\D/g,'');

				if ($(this).val() > 99999)
					$(this).val(99999);
			});

	

}
