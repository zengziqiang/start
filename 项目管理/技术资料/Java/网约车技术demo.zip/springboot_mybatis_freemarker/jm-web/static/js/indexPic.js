
//初始化对联
function initDuilian(){
	var duilian = $("div.duilian");
	var duilian_close = $("a.duilian_close");
	
	var window_w = $(window).width();
	if(window_w>1000){duilian.show();}
	$(window).scroll(function(){
		var scrollTop = $(window).scrollTop();
		duilian.stop().animate({top:scrollTop+260});
	});
};	

$(document).ready(function() {
	initDuilian();
	
	//三个选项卡到位
	$('.tabus_box div a img,.left_img a img').hover(function(){
		$(this).css('opacity',0.7);	
	},function(){
		$(this).css('opacity',1);	
	});
	$('.tabus').children('div').children('span').mouseover(function(){
		$(this).parent('div').children('span').removeClass('tabchoose tabright_choose ad_choose');
		$(this).addClass('tabchoose tabright_choose ad_choose');
		$(this).parent('div').parent('div').children('div').hide();
		$(this).parent('div').parent('div').children('div').eq(0).show();
		var tab_bum=$(this).parent('div').children('span').index(this)+1;
		$(this).parent('div').parent('div').children('div').eq(tab_bum).show();
		
	})
	$('.tabus1').children('div').children('div').children('span').mouseover(function(){
		$(this).parent('div').children('span').removeClass('ad_choose');
		$(this).addClass('ad_choose');
		$(this).parent('div').parent('div').parent('div').children('div').hide();
		$(this).parent('div').parent('div').parent('div').children('div').eq(0).show();
		
		var tab_bum=$(this).parent('div').children('span').index(this)+1;
		$(this).parent('div').parent('div').parent('div').children('div').eq(tab_bum).show();
	})
	//表格效果
	   $('.table-03 tr:even').addClass('alt');
   	   $('.table-03 tr').mouseover(function(){$(this).addClass('over')}).mouseout(function(){$(this).removeClass('over')})
	
	// 添加、减少数量
	$("input.price").css({'ime-mode':'disabled'});
	$("input.price").live('keydown',function(e){
		var keyCode = e.keyCode ? e.keyCode : e.which ? e.which : e.charCode;
		sk = e.shiftKey?e.shiftKey:((keyCode == 16)?true:false);
		if (sk)return false;
		if(!(keyCode==46)&&!(keyCode==8)&&!(keyCode==9)&&!(keyCode==37)&&!(keyCode==39))
			if(!((keyCode>=48&&keyCode<=57)||(keyCode>=96&&keyCode<=105)))
			 return false;
	}).live('blur',function(event){
		$(this).val(Math.round(this.value));
		if ($(this).val()<1)$(this).val(1);
		if ($(this).val()>99999)$(this).val(99999);
	}).live('keyup',function(){
		if ($(this).val()<1)$(this).val(1);
		if ($(this).val()>99999)$(this).val(99999);
	});
	$('a.minus').live('click',function(){$(this).siblings('input').val()>1?$(this).siblings('input').val(parseInt($(this).siblings('input').val())-1):1;});
	$('a.plus').live('click',function(){
		
		if ($(this).siblings('input').val()>99998){$(this).siblings('input').val(99999);}
		else{
			$(this).siblings('input').val(parseInt($(this).siblings('input').val())+1);
		}
	});
	$('.check_id:checked').siblings('span').addClass('car_b_select');
	$('.check_id').click(function(){
		if($(this).attr('checked')=='checked'){
			$(this).siblings('span').addClass('car_b_select');
			
		}else{
			$(this).siblings('span').removeClass('car_b_select');
		}
	
	
	});
	var n=3;
	
	$('.message_l:lt('+n+')').show();
	$('.message_l:odd').addClass('bs')
	$('.message_dot .dot').mouseover(function(){
		$('.message_dot .dot').removeClass('now_in');
		$(this).addClass('now_in');
		if($(this).index()==1){
			$('.message_l').hide();
			$('.message_l:lt('+n+')').show();
		 }
		else if($(this).index()==$('.message_dot .dot:last').index()){
			$('.message_l').hide();
			var m=$('.message_l:last').index()-n;
		
			$('.message_l:gt('+m+')').show();
		 }else{
			 var m=$('.message_l:last').index()-n;
			 $('.message_l').show();
			 var x=n*($(this).index()-1);
			 $('.message_l:lt('+n+')').hide();
			 $('.message_l:gt('+m+')').hide();
		 }
		 
		});
});		  
/*首页广告效果*/
$(function(){});

function initPic(){
    var len  = $(".slider > li").length;
	 var strtemp="",str="";
	for(i=1;i<=len;i++){strtemp+='<li>'+i+'</li>'};
	 str='<ul class="num">'+ strtemp +'</ul>';
	 $('.slider').after(str);
	 var index = 0;
	 var adTimer;
	 $(".num li").mouseover(function(){
		index  =   $(".num li").index(this);
		showImg(index);
	 }).eq(0).mouseover();	
	 //滑入 停止动画，滑出开始动画.
	 $('.ad').hover(function(){
			 clearInterval(adTimer);
		 },function(){
			 adTimer = setInterval(function(){
			    showImg(index)
				index++;
				if(index==len){index=0;}
			  } , 3000);
	 }).trigger("mouseleave");
}
// 通过控制top ，来显示不同的幻灯片
function showImg(index){
        var adHeight = $(".content_right .ad").height();
		$(".slider").stop(true,false).animate({bottom : -adHeight*index},1000);
		$(".num li").removeClass("on").eq(index).addClass("on");
}
//弹出层方法
/*
 * @auther ediosn
   @showBg(dialogdiv,w,h)
   dialogdiv //要显示的层绑定ID，在这里不用写#号
   w  //       要显示层的宽度
   h  //       要显示层的高度
   closeBg(dialogdiv)
   dialogdiv// 要关闭的层


*/

	function showBg(dialogdiv,w,h) {
		if ($.browser.msie && ($.browser.version == "6.0") && !$.support.style){ 
		var domThis = $(dialogdiv)[0];
        var wh = $(window).height() / 2;
        $("body").css({
            "background-image": "url(about:blank)",
            "background-attachment": "fixed"
        });
        domThis.style.setExpression('top', 'eval((document.documentElement).scrollTop + ' + wh + ' -30) + "px"');
		
		} 
       var bh = $("body").height();
       var bw = $("body").width();
        $("#fullbg").css({
            height: bh,
            width: bw,
            display: "block"
        });
		var str="position: fixed !important;position: absolute; "
		$(dialogdiv).attr('style',str);
		
		$(dialogdiv).css({
			height: h,
            width: w,
			left: '50%',
			top:'50%',
			marginLeft:-0.5*w,
			marginTop:-0.5*h,
			zIndex:16000
         	
        });
		
        
		$(dialogdiv).show();
    }
    //关闭灰色 jQuery 遮罩
    function closeBg(dialogdiv) {
        $("#fullbg").hide();
		$(dialogdiv).hide();
    }
	$(window).resize(function() {
	   var bh = $("body").height();
       var bw = $("body").width();
 	   if($('#dialog').css('display')=='block'){
		 $("#fullbg").css({
            height: bh,
            width: bw
        });  
		   
	   }
});
	