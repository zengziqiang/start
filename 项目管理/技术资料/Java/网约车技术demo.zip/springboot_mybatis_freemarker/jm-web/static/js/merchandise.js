

var merchandiseCallbackFn;
var isFirstRun = true;
var options;

function merchandiseInit(callback, initOptions){
	merchandiseCallbackFn = callback;
	options = initOptions || {};
	if(!options.showMemberPrice){
		options.showMemberPrice = false;
	}
}

function merchandiseOpen(){
	$('#merchandiseSelectWindow').window({  
	    width:800,  
	    height:500,  
	    modal:true,
	    collapsible:false,
	    minimizable:false,
	    resizable:true,
	    maximizable:false,
	    closable:true,
	    closed:true,
	    position : 'fixed',
	    title:'选择药品',
	    shadow : false
	});	
	$('#merchandiseSelectWindow').window('center');
	
	$('#merchandise_keyword').searchbox('setValue', '');
	$('#merchandise_chuffl').val('');
	$('#merchandise_jixing').val('');
	$('#merchandise_xkjylb').val('');
	$('#merchandise_date1').datebox('getValue', '');
	$('#merchandise_date2').datebox('getValue', '');	
	
	if(isFirstRun){
		$('#merchandiseSelectTable').datagrid(
				{
					fit : true,
					nowrap : true,
					striped : true,
					fitColumns : false,
					rownumbers: true,
					toolbar:'#merchandise_tb',
					loadMsg : '数据加载中请稍后……',
					url : '/search/pick_merchandise.htm',
					method : 'post',
					pageSize : 10,
					pageNumber : 1,
					pagination : true,
					singleSelect : false,
					idField : 'merchandise_id',
					queryParams: {
						options : options
					},
					frozenColumns : [ [ {
						field : 'merchandise_id',
						checkbox : true
					} ] ],
					columns : [ [
					             	{
					             		field : 'passfile_number',
					             		hidden : true
					             	},{
					             		field : 'note',
					             		title : '采购备注',
					             		hidden : true,
					             		formatter : function(value) { return value ? value : "无";}
					             	},
									{
										field : 'orgmerchandise_code',
										title : '药品编码',
										align : 'left',
										resizable : true,
										width:100,
										formatter : function(value) { return value ? value : ""; }
									},
									{
										field : 'merchandise_name',
										title : '药品名称',
										align : 'left',
										resizable : true,
										width:150,
										formatter : function(value) { return value ? value : ""; }
									},
									{
										field : 'merchandise_spec',
										title : '规格',
										align : 'left',
										resizable : true,
										width:100,
										formatter : function(value) { return value ? value : ""; }
									},
									{
										field : 'manufacturer',
										title : '厂家',
										align : 'left',
										resizable : true,
										width:150,
										formatter : function(value) { return value ? value : ""; }
									},
									{
										field : 'packing_number',
										title : '中/大包装',
										align : 'left',
										resizable : true,
										width:60,
										formatter : function( value, row, index) { 
											return (row.middling_packing ? row.middling_packing:"") + "/" + (row.packing_number ? row.packing_number:"");
										}
									},
									{
										field : 'storage_number',
										title : '库存',
										align : 'left',
										resizable : true,
										width:60,
										formatter : function( value) { 
											return (value && value>0)? (value>100?">100":"有"):"无";
										}
									},
									{
										field : 'retail_price',
										title : '零售价',
										align : 'left',
										resizable : true,
										width:60,
										formatter : function(value) { return value ? value : ""; }
									},
									{
										field : 'member_price',
										title : '会员价',
										align : 'left',
										resizable : true,
										width:60,
										hidden : true,
										formatter : function(value) { return value ? value : ""; }
									},
									{
										field : 'merchandise_unit',
										title : '单位',
										align : 'left',
										resizable : true,
										width:50,
										formatter : function(value) { return value ? value : ""; }
									},
									{
										field : 'chuffl',
										title : '处方类',
										align : 'left',
										resizable : true,
										width:50,
										formatter : function(value) { return value ? value : ""; }
									},
									{
										field : 'jingyjm',
										title : '基药类',
										align : 'left',
										resizable : true,
										width:50,
										formatter : function(value) { return value ? value : 0; }
									}
					] ]
			
				});
		isFirstRun = false;
	}else{
		$('#merchandiseSelectTable').datagrid('clearChecked');
		merchandiseReLoad();
	}
	if(options.showMemberPrice){
		$('#merchandiseSelectTable').datagrid('showColumn', 'member_price');
	}
	$('#merchandiseSelectWindow').window('open');
	$('#merchandiseSelectWindow').css('display','');
}

function merchandiseBtnOK(){
	$('#merchandiseSelectWindow').window('close');
	merchandiseCallbackFn($('#merchandiseSelectTable').datagrid('getChecked'));
}

function merchandiseBtnCancle(){
	$('#merchandiseSelectWindow').window('close');
}

function merchandiseReLoad(){
    $("#merchandiseSelectTable").datagrid('load', {
    	keyword : $('#merchandise_keyword').searchbox('getValue'),
    	chuffl : $('#merchandise_chuffl').val(),
    	jixing : $('#merchandise_jixing').val(),
    	xkjylb : $('#merchandise_xkjylb').val(),
    	date1 : $('#merchandise_date1').datebox('getValue'),
    	date2 : $('#merchandise_date2').datebox('getValue'),
    	options : options
	}); 
}

/*******************************************************************************
 * 获取药品数据
 * 
 */
function getMerchandiseTable() {


}


/****
* 在搜索结果中进行二次查找
*/
function searchMerchandise(){
	var keyword = $("#keyword").val();
	var category = $("#category").val();
	var storage = $("#storage").val();
	//var price = $("#price").val();
	var keyword2 = $("#keyword2").val();
	var level1Name = $("#level1Name").val();
	var level2Name = $("#level2Name").val();
	var level3Name = $("#level3Name").val();
	var yibao = $("#yibao").val();
	var isjiyao = $("#isjiyao").val();
	var merchandise_type = $("#merchandise_type").val();
	var isAddedMerchandise = $("#isAddedMerchandise").val();
	
	//二次需求增加的搜索条件
	var isShowForList = $("#isShowForList").val();
	var popularityToSort = $("#popularityToSort").val();
    var storageToSort = $("#storageToSort").val();
    var isPromotion = $("#isPromotion").val();
    var isYiBao = $("#isYiBao").val();
    var isZhanXiaoHui = $("#isZhanXiaoHui").val();
    var isHistory = $("#isHistory").val();
    var isLianMeng = $("#isLianMeng").val();
    var isJiFen = $("#isJiFen").val();
	
	var links = "/search/merchandise.htm?keyword="+keyword+"&category="+category+"&level1_name="+level1Name
				+"&level2_name="+level2Name+"&level3_name="+level3Name+"&storage="+storage
				//+"&price="+price
				+"&keyword2="+keyword2
				+"&yibao="+yibao+"&isjiyao="+isjiyao+"&merchandise_type="+merchandise_type
				+"&isAddedMerchandise="+isAddedMerchandise
				+"&isShowForList="+isShowForList+"&popularityToSort="+popularityToSort
				+"&storageToSort="+storageToSort+"&isPromotion="+isPromotion
				+"&isYiBao="+isYiBao+"&isZhanXiaoHui="+isZhanXiaoHui
				+"&isHistory="+isHistory+"&isLianMeng="+isLianMeng
				+"&isJiFen="+isJiFen;
	window.location.href=encodeURI(links);
}

///**
// * 进行异步加载药品信息 设置加载的时间
// * @param merchandiseId
// */
//function mouseOverMerchandise(merchandiseId){
//	
//	 var handle = null;
//	 $(".div"+merchandiseId).mouseover(function () {
//	     handle = setTimeout(loadMerchandiseById(merchandiseId), 5000);
//	 }).mouseout(function () {
//	     clearTimeout(handle);
//	 });
//	
//	
//}

/**
 * 根据ID进行异步加载药品信息
 * @param merchandiseId
 */
function loadMerchandiseById(merchandiseId){
	var url  ="/merchandise/oneMerchandise.json?"+Math.random();
	//jsonData = "array=[{merchandise_id:"+merchandiseId+"}]";
	jsonData = "merchandise_id="+merchandiseId;
	var clazz = $("#merchandiseAjax").attr("class");
	if(clazz!='float_img'){
	$.ajax({
		  type : "GET",                 
		  url: url,
		  data:jsonData,
		  async:false,
		  success: function(data){
			  var json = parserToJson(data);
			  var merchandiseImagePath = json.merchandiseImagePath;
			  var orgmerchandiseCode = json.merchandise.orgmerchandiseCode;
			  var branchId = json.merchandise.branchId;
			  var retail ="否";
			  if(json.merchandise.retail==1){
				  retail = "是";
			  }
			  var yibao ="其它";
			  var isYiBao = "否";
			  if(json.merchandise.chuffl =="AC"){
				  yibao="甲类";
				  isYiBao = "是";
			  }else if(json.merchandise.chuffl =="AD"){
				  yibao="乙类";
				  isYiBao = "是";
			  }else if(json.merchandise.chuffl =="AB"){
				  yibao="处方药";
				  isYiBao = "是";
			  }
			  
			  var isJiYao = "否";
			  if(json.merchandise.isYbsp == '4' || json.merchandise.isYbsp == '5'){
				  isJiYao = "是";
			  }
			  
			  var currencyName = json.merchandise.currencyName;
			  var start = currencyName.indexOf("/")+1;
			  
			  var temp = null;
			  if(branchId=="J19" || branchId=="J45" || branchId=="J47"){
				  temp ='<div class="float_img" id="merchandiseAjax"><img onerror=this.src="/static/images/nophoto.png" src="'+merchandiseImagePath+substrVal2(orgmerchandiseCode,11)+'/'+substrVal2(orgmerchandiseCode,11)+'.JPG" width="150" height="113" /></div>'
			  		+'<div class="float_font">'
			  		+'<p>商品编码：'+orgmerchandiseCode +'</p>'
			  		+'<p>规格：'+currencyName.substr(start) +'</p>'
			  		+'<p>批准文号：'+json.merchandise.passfileNumber+'</p>'
			  		//+'<p>销售类别：未知</p>'
			  		+'<p>是否拆零：'+retail+'</p>'
			  		+'<p>是否医保：'+isYiBao+'</p>'
			  		+'<p>处方分类：'+yibao+'</p>'
			  		+'<p>是否基药：'+isJiYao+'</p>'
			  		+'<p>产地名：'+json.merchandise.producingName+'</p>'
			  		+'<p>有效期：'+json.merchandise.fvalidity+'</p>'
			  		+'</div>';
			  }else{
				  temp ='<div class="float_img" id="merchandiseAjax"><img onerror=this.src="/static/images/nophoto.png" src="'+merchandiseImagePath+substrVal2(orgmerchandiseCode,11)+'/'+substrVal2(orgmerchandiseCode,11)+'.JPG" width="150" height="113" /></div>'
			  		+'<div class="float_font">'
			  		+'<p>商品编码：'+orgmerchandiseCode +'</p>'
			  		+'<p>规格：'+currencyName.substr(start) +'</p>'
			  		+'<p>批准文号：'+json.merchandise.passfileNumber+'</p>'
			  		//+'<p>销售类别：未知</p>'
			  		+'<p>是否拆零：'+retail+'</p>'
			  		+'<p>是否医保：'+isYiBao+'</p>'
			  		+'<p>处方分类：'+yibao+'</p>'
			  		+'<p>是否基药：'+isJiYao+'</p>'
			  		+'<p>产地名：'+json.merchandise.producingName+'</p>'
			  		+'<p>近效期：'+json.merchandise.sfDzjg+'</p>'
			  		+'<p>远效期：'+json.merchandise.fvalidity+'</p>'
			  		+'</div>';
				 
				  
			  }
			 
			 $(".all_product_div").html(temp);
		  }
	});
	}
}

function sortMerchandiseByMemberPrice(isAsc){
	
	
	var isLogin = $("#isLogin").val();
	
	if(isLogin == null || isLogin =='false'){
		return;
	}
	
	var merchandiseList ;
	var member_price_list ;
	
	var isShowForList = $("#isShowForList").val();
	
	if(isShowForList != null && isShowForList =='true'){
		//来自于列表页面
		merchandiseList = $('.all_product_imglist');
		member_price_list = merchandiseList.find('.member_price');
	}else{
		//默认来自于图片列表页面
		merchandiseList = $('.all_product_imglist_for_picture');
		member_price_list = merchandiseList.find('.member_price_for_picture');
	}
	
	
	var arrayPrice=[];
	var arrayMerchandise=[];
	var arrayPriceSequence=[];
	
	if(member_price_list != null && member_price_list.length != 0){
		for(i=0;i<member_price_list.length;i++){
			var price = Number(member_price_list[i].innerHTML);
			if(isNaN(price)){
				price = 0;
//				return ;
			}
			arrayPrice[i]=price;
			arrayMerchandise[i]=merchandiseList[i].innerHTML;
		}
		//进行价格排序, 获得排序时对应的顺序
		for(j=0;j<arrayPrice.length;j++){
			var sequence =0;
			for(k=0;k<arrayPrice.length;k++){
				if(j != k){
					if(arrayPrice[j]>arrayPrice[k]){
						sequence = sequence+1;
					}else{
						if(arrayPrice[j] == arrayPrice[k] &&  k<j){
							sequence = sequence+1;
						}
						
					}
					
				}
			}
			arrayPriceSequence[sequence] = j;
		}	
		
	}
	
	if(arrayPriceSequence != null && arrayPriceSequence.length > 0){
		var merchandiseString ;
		if(isAsc){
			for(i=0;i<arrayPriceSequence.length;i++){
				var index=arrayPriceSequence[i];
				merchandiseString = arrayMerchandise[index];
				
				
				if(isShowForList != null && isShowForList =='true'){
					//来自于列表页面
					$($('.all_product_imglist')[i]).html(merchandiseString);
				}else{
					//默认来自于图片列表页面
					$($('.all_product_imglist_for_picture')[i]).html(merchandiseString);
				}
			}
		}else{
			for(i=arrayPriceSequence.length-1;i>=0;i--){
				var index=arrayPriceSequence[i];
				merchandiseString = arrayMerchandise[index];
				
				
				if(isShowForList != null && isShowForList =='true'){
					//来自于列表页面
					$($('.all_product_imglist')[arrayPriceSequence.length-1-i]).html(merchandiseString);
				}else{
					//默认来自于图片列表页面
					$($('.all_product_imglist_for_picture')[arrayPriceSequence.length-1-i]).html(merchandiseString);
					
				}
				
				
				
			}
		}
		
	}
	return;
}



function sortMerchandiseByManufacturer(isAsc){
	
	var merchandiseList ;
	var manufacturerList ;
	
	var isShowForList = $("#isShowForList").val();
	
	if(isShowForList != null && isShowForList =='true'){
		//来自于列表页面
		merchandiseList = $('.all_product_imglist');
		manufacturerList = merchandiseList.find('.all_changj');
	}else{
		//默认来自于图片列表页面
		merchandiseList = $('.all_product_imglist_for_picture');
		manufacturerList = merchandiseList.find('.chang');
	}
	
	
	var arrayManufacturer=[];
	var arrayMerchandise=[];
	var arrayManufacturerSequence=[];
	
	if(manufacturerList != null && manufacturerList.length != 0){
		for(i=0;i<manufacturerList.length;i++){
			var manu = manufacturerList[i].innerHTML;
			if(manu == null || manu == undefined){
				manu = "";
			}
			arrayManufacturer[i]=manu.replace(/\s/g,"");
			arrayMerchandise[i]=merchandiseList[i].innerHTML;
		}
		//进行价格排序, 获得排序时对应的顺序
		for(j=0;j<arrayManufacturer.length;j++){
			var sequence =0;
			for(k=0;k<arrayManufacturer.length;k++){
				if(j != k){
					if(arrayManufacturer[j]>arrayManufacturer[k]){
						sequence = sequence+1;
					}else{
						if(arrayManufacturer[j] == arrayManufacturer[k] &&  k<j){
							sequence = sequence+1;
						}
						
					}
					
				}
			}
			arrayManufacturerSequence[sequence] = j;
		}	
		
	}
	
	if(arrayManufacturerSequence != null && arrayManufacturerSequence.length > 0){
		var merchandiseString ;
		if(isAsc){
			for(i=0;i<arrayManufacturerSequence.length;i++){
				var index=arrayManufacturerSequence[i];
				merchandiseString = arrayMerchandise[index];
				
				
				if(isShowForList != null && isShowForList =='true'){
					//来自于列表页面
					$($('.all_product_imglist')[i]).html(merchandiseString);
				}else{
					//默认来自于图片列表页面
					$($('.all_product_imglist_for_picture')[i]).html(merchandiseString);
				}
			}
		}else{
			for(i=arrayManufacturerSequence.length-1;i>=0;i--){
				var index=arrayManufacturerSequence[i];
				merchandiseString = arrayMerchandise[index];
				
				
				if(isShowForList != null && isShowForList =='true'){
					//来自于列表页面
					$($('.all_product_imglist')[arrayManufacturerSequence.length-1-i]).html(merchandiseString);
				}else{
					//默认来自于图片列表页面
					$($('.all_product_imglist_for_picture')[arrayManufacturerSequence.length-1-i]).html(merchandiseString);
					
				}
				
				
				
			}
		}
		
	}
	return;
}


//将光标聚焦到keyword关键字上
function focusTheKeyword(){
	$('#keyword').focus();
	var keyword = $('#keyword').val();
	$('#keyword').val('');
	$('#keyword').val(keyword);
}








