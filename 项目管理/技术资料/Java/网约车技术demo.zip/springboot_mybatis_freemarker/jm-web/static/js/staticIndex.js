﻿$(document).ready(function() {
	
	var ids = '';
	$.each($('[indexMerchandise=true]'),function(i,row){
		ids=ids+$(row).attr('merchandiseId')+",";
	});
	 duilianopen();
	$.ajax({
		url: "/indexData.json",
		type: "GET",
		data:{ids:ids},
		async: true,
		cache: false,
		success: function(data) {
			data = parserToJson(data);
			//浮动弹出框
			if(data != null && data.user != null){
				if(data.isLeagueCust){
					$('#isLeagueCust').attr('href','javascript:void(0);');
					$('#isLeagueCust').attr('onclick','leagueCust()');
					$('#isLeagueCust').html("<span>众创联盟</span>");
				}
				
				$('#top_right_login').show();
				if(data.user.userType==2){
					var attentionCont = data.attentionCont;
					var dbasketItemContDao = data.dbasketItemContDao;
					var zixunhuifu = data.zixunhuifu;
					var quality = data.custQuality;
					var isShowMessage = data.isShowMessage;
					var message = data.message;
					var saleFairsInfoMessage=data.saleFairsInfoMessage;
					tantishi(attentionCont,dbasketItemContDao,zixunhuifu,quality,isShowMessage,message,saleFairsInfoMessage);
					
				}
			}
			//判断展销会
			if(data.isSaleFairsInfo==1){
				$("#isSaleFairsInfo").css("display","block");
				$('#isSaleFairsInfo').attr('href','/sale/fairs/indexRoom.htm?roomId=11');
				$('#isSaleFairsInfo').html("<span>展销会</span>");
				if(data.isSaleFairsInfoActivity==1){//只有展会信息
					$('#isSaleFairsInfoActivity').html("<a href='/sale/fairs/indexRoom.htm?roomId=11'><span>展会信息</span></a>");
				}else if(data.isSaleFairsInfoActivity==2){//展会信息和展会活动都有
					$('#isSaleFairsInfoActivity').html("<a href='/sale/fairs/indexRoom.htm?roomId=11'><span>展会信息</span></a>|<a href='/sale/fairs/indexRoom.htm?roomId=10'><span>展会活动</span></a>");
				}
				/*$('#isSaleFairsInfo').html("<a href='/sale/fairs/indexRoom.htm?roomId=11'><span>展销会</span></a>");
				if(data.isSaleFairsInfoActivity==1){//只有展会信息
					$('#isSaleFairsInfo').html("<a href='/sale/fairs/indexRoom.htm?roomId=11'><span>展销会</span></a>" +
							"<div class='nav_m_d'><a href='/sale/fairs/indexRoom.htm?roomId=11'><span>展会信息</span> </a></div>");
				}else if(data.isSaleFairsInfoActivity==2){//展会信息和展会活动都有
					$('#isSaleFairsInfo').html("<a href='/sale/fairs/indexRoom.htm?roomId=11'><span>展销会</span></a>" +
					"<div class='nav_m_d'><a href='/sale/fairs/indexRoom.htm?roomId=11'><span>展会信息</span></a>" +
					"|<a href='/sale/fairs/indexRoom.htm?roomId=10'><span>展会活动</span></a></div>");
				}*/
			}
					
			
			
			//药品价格和库存
			$.each($('[indexMerchandise=true]'),function(i,row){
				
				$(row).text(data.merchandiseList[i].formatRetailPrice);
				if($(row).parent().parent().find('[indexMerchandiseStorage=true]').length>0){
					$(row).parent().parent().find('[indexMerchandiseStorage=true]').html(formatStorage(data.merchandiseList[i].showTactics,data.merchandiseList[i].merchandiseId));
				}
			});
			if(data.haveCartResource){
				$('#templateIndex').attr('href','/member/advice/replyConsult.htm');
			}
			if(data.isCustLogin){
				$('#pricesituation').attr('href','/member/statistics/pricesituation.htm');
				$('#fastPurchase').attr("onclick","addAdvice(0)");
			} else {
				$('#fastPurchase').attr("onclick","alert('请先登录！')");
			}
			if(data.isCustLogin && data.haveCartResource){
				$('.car_ctn').show();
			}
			
			//客户评价信息
			$(data.custServiceList).each(function(k,v){
				if(v.reply==null||v.reply=="null"){
					v.reply ="";
				}

				var html = 
				'<div class="message_r">'
				+'<div class="message_one" >'
				+'<p class="p_user"><b>用户:</b><span>'+v.custNameHidden+'</span></p> <P class="p_din">订单号：'+v.orderCodeHide+'</P><p class="p_time">评价时间：'+v.createDateString+'</p>'
				+'</div>'
				+'<div class="clearit"></div>'
				+'<div class="message_two">'
				+'<p title="'+v.content+'">评价：'+v.content+'</p>'
				+'</div>'
				+'<div class="message_three">'
				+'<p title="'+v.reply+'">回复：'+v.reply+'</p>'
				+'</div>'
				+'</div>';
				$('#custServiceDiv').append(html);
			});
			//网站访问量
			if(data.dayPV!=null&&data.allPV!=null){
				$("#allPV").text(data.allPV);
				$("#dayPV").text(data.dayPV);
			}
		}
	});
	
	init();
	
//屏蔽网站首页底部刷新订单状态 2015-04-01 limingshuai
//	loadOrderInfo();
	
	if($('.adver').length !=0){
			initAdver();
	}
});	



function initAdver(){
	$('.bigad_close').click(function(){
		$('.adver').hide();
		$("#fullbg").hide();
	});
   showBg('.adver','750','400');
}

//对联卷轴效果
function duilianopen(){

	$(".duilian").animate({height:'352px'},"slow");

		var duilian = $("div.duilian");
		var duilian_close = $("a.top_ad_close1");
		
		var window_w = $(window).width();
		if(window_w>1000){duilian.show();}
		$(window).scroll(function(){
			var scrollTop = $(window).scrollTop();
			duilian.stop().animate({top:scrollTop+150});
		});
		duilian_close.click(function(){
			$(this).parent().hide();
			return false;
		});
		
		
		};


function init(){
	$('.top_ad_close').click(function(){$('.top_ad').hide();}) 
		
	 var liW = $("#actor li:first").width();
	 var liL = $("#actor li").length;
	   var lis = $("#actor li").length;
	  $("#bnt li").each(function(index) {
	   $(this).click(function(){
	    if($("#actor").is(":animated")==false){
	     $("#actor").animate({"marginLeft":-index*liW},500,function(){
	     $("#bnt li").removeClass("sli");
	     $("#bnt li").eq(index).addClass("sli");
	     });
	      };
	    });
	        });
	  settime=window.setInterval(atuoScroll,10000);
	  $("#box").hover(function(){
	  window.clearInterval(settime);
	  },function(){
	  settime=window.setInterval(atuoScroll,10000);
	 });
	
	  //绑定对联JS事件
	  $(window).scroll(function(){
		  $(window).unbind('scroll');
		  $(window).scroll(
					function() {
						
						var h = (document.documentElement.scrollTop ? document.documentElement.scrollTop : document.body.scrollTop) + document.documentElement.clientHeight - $("#message").height()
		                if (h < document.body.offsetHeight) {
		                    $("#message").css('top', h + 'px')
							
		                }
		                else {
		                    $("#message").css('top', document.body.offsetHeight + 'px')
							
		                }
					});
			if($('#duilian_left').length !=0 && $('#duilian_right').length !=0){
				initDuilian();
			}
			var bt = $('#toolBackTop');
			var sw = $(document.body)[0].clientWidth;
			var limitsw = (sw - 1060) / 2 - 40;
			if (limitsw > 0) {
				limitsw = parseInt(limitsw);
				bt.css("right", 0);
			}
			$(window).scroll(function() {
				//底部返回页面的固定
				var st = $(window).scrollTop();
				var _width = $(window).width(); 
			
				if (st > 500 && _width>1330) {
					bt.show();
				} else {
					bt.hide();
				}
				
				
				//顶部搜索框的固定
				var scrollTop = $(window).scrollTop();
				var tskeep;
				if($('.top_ad').css('display')=="none"){
					tskeep=170;
				}else{tskeep=340;};
				
		       if(scrollTop>tskeep){
		    	   $('.small_logo_area').show();
		       }else{
				   $('.small_logo_area').hide();
			   };
			});
		});
	  if($('#duilian_left').length !=0 && $('#duilian_right').length !=0){
		  $("a.duilian_close").click(function(){
				$(this).parent().hide();
				return false;
		  });
	  }
	  //表格效果
	 $('.table-03 tr').mouseover(function(){$(this).addClass('over')}).mouseout(function(){$(this).removeClass('over')});

	 
}

//初始化对联
function initDuilian(){
	var duilian = $("div.duilian");
	var duilian_close = $("a.duilian_close");
	
	$(window).scroll(function(){
		var scrollTop = $(window).scrollTop();
		duilian.stop().animate({top:scrollTop+260});
	});
};	

function initTab(){
	//三个选项卡到位
	$('.qlink span a').hover(function(){$(this).parent('span').addClass('newv')},function(){$(this).parent('span').removeClass('newv')});
	$('.tabus_box div a img,.left_img a img').hover(function(){
		$(this).css('opacity',0.7);	
	},function(){
		$(this).css('opacity',1);	
	});
$('.tabus').children('div').children('span').mouseover(function(){
		$(this).parent('div').children('span').removeClass('tabchoose tabright_choose ad_choose');
		$(this).addClass('tabchoose tabright_choose ad_choose');
		$(this).parent('div').parent('div').children('div').hide();
		$(this).parent('div').parent('div').children('div').eq(0).show();
		var tab_bum=$(this).parent('div').children('span').index(this)+1;
		$(this).parent('div').parent('div').children('div').eq(tab_bum).show();
	})
}

function atuoScroll(){
	  var liW = $("#actor li:first").width();
	  var liL = $("#actor li").length;
	  var ulM =parseInt( $("#actor").css("margin-left"));
	  
	  if(ulM==-((liL-1)*liW)&&$("#actor").is(":animated")==false){
	   $("#actor").stop();
	  $("#actor").animate({"marginLeft":0},500,function(){
	     $("#bnt li").removeClass("sli");
	     $("#bnt li:first").addClass("sli");   
	   });
	   }
	   
	  else if($("#actor").is(":animated")==false){
	  $("#actor").stop();
	  $("#actor").animate({"marginLeft":ulM-liW},500,function(){
	  var ulM =parseInt( $("#actor").css("margin-left"));
	  var num = -ulM/liW
	     $("#bnt li").removeClass("sli");
	     $("#bnt li").eq(num).addClass("sli");   
	   });
}
}
var isfirst = true;
var lastLogId;
function loadOrderInfo(){
	if(isfirst){
		isfirst = false;
		$.ajax({
			url: "/orderStateLog/listPageOrderStateLog.json",
			type: "GET",
			data:{lastLogId:lastLogId},
			async: false,
			cache: false,
			success: function(data) {
				data = parserToJson(data);
				var newover='';
				$(data.list).each(function(k,v){
					if(0 == k){
						lastLogId = v.logId
					}
					newover +='<li><span class="custname">'+v.custNameHidden+'</span><span class="orderCodeHide"><b>'+v.orderCodeHide+'</b></span>&nbsp;订单于<span class="time">'+v.createTimeString+'</span><span>'+v.orderStateText+'；</span> </li>';
				});
				$('#orderStateUl').prepend(newover);
			}
		});
	}else {
		$.ajax({
			url: "/orderStateLog/listPageOrderStateLog.json",
			type: "GET",
			data:{lastLogId:lastLogId},
			async: false,
			cache: false,
			success: function(data) {
				data = parserToJson(data);
				$(data.list).each(function(k,v){
					if(0 == k){
						lastLogId = v.logId
					}
					addover(v.custName,v.orderCodeHide,v.createTimeString,v.orderStateText);
				});
			}
		});
	}
		setTimeout(loadOrderInfo,10000);
}

//添加信息滚动
function addover(custName,orderCode,createTimeString,stateString){
	
	var newover='<li><span class="custname" title="'+custName+'">'+custName+'</span><span class="orderCodeHide"><b>'+orderCode+'</b></span>&nbsp;订单于<span class="time">'+createTimeString+'</span><span>'+stateString+'；</span> </li>';
	var mtnow=parseFloat($('#overarea').children('div').css('margin-top'));

	var mtnum=-(mtnow/24);
	
	var mtlod=(mtnow-20)+'px';
	

	$('#overarea').children('div').css('margin-top',mtlod);
	
	$('#overarea div').children('ul').prepend(newover);
	var vk=function(){$('#overarea').children('div').animate({marginTop:'0'}, 2000)};
	var kl=setTimeout(vk,mtnum);
	}

//众创联盟连接
function leagueCust(){
	//alert(123);
	$.ajax({   
		type : "post",   
		url : "/leagueCust/index.htm",   
		async : false,   
		success : function(text){  
			var data = parserToJson(text);
			if(data.success){
				//showdemo('ok',data.msg);
				window.location.href = "/leagueCust/home.htm";
				//SimplePop.confirm(data.msg,{width:"300px",title:"提示"});
			}else{
				SimplePop.confirm(data.msg,{width:"300px",title:"提示"});
			}
		}   
	});
}

function addAdvice(type){
	if(type==1){
		$("#titleNameId").html('在线投诉');
	}
	if(type==0){
		$("#titleNameId").html('建议咨询');
	}
	$("#type_add").val(type);
	
	showBg(bland2,600,350);
}

function submitAdvice(){
	if($("#addAdviceForm").form("validate")){	
		$('#addAdviceForm').attr("action","/member/advice/submitAdviceConsult.htm");
		$('#addAdviceForm').submit();
		
	};
}

//重置
function resetAdvice(){
	$("#title_add").val('');
	$("#adviceConsult_add").val('');
}

//取消
function cancleAdice(){
	$("#type_add").val('');
	$("#title_add").val('');
	$("#adviceConsult_add").val('');
	closeBg(bland2);
}




