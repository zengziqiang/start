function openFrame(url,centerTitile){
	var centerPanel = $('body').layout('panel','center');
	centerPanel.panel("setTitle",centerTitile);
	$('#centerFrame').attr('src',url);
};

String.prototype.trim=function()
{
     return this.replace(/(^\s*)(\s*$)/g, '');
};

Date.prototype.format = function(format) {
	/*
	 * eg:format="yyyy-MM-dd hh:mm:ss";
	 */
	if (!format) {
		format = "yyyy-MM-dd hh:mm:ss";
	}
	var o = {
		"M+" : this.getMonth() + 1, // month
		"d+" : this.getDate(), // day
		"h+" : this.getHours(), // hour
		"m+" : this.getMinutes(), // minute
		"s+" : this.getSeconds(), // second
		"q+" : Math.floor((this.getMonth() + 3) / 3), // quarter
		"S" : this.getMilliseconds()
	// millisecond
	};
	if (/(y+)/.test(format))
		format = format.replace(RegExp.$1, (this.getFullYear() + "")
				.substr(4 - RegExp.$1.length));
	for ( var k in o)
		if (new RegExp("(" + k + ")").test(format))
			format = format.replace(RegExp.$1, RegExp.$1.length == 1 ? o[k]
					: ("00" + o[k]).substr(("" + o[k]).length));
	return format;
};
/**
 * 日期格式话 dataStr:被格式话的日期字符串 format:日期格式
 */
formatDate = function(dataStr, format) {
	if(dataStr==undefined||dataStr==''||dataStr==null)
		return '';
	return new Date(dataStr.replace(/-/ig, '/')).format(format);
};
 
/**
 * 字符转换成json队形
 * @param strData
 * @returns
 */
function parserToJson(strData) {
	return (new Function("return " + strData))();
}

function htmlEncode ( input ) 
{ 
	var converter = document.createElement("DIV"); 
	converter.innerText = input; 
	var output = converter.innerHTML; 
	converter = null;
	if (typeof(input) == "undefined") return "暂无"; 
	return input; 
} 
function HTMLDecode ( input ) 
{ 
	var converter = document.createElement("DIV"); 
	converter.innerHTML = input; 
	var output = converter.innerText; 
	converter = null; 
	return output; 
}

//字符串截取 汉字占一个字符
function substrVal(val,length){
	if(val == null){
		return "";
	}
	if(val.length>length){
		return val.substr(0,length-1)+'...';
	}else {
		return val;
	}
}
//字符串截取 汉字占两个字符
function substrVal2(str,length){
		 var len=0;
		  for(var i=0;i<str.length;i++){
		    if (str.charAt(i)>'~')len+=2; else len++;
			if(len>length){
					return str.substr(0,i)+"...";
			}
		}
		return str;
}

//字符串截取，不带省略号
function substrVal2(val,length){
	if(val == null){
		return "";
	}
	if(val.length>length){
		return val.substr(0,length-1);
	}else {
		return val;
	}
}

//库存值格式化
function formatStorageNumber(number){
	if(number == null){
		return 0;
	}else if(number>100){
		return '>100';
	}else {
		return number;
	}
}

function setCookie(name,value,hours,path){   
    var name = escape(name);   
    var value = escape(value);   
    var expires = new Date();   
    expires.setTime(expires.getTime() + hours*3600000);   
    path = path == "" ? "" : ";path=" + path;   
    _expires = (typeof hours) == "string" ? "" : ";expires=" + expires.toUTCString();   
    document.cookie = name + "=" + value + _expires + path;   
}   
//获取cookie值    方法 
function getCookieValue(name){   
    var name = escape(name);   
    //读cookie属性，这将返回文档的所有cookie   
    var allcookies = document.cookie;          
    //查找名为name的cookie的开始位置   
    name += "=";   
    var pos = allcookies.indexOf(name);       
    //如果找到了具有该名字的cookie，那么提取并使用它的值   
    if (pos != -1){                                             //如果pos值为-1则说明搜索"version="失败   
        var start = pos + name.length;                  //cookie值开始的位置   
        var end = allcookies.indexOf(";",start);        //从cookie值开始的位置起搜索第一个";"的位置,即cookie值结尾的位置   
        if (end == -1) end = allcookies.length;        //如果end值为-1说明cookie列表里只有一个cookie   
        var value = allcookies.substring(start,end);  //提取cookie的值   
        return unescape(value);                           //对它解码         
        }      
    else return "";                                             //搜索失败，返回空字符串   
}   

