/******************** 菜单 相关操作 开始*****************************/
//初始化加载菜单列表
function loadSalesManMenuList(){
	$('#salesManMenuTab').datagrid({
		fit : true,
		striped : true,//True 就把行条纹化。（即奇偶行使用不同背景色）
		fitColumns : true,//True 就会自动扩大或缩小列的尺寸以适应表格的宽度并且防止水平滚动。
		url : '/admin/salesManRole/salesManMenuList.json',
		method : 'post',
		pageSize : 10,
		pageNumber : 1,
		pagination : true,
		singleSelect : false,
		rownumbers : true,
		columns : [ [  
		    { title : '菜单ID', field : 'menuId', align : 'center', resizable : true,checkbox:true }, 
		    { title : '菜单名称', field : 'menuName', align : 'center', resizable : true }, 
		    { title : '菜单图片地址', field : 'menuPicUrl', align : 'center', resizable : true}, 
		    { title : '跳转链接地址', field : 'menuLink', align : 'center', resizable : true}, 
		    { title : '菜单备注', field : 'menuNote', align : 'center', resizable : true},
		    { title : '菜单状态', field : 'deleteFlag', align : 'center', resizable : true,
		    	formatter : function(value) {
		    		return value == '0' ? "启用" : "停用"; 
		    	}
		    },
		] ],
		toolbar:"#menuToolbar"
	});
}

//点击查询角色
function searchSalesManMenu(){
	$('#salesManMenuTab').datagrid('options').queryParams={
		//"linkMan":$("#linkMan").val()
	};
	$("#salesManMenuTab").datagrid('reload');
}

//点击新增菜单
function addSalesManMenu(){
	$("#addSalesManMenuWindow").panel({title:"新增菜单"});
	$("#addSalesManMenuWindow").window('open');
}

//点击修改菜单
function editSalesManMenu(){
	var selects = $('#salesManMenuTab').datagrid('getSelections');
	if(selects && selects.length == 1){
		selects = selects[0];
		if(selects.menuId!=null){$('#menuId').val(selects.menuId);}
		if(selects.menuName!=null){$('#salesManMenuName').val(selects.menuName);}
		if(selects.menuPicUrl != null) {$("#salesManMenuUrl").val(selects.menuPicUrl);}
		if(selects.menuLink != null) {$("#salesManMenuLink").val(selects.menuLink);}
		if(selects.menuNote != null){$("#salesManMenuNote").val(selects.menuNote);}
		if(selects.deleteFlag!=null){$('#menuDeleteFlag').combobox('setValue',selects.deleteFlag+'');}
		$("#addSalesManMenuWindow").panel({title:"修改菜单"});
		$("#addSalesManMenuWindow").window('open');
	}else{
		$.messager.alert('提示','请先选择一条记录再点击编辑');
	}
}

//确认新增或者修改菜单
function commitAddMenu(){
	if($("#salesManMenuForm").form("validate")){
		$.messager.confirm('系统提示', '您确定要设置菜单吗？', function(flag) {
			if(flag){
				$("#salesManMenuForm").form("submit",{
					url : '/admin/salesManRole/addSalesManMenu.json',
					dataType:'json',
				    success:function(text){  
				    	var data = parserToJson(text);
				    	if(data.success) {
				    		cancelAddMenu();
				    		$.messager.alert('提示',data.msg,'info');
				    		$("#salesManMenuTab").datagrid("reload");//重新加载菜单列表
				    	}else {
				    		$.messager.alert('发生错误',data.msg,'error');
				    	}
				    }
				});
			}else{
				return false;
			}
		});
	}
}


//取消新增菜单
function cancelAddMenu(){
	clearMenuForm();
	$("#addSalesManMenuWindow").window('close');
}

//清空菜单表单
function clearMenuForm(){
	$("#menuId").val('');
	$("#salesManMenuName").val('');
	$("#salesManMenuUrl").val('');
	$("#salesManMenuLink").val('');
	$("#salesManMenuNote").val('');
	$('#menuDeleteFlag').combobox('setValue',"0");
}

//点击删除菜单
function deleteSalesManMenu(){
	var selects = $('#salesManMenuTab').datagrid('getSelections');
	var menuIdS = null;
	if(selects && selects.length > 0){
		$.messager.confirm('提示','确定删除所选的 '+selects.length+' 条记录吗?',function(flag){
			if(flag){
				//获取选中menuIdS
				for(var i=0;i<selects.length;i++){
					if(menuIdS!=null){
						menuIdS = menuIdS + "," + selects[i].menuId ;
					}else{
						menuIdS = selects[i].menuId ;//选中的药品ID
					}
				}
				$.ajax({
					type:'post',
					url : '/admin/salesManRole/deleteSalesManMenu.json',
					cache:false,
					data:{
						menuIdS:menuIdS
					},
					dataType:'json',
					success:function(result){
						if(result.success){
							$.messager.alert('提示',result.msg,'info');
							$("#salesManMenuTab").datagrid("reload");//重新加载菜单列表
						}else{
							$.messager.alert('提示',result.msg,'error');
							return false;
						}
					}
				});
			}
		});
	}else{
		$.messager.alert('提示','请先选择一条记录再点击编辑');
	}
}

/******************** 菜单 相关操作 结束*****************************/



/******************** 角色 相关操作 开始*****************************/
//初始化加载角色列表
function loadSalesManRoleList(){
	$('#salesManRoleTab').datagrid({
		fit : true,
		striped : true,//True 就把行条纹化。（即奇偶行使用不同背景色）
		fitColumns : true,//True 就会自动扩大或缩小列的尺寸以适应表格的宽度并且防止水平滚动。
		url : '/admin/salesManRole/salesManRoleList.json',
		method : 'post',
		pageSize : 10,
		pageNumber : 1,
		pagination : true,
		singleSelect : false,
		rownumbers : true,
		columns : [ [  
		    { title : '角色ID', field : 'roleId', align : 'center', resizable : true,checkbox:true }, 
		    { title : '角色名称', field : 'roleName', align : 'center', resizable : true }, 
		    { title : '角色描述', field : 'roleDesc', align : 'center', resizable : true}, 
		    { title : '创建时间', field : 'createTimeStr', align : 'center', resizable : true},
		    { title : '拥有菜单ID', field : 'menuIdS', align : 'center', resizable : true, hidden:true},
		    { title : '拥有菜单', field : 'menuIdSName', align : 'center', resizable : true,
		    	formatter : function(value) {
		    		return value == null ? "无" : value; 
		    	}
		    },
		    { title : '状态', field : 'deleteFlag', align : 'center', resizable : true,
		    	formatter : function(value) {
		    		return value == '0' ? "启用" : "停用"; 
		    	}
		    }
		] ],
		toolbar:"#roleToolbar"
	});
}

//点击查询角色
function searchSalesManRole(){
	$('#salesManRoleTab').datagrid('options').queryParams={
		//"linkMan":$("#linkMan").val()
	};
	$("#salesManRoleTab").datagrid('reload');
}

//新增角色
function addSalesManRole(){
	$("#addSalesManRoleWindow").panel({title:"新增角色"});
	$("#addSalesManRoleWindow").window("open");
}

//点击修改角色
function editSalesManRole(){
	var selects = $('#salesManRoleTab').datagrid('getSelections');
	if(selects && selects.length == 1){
		selects = selects[0];
		if(selects.roleId!=null){$('#roleId').val(selects.roleId);}
		if(selects.roleName!=null){$('#salesManRoleName').val(selects.roleName);}
		if(selects.roleDesc != null) {$("#salesManRoleDesc").val(selects.roleDesc);}
		if(selects.deleteFlag!=null){$('#roleDeleteFlag').combobox('setValue',selects.deleteFlag);}
		$("#addSalesManRoleWindow").panel({title:"修改角色"});
		$("#addSalesManRoleWindow").window('open');
	}else{
		$.messager.alert('提示','请先选择一条记录再点击编辑');
	}
}


//验证角色名称唯一性
var nameYanFlag = false;
function addSalesManRoleYan(){
	var salesManRoleName = $.trim($("#salesManRoleName").val());
	if(salesManRoleName == null || salesManRoleName==''){
		nameYanFlag = false;
		return false;
	}
	var url = "/admin/salesManRole/salesManRoleNameValid.json?salesManRoleName="+salesManRoleName;
	$.get(url,function(data){
		if(data=="false"){
			//验证通过
			nameYanFlag = true;
			$("#yanzhengname").html("*");
		}else{
			//验证失败,用户名已经存在
			$("#yanzhengname").html("* 名称已经存在");
		}
	},"text");
}


//确认新增角色
function commitAddRole(){
	if($("#salesManRoleForm").form("validate")){
		$.messager.confirm('系统提示', '您确定要设置角色吗？', function(flag) {
			if(flag){
				$("#salesManRoleForm").form("submit",{
					url : '/admin/salesManRole/addSalesManRole.json',
					dataType:'json',
				    success:function(text){  
				    	var data = parserToJson(text);
				    	if(data.success) {
				    		$.messager.alert('提示',data.msg,'info');
				    		$("#salesManRoleTab").datagrid("reload");//重新加载菜单列表
				    		cancelAddRole();
				    	}else {
				    		$.messager.alert('发生错误',data.msg,'error');
				    	}
				    }
				});
			}else{
				return false;
			}
		});
	}
}



//取消新增角色
function cancelAddRole(){
	clearRoleForm();
	$("#addSalesManRoleWindow").window('close');
}

//清空菜单表单
function clearRoleForm(){
	$("#roleId").val('');
	$("#salesManRoleName").val('');
	$("#salesManRoleDesc").val('');
	$('#roleDeleteFlag').combobox('setValue','');
}

//指定角色功能
function setSalesManRole(){
	var selects = $('#salesManRoleTab').datagrid('getSelections');
	if(selects && selects.length == 1){
		
		$('#setRoleMenu').combobox({
		    required:true,
		    multiple:true,
		    url:'/admin/salesManRole/getSalesManMenuComboboxList.json', //
			editable:false,
			valueField:'id',   
			textField:'text'
		});
		
		selects = selects[0];
		if(selects.roleId!=null){$('#setRoleId').val(selects.roleId);}
		if(selects.roleName!=null){$('#setSalesManRoleName').val(selects.roleName);}
		if(selects.menuIdS!=null){
			var menuIdS = selects.menuIdS.split(",");
			$('#setRoleMenu').combobox('setValues',menuIdS);
			}
		$("#setSalesManRoleWindow").window('open');
		
	}else{
		$.messager.alert('提示','请先选择一条记录再点击编辑');
	}
}

//确认指定角色功能
function commitSetRoleMenu(){
	if($("#setRoleMenuForm").form("validate")){
		$.messager.confirm('系统提示', '您确定要指定该功能吗？', function(flag) {
			if(flag){
				$("#setRoleMenuForm").form("submit",{
					url : '/admin/salesManRole/commitSetRoleMenu.json',
					dataType:'json',
				    success:function(text){  
				    	var data = parserToJson(text);
				    	if(data.success) {
				    		cancelSetRoleMenu();
				    		$.messager.alert('提示',data.msg,'info');
				    		$("#salesManRoleTab").datagrid("reload");//重新加载菜单列表
				    	}else {
				    		$.messager.alert('发生错误',data.msg,'error');
				    	}
				    }
				});
			}else{
				return false;
			}
		});
	}
}

//取消指定却色功能
function cancelSetRoleMenu(){
	clearSetRoleMenu();
	$("#setSalesManRoleWindow").window('close');
}

//清除表单
function clearSetRoleMenu(){
	$("#setRoleId").val('');
	$("#setSalesManRoleName").val('');
	$('#setRoleMenu').combobox('setValue','');
}

/******************** 角色 相关操作 结束*****************************/









