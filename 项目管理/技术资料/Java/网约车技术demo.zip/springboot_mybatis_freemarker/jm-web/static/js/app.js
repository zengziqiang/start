var isNullRex = new RegExp("^[ ]+$");

function isNull(str) {
    if (!str) return true;
    if (str == "") return true;
    return isNullRex.test(str);
}

function numts(value) {
    if (isNaN(value) || value === undefined || value == '-') {
        return '-';
    }
    var theTime = parseInt(value);// 秒
    if (isNaN(theTime)) {
        return '-';
    }

    var theTime1 = 0;// 分
    var theTime2 = 0;// 小时
    // alert(theTime);
    if (theTime > 60) {
        theTime1 = parseInt(theTime / 60);
        theTime = parseInt(theTime % 60);
        // alert(theTime1+"-"+theTime);
        if (theTime1 > 60) {
            theTime2 = parseInt(theTime1 / 60);
            theTime1 = parseInt(theTime1 % 60);
        }
    }
    var result = padZero(parseInt(theTime));
    if (theTime1 > 0) {
        result = padZero(parseInt(theTime1)) + ":" + result;
    } else {
        result = "00:" + result;
    }
    if (theTime2 > 0) {
        result = padZero(parseInt(theTime2)) + ":" + result;
    }
    return result;
}

function padZero(num) {
    if (!isNaN(num)) {
        if (num.toString().length < 2) {
            return "0" + num
        } else {
            return num
        }
    }
    return "00"
}

function numt(num) {
    if (num === undefined || isNaN(num)) {
        return '-';
    }
    return (num + '').replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&,');
}

function nump(v) {
    if (v == '-' || v === undefined || isNaN(v)) {
        return '-';
    }
    return v + "%";
}

function numdate(javaTimestamp) {
    var timestamp = moment(new Date(parseInt(javaTimestamp)));
    return timestamp.format("YYYY-MM-DD HH:mm:ss")
}

function getFormJson(form) {
    var o = {};
    var a = $(form).serializeArray();
    $.each(a, function () {
        if (o[this.name] !== undefined) {
            if (!o[this.name].push) {
                o[this.name] = [o[this.name]];
            }
            o[this.name].push(this.value || '');
        } else {
            o[this.name] = this.value || '';
        }
    });
    return o;
}

function initDateRangePick(control) {
    control.daterangepicker({
        autoUpdateInput: false,
        ranges: {
            '今日': [moment().startOf('day'), moment()],
            '昨日': [moment().subtract(1, 'days').startOf('day'), moment().subtract(1, 'days').endOf('day')],
            '最近7日': [moment().subtract(6, 'days'), moment()],
            '最近30日': [moment().subtract(29, 'days'), moment()]
        },
        locale: {
            'format': "YYYY-MM-DD",
            'separator': ' 至 ',
            'applyLabel': '确定',
            'cancelLabel': '清除',
            'fromLabel': '起始时间',
            'toLabel': '结束时间',
            'customRangeLabel': '自定义',
            'daysOfWeek': ['日', '一', '二', '三', '四', '五', '六'],
            'monthNames': ['一月', '二月', '三月', '四月', '五月', '六月', '七月', '八月', '九月', '十月', '十一月', '十二月'],
            'firstDay': 1
        }
    });
    control.on('apply.daterangepicker', function (ev, picker) {
        $(this).val(picker.startDate.format('YYYY-MM-DD') + ' 至 ' + picker.endDate.format('YYYY-MM-DD'));
    });
    control.on('cancel.daterangepicker', function (ev, picker) {
        control.val('');
    });
}

Date.now = Date.now || function () {
    return +new Date;
};

(function ($) {
    $.fn.dialog = function (options) {
        var defaults = {};

        var opts = $.extend(defaults, options);
        $(this).unbind("click");
        $(this).bind("click", function () {
            var index = top.layer.open($.extend({
                type: 2,
                title: $(this).attr('title') ? $(this).attr('title') : '未命名窗口',
                maxmin: true,
                anim: 0,
                //shade: true,
                shade: [0.5],
                shadeClose: true,
                resize: true,
                //area: ['50%', '80%'],
                area: ['70%', 'auto'],
                moveOut: false,
                offset: '20%',
                zIndex: top.layer.zIndex,
                success: function (layero, index) {
                    top.layer.setTop(layero);
                    //var body = top.layer.getChildFrame('body', index);
                    //body.setParentOptions(opts);
                    var iframeWin = top.window[layero.find('iframe')[0]['name']];
                    iframeWin.parentOptions = opts;
                },
                content: $(this).attr('href')
            }, options));

            return false;
        });
    };
})(jQuery);

