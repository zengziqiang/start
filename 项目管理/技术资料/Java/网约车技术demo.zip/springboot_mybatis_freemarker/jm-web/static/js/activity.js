$(document).ready(function(){
	init();
	$('.aV2Products').hover(
			function(){
				$(this).removeClass('aV2Products').addClass('aV2Productshover');
				$(this).find('h1').css('color','#F60');
				$(this).find('.btnlink').removeClass('btnlink').addClass('btnhover');
			},
			function(){
				$(this).removeClass('aV2Productshover').addClass('aV2Products');
				$(this).find('h1').removeAttr('style');
				$(this).find('.btnhover').removeClass('btnhover').addClass('btnlink');
			}
		);
		$('.aV2ProductsYMYS').hover(
			function(){
				$(this).removeClass('aV2ProductsYMYS').addClass('aV2ProductsYMYShover');
				$(this).find('h1').css('color','#F60');
				$(this).find('.btnlink').removeClass('btnlink').addClass('btnhover');
			},
			function(){
				$(this).removeClass('aV2ProductsYMYShover').addClass('aV2ProductsYMYS');
				$(this).find('h1').removeAttr('style');
				$(this).find('.btnhover').removeClass('btnhover').addClass('btnlink');
			}
		);
	
	
})
var searchLeveNameMS='';
var searchLeveNameTJ='';
//查看展示到展区边栏的药品
function searchActivityIndex(pageNum,pageSize,activityType,leveName)
{

	var url = '/sale/activity/serchPandect.json?'+ Math.random();
	var listActivity;
	$.ajax({   
		type : "post",   
		url : url,   
		data:{activityType:activityType,page:pageNum,rows:pageSize,leveName:leveName},
		async : false,   
		success : function(data){   
			listActivity = parserToJson(data);
		}   
	}); 
	return listActivity;
}
function  loadActivieyPaginationMS(pageNum,pageSize){
	return loadActivieyMS(pageNum,pageSize,2);
}

function  loadActivieyPaginationTJ(pageNum,pageSize){
	return loadActivieyTJ(pageNum,pageSize,1);
}

function init(){
	var bkw=$("body").width();
	  $('.banner_t,.banner_g').css('width',bkw);
	  $(window).resize(function() {
		 	
	var bkw=$("body").width() < "1000" ? "1000" : $("body").width();
		  $('.banner_t,.banner_g').css('width',bkw);
		 });
	  $('.banner_g').css('height',$('.activity_main').height());
	  
	  //仿下拉框
	  $('.activity_t1 input,.activity_t2 input,.fenlei input').click(function(){
			
			var nowis=$('.activity_bm').css("display") == "none" ? "" : "none";
			$('.activity_bm').css("display",nowis)
		})

	   
		$('.activity_cur').click(function(){
			$('.activity_t1 input,.activity_t2 input,.fenlei input').val($(this).html());
			$('.activity_bm').css('display','none');
		})
		$('.activity_cur').hover(function(){
				$(this).css('background-color','#EBEBEB').css('color','#f90');
			},function(){
				$(this).css('background-color','#fff').css('color','#788F72');
				});
		$('.activity_bm').hover(function(){},function(){
			$(this).css('display','none');
		});

}



//加载本期特价药品

function  loadActivieyTJ(pageNum,pageSize,activityType){
	var activityInfo="";
	var activityResult=searchActivityIndex(pageNum,pageSize,activityType,searchLeveNameTJ);
	$('#activity_tj').html('');
	$.each(activityResult.rows,function(i,row){
		activityInfo=activityInfo+'<div class="activity_box activity_buf">'
		+'<div class="activity_mid">'
		+'<a target="blank" href="/front/merchandise/detail.htm?id='+row.merchandiseId+'">'
		+'<img onerror="this.src=\'/static/images/nophoto.png\'" src="'+activityResult.merchandiseImagePath+substrVal2(row.orgmerchandiseCode,11)+'/'+substrVal2(row.orgmerchandiseCode,11)+'.JPG" width="221" height="166" /> </a><p>'	
		+'名称：<a target="blank" href="/front/merchandise/detail.htm?id='+row.merchandiseId+'">'+row.merchandiseName+'</a></p>'
		+'<p>规格：'+row.merchandiseSpec+'</p>'
		 
		+'<p>生产厂家：'+(row.manufacturer==null?'':row.manufacturer)+'</p>'
		  +' <p>特价：<span>'+row.formatMermberPrice+'</span>/<em>'+row.formatRetailPrice+'</em></p>'
		  +'<div class="activity_box_bottom">'
		  +' <p>库存：'  +(row.storageNumber>100?'>100':'0-100')+'</p>'
		  +'<input style="ime-mode:disabled" onkeydown="IsNum(event)" maxlength="5" id="num_'+row.merchandiseId+'" name="" type="text" />盒' 
		+'<a  onclick="activityAddcart('+row.merchandiseId+')"><img src="/static/images/activity_buy.png" width="75" height="32" /></a> </div>'
		 +'</div>'  
		 +'</div>';  
	});
	$('#activity_tj').append(activityInfo);
	//获得高度设置背景高度
	$('#banner_g').height($('#activity_tj').height()+80);
	return  activityResult.pagination;
}

function loadActivieyMS(pageNum,pageSize,activityType)
{
	var activityInfo="";
	$('#activity_ms').html('');
	var activityResult=searchActivityIndex(pageNum,pageSize,activityType,searchLeveNameMS);
	$.each(activityResult.rows,function(i,row){
		activityInfo=activityInfo+'<div class="activity_box activity_buf">'
		+'<div class="activity_mid">'  
		+'<a  target="blank" href="/front/merchandise/detail.htm?id='+row.merchandiseId+'"><img onerror="this.src=\'/static/images/nophoto.png\'" src="'+activityResult.merchandiseImagePath+substrVal2(row.orgmerchandiseCode,11)+'/'+substrVal2(row.orgmerchandiseCode,11)+'.JPG" width="221" height="166" /> </a><p>'
		+'名称：<a  target="blank" href="/front/merchandise/detail.htm?id='+row.merchandiseId+'">'+row.merchandiseName+'</a></p>'
		+'<p>规格：'+row.merchandiseSpec+'</p>'
		+'<p>生产厂家：'+(row.manufacturer==null?'':row.manufacturer)+'</p>'
		  +' <p>政策：<span>'+row.activityPolicy+'</span></p>'
		  +'<div class="activity_box_bottom">'
		  +' <p>库存：'+(row.storageNumber>100?'>100':'0-100')+'</p>'
		  +'<input style="ime-mode:disabled" onkeydown="IsNum(event)" id="num_'+row.merchandiseId+'" name="" type="text" />盒' 
		+'<a  onclick="activityAddcart('+row.merchandiseId+')"><img src="/static/images/activity_buy.png" width="75" height="32" /></a> </div>'
		 +'</div>'  
		 +'</div>';
	});
	$('#activity_ms').append(activityInfo);
	$('#banner_g').height($('#activity_ms').height()+80);
	return  activityResult.pagination;
}
function activityAddcart(merchandiseId)
{
	var num=$('#num_'+merchandiseId).val();
	//if(0==num||null==num||""==num)
	//	{
	//	alert("请输入购买数量!");
	//	return;
	//	}
//	var reg = new RegExp("^(0|[1-9][0-9]*)$");
//	if(!reg.test(num)){
    //    alert("请输入正确数量!");
   //     return;
 //   }	
	
	//退货品种提示
	var json = isReturnMerchandise(merchandiseId);
	if(json.isNotReturnType && (!confirm(json.message))){
		return;
	}
	var aerray="[{merchandiseId:"+merchandiseId+",merchandiseNumber:"+num+"}]";
	//[{merchandiseId:4885,merchandiseNumber:60,agentPrice:30},{merchandiseId:4886,merchandiseNumber:30,agentPrice:30}]
	var json = check_cart(aerray);//加入购物车
	//if(returnValue != null && returnValue!=""){
	//	alert(returnValue);
	//}
	if(json==undefined){
		$("#checkbox"+merchandiseId).removeAttr('checked');
	}
	//if(returnValue=="添加失败"){
	//}
}

//限时抢购
function panicBuying(merchandiseId){
	var purchaseAmount=$('#num_'+merchandiseId).val();
	var orgMerchandiseCode = $('#org_'+merchandiseId).val();
	 $.ajax({   
		      url:'/sale/activity/panicBuying.htm',   
		      type:'get',   
		      data:"orgMerchandiseCode=" + orgMerchandiseCode + "&purchaseAmount=" + purchaseAmount + "&t=" + Math.random(),
		      async : false, 
		      error:function(){   
		         alert('发生错误');   
		      },   
		      success:function(data){
		    	  var json = parserToJson(data);
			        if(!json.success){
			        	//alert(json.message);
			        	if(json.nologin != undefined && json.nologin == '1'){
			        		location.href = "/user/login.htm";
			        	}
			        	return;
			        }
			        //抢购成功后，刷新当前页面的库存
			        //$('#storage_'+merchandiseId).text("库存："+json.currentStorageNumber);
			        //会员客户才允许加入购物车
			        activityAddcart(merchandiseId);
		      }
		  });
}


//会员专销区，需要对客户是否会员进行判断
function  coreCustAddCart(merchandiseId){
	 $.ajax({   
		      url:'/user/isCoreCust.json',   
		      type:'get',   
		      async : false, 
		      error:function(){   
		         alert('发生错误');   
		      },   
		      success:function(data){  
		    	  var isCoreCust = data;
			        if(isCoreCust == 'false'){
			        	alert("此活动只针对会员客户!");
			        	return;
			        }
			        //会员客户才允许加入购物车
			        activityAddcart(merchandiseId);
		      }
		  });
}


	function IsNum(event){
		var a =event.keyCode;
		if(!((a>=48 && a<=57) || (a>=96 && a<=105) || (a>=37 && a<=40) || a==8  || a==110  || a==190))
		{event.preventDefault?event.preventDefault():event.returnValue=false;
		}
	}

function getLeveNameMS(levename)
{
	if('全部'==levename)
		{
		levename='';
		}
	searchLeveNameMS=levename;
	//pageInit(loadActivieyPaginationMS,20);
	window.location.href='/sale/activity/index.htm?pageNum=2&leveName='+encodeURI(levename);
}

function getLeveNameTJ(levename)
{
	if('全部'==levename)
	{
	levename='';
	}
	searchLeveNameTJ=levename;
	window.location.href='/sale/activity/index.htm?pageNum=1&leveName='+encodeURI(levename);
	//pageInit(loadActivieyPaginationTJ,20);
}

function getLeveNameFX(levename)
{
	if('全部'==levename)
	{
	levename='';
	}
	searchLeveNameTJ=levename;
	window.location.href='/sale/activity/index.htm?pageNum=3&leveName='+encodeURI(levename);	

}
function getLeveNameJZBZH(levename,aktionsprogrammId,aktionsprogrammType,aktionsprogrammName)
{
	if('全部'==levename)
	{
	levename='';
	}
	searchLeveNameTJ=levename;
	if(aktionsprogrammType=='2'){
	window.location.href='/tactics/tacticsM.htm?page=1&aktionsprogrammType='+encodeURI(aktionsprogrammType)+'&leveName='+encodeURI(levename);
	}
	else{
	window.location.href='/tactics/tacticsM.htm?page=1&aktionsprogrammId='+encodeURI(aktionsprogrammId)+'&aktionsprogrammType='+encodeURI(aktionsprogrammType)+'&leveName='+encodeURI(levename);
	
	}
}
/**
 * 药品数量减、加
 */
function initCartNum(){
	$("input.a_plus_input")
	.live(
			'keydown',
			function(e) {

				var keyCode = e.keyCode ? e.keyCode : e.which ? e.which
						: e.charCode;
				if (keyCode == 13) {
					return true;
				}
				sk = e.shiftKey ? e.shiftKey : ((keyCode == 16) ? true
						: false);
				if (sk)
					return false;
				if (!(keyCode == 46) && !(keyCode == 8)
						&& !(keyCode == 9) && !(keyCode == 37)
						&& !(keyCode == 39))
					if (!((keyCode >= 48 && keyCode <= 57) || (keyCode >= 96 && keyCode <= 105) || keyCode == 110 || keyCode == 190))
						return false;
			
			}).live('focus', function(event) {
				
		$(this).val('');

	}).live('blur', function(event) {
	
		if($(this).val() == ''){
			$(this).val(0);
		}
		//$(this).val(Math.round(this.value));
		if ($(this).val() < 0)
			$(this).val(0);
		if ($(this).val() > 99999)
			$(this).val(99999);
	}).live('keyup', function() {


		// if ($(this).val()<1)$(this).val(1);
		if ($(this).val() > 99999)
			$(this).val(99999);
	});
$('a.minus')
	.live(
			'click',
			function() {
				$(this).siblings('input').val() > 1 ? $(this).siblings(
						'input').val(
						parseInt($(this).siblings('input').val()) - 1)
						: 1;
			});
$('a.plus').live(
	'click',
	function() {

		if ($(this).siblings('input').val() > 99998) {
			$(this).siblings('input').val(99999);
		} else {
			$(this).siblings('input').val(
					parseInt($(this).siblings('input').val()) + 1);
		}
	});
}
/**
 * 验证采购数量输入框为空或者输入0开头的数字
 */
function checkNull(merchandiseId){
	var buyAmount=$('#'+merchandiseId+'').val();
	if(buyAmount==null || buyAmount==NaN ||buyAmount==''){
		$('#'+merchandiseId+'').val(0);
	}
	if(buyAmount.substring(0,1)=='0'){
		$('#'+merchandiseId+'').val(buyAmount.substring(1,buyAmount.length));
	}
}