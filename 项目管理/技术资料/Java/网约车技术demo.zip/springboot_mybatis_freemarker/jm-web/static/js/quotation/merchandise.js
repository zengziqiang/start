var merchandiseCallbackFn;
var isFirstRun = true;
var options;

function merchandiseInit(callback, initOptions) {
	merchandiseCallbackFn = callback;
	options = initOptions || {};
	if (!options.showMemberPrice) {
		options.showMemberPrice = false;
	}
}

function merchandiseOpen() {
	$('#merchandiseSelectWindow').window({
		width : 800,
		height : 500,
		modal : true,
		collapsible : false,
		minimizable : false,
		resizable : true,
		maximizable : false,
		closable : true,
		closed : true,
		position : 'fixed',
		title : '选择药品',
		shadow : false
	});
	$('#merchandiseSelectWindow').window('center');

	$('#merchandise_keyword').searchbox('setValue', '');
	$('#merchandise_chuffl').val('');
	$('#merchandise_jixing').val('');
	$('#merchandise_xkjylb').val('');
	$('#merchandise_date1').datebox('getValue', '');
	$('#merchandise_date2').datebox('getValue', '');

	if (isFirstRun) {
		$('#merchandiseSelectTable')
				.datagrid(
						{
							fit : true,
							nowrap : true,
							striped : true,
							fitColumns : false,
							rownumbers : true,
							toolbar : '#merchandise_tb',
							loadMsg : '数据加载中请稍后……',
							url : '/search/pick_merchandise.htm',
							method : 'post',
							pageSize : 10,
							pageNumber : 1,
							pagination : true,
							singleSelect : false,
							idField : 'merchandise_id',
							queryParams : {
								options : options
							},
							frozenColumns : [ [ {
								field : 'merchandise_id',
								checkbox : true
							} ] ],
							columns : [ [
									{
										field : 'passfile_number',
										hidden : true
									},
									{
										field : 'orgmerchandise_code',
										title : '药品编码',
										align : 'left',
										resizable : true,
										width : 100,
										formatter : function(value) {
											return value ? value : "";
										}
									},
									{
										field : 'merchandise_name',
										title : '药品名称',
										align : 'left',
										resizable : true,
										width : 150,
										formatter : function(value) {
											return value ? value : "";
										}
									},
									{
										field : 'merchandise_spec',
										title : '规格',
										align : 'left',
										resizable : true,
										width : 100,
										formatter : function(value) {
											return value ? value : "";
										}
									},
									{
										field : 'manufacturer',
										title : '厂家',
										align : 'left',
										resizable : true,
										width : 150,
										formatter : function(value) {
											return value ? value : "";
										}
									},
									{
										field : 'packing_number',
										title : '中/大包装',
										align : 'left',
										resizable : true,
										width : 60,
										formatter : function(value, row, index) {
											return (row.middling_packing ? row.middling_packing
													: "")
													+ "/"
													+ (row.packing_number ? row.packing_number
															: "");
										}
									},
									{
										field : 'storage_number',
										title : '库存',
										align : 'left',
										resizable : true,
										width : 60,
										formatter : function(value) {
											return (value && value > 0) ? (value > 100 ? ">100"
													: "有")
													: "无";
										}
									}, {
										field : 'retail_price',
										title : '零售价',
										align : 'left',
										resizable : true,
										width : 60,
										formatter : function(value) {
											return value ? value : "";
										}
									}, {
										field : 'member_price',
										title : '会员价',
										align : 'left',
										resizable : true,
										width : 60,
										hidden : true,
										formatter : function(value) {
											return value ? value : "";
										}
									}, {
										field : 'merchandise_unit',
										title : '单位',
										align : 'left',
										resizable : true,
										width : 50,
										formatter : function(value) {
											return value ? value : "";
										}
									}, {
										field : 'chuffl',
										title : '处方类',
										align : 'left',
										resizable : true,
										width : 50,
										formatter : function(value) {
											return value ? value : "";
										}
									}, {
										field : 'jingyjm',
										title : '基药类',
										align : 'left',
										resizable : true,
										width : 50,
										formatter : function(value) {
											return value ? value : 0;
										}
									} ] ]

						});
		isFirstRun = false;
	} else {
		$('#merchandiseSelectTable').datagrid('clearChecked');
		merchandiseReLoad();
	}

	$('#merchandiseSelectWindow').window('open');
}

function merchandiseBtnOK() {
	var row = $('#merchandiseSelectTable').datagrid('getSelected');
	if (!row) {
		$.messager.alert('警告', '请选择一个药品');
		return;
	}
	$('#merchandiseName').val(row.merchandise_name);
	$('#merchandiseId').val(row.merchandise_id);

	$('#merchandiseSelectWindow').window('close');
}

function merchandiseBtnCancle() {
	$('#merchandiseSelectWindow').window('close');
}

function merchandiseReLoad() {
	$("#merchandiseSelectTable").datagrid('load', {
		keyword : $('#merchandise_keyword').searchbox('getValue'),
		chuffl : $('#merchandise_chuffl').val(),
		jixing : $('#merchandise_jixing').val(),
		xkjylb : $('#merchandise_xkjylb').val(),
		date1 : $('#merchandise_date1').datebox('getValue'),
		date2 : $('#merchandise_date2').datebox('getValue'),
		options : options
	});
}

/*******************************************************************************
 * 获取药品数据
 * 
 */
function getMerchandiseTable() {

}

/*******************************************************************************
 * 在搜索结果中进行二次查找
 */
function searchMerchandise() {
	var keyword = $("#keyword").val();
	var category = $("#category").val();
	var storage = $("#storage").val();
	var price = $("#price").val();
	var keyword2 = $("#keyword2").val();
	var level1Name = $("#level1Name").val();
	var level2Name = $("#level2Name").val();
	var level3Name = $("#level3Name").val();
	var yibao = $("#yibao").val();
	var isjiyao = $("#isjiyao").val();
	var merchandise_type = $("#merchandise_type").val();

	location.href = "/search/merchandise.htm?keyword=" + keyword + "&category="
			+ category + "&level1_name=" + level1Name + "&level2_name="
			+ level2Name + "&level3_name=" + level3Name + "&storage=" + storage
			+ "&price=" + price + "&keyword2=" + keyword2 + "&yibao=" + yibao
			+ "&isjiyao=" + isjiyao + "&merchandise_type=" + merchandise_type;
}

/**
 * 根据ID进行异步加载药品信息
 * 
 * @param merchandiseId
 */
function loadMerchandiseById(merchandiseId) {
	var url = "/merchandise/oneMerchandise.json";
	// jsonData = "array=[{merchandise_id:"+merchandiseId+"}]";
	jsonData = "merchandise_id=" + merchandiseId;
	$.ajax({
		type : "GET",
		url : url,
		data : jsonData,
		async : false,
		success : function(data) {
			var json = JSON.parse(data);
			var merchandiseImagePath = json.merchandiseImagePath;
			var orgmerchandiseCode = json.merchandise.orgmerchandiseCode;
			var temp = '<div class="all_product_div">'
					+ '<div class="float_img"><img src="'
					+ merchandiseImagePath + orgmerchandiseCode + '/'
					+ orgmerchandiseCode
					+ '.JPG" width="150" height="113" /></div>'
					+ '<div class="float_font">' + '<p>商品编码：'
					+ orgmerchandiseCode + '</p>' + '<p>批准文号：'
					+ json.merchandise.passfileNumber + '</p>'
					+ '<p>销售类别：未知</p>' + '<p>是否拆零：是</p>' + '<p>处方分类：乙类</p>'
					+ '<p>有效期：' + json.merchandise.fvalidity + '</p>'
					+ '</div>' + '</div>';
			$("body").append(temp);
		}
	});
}
