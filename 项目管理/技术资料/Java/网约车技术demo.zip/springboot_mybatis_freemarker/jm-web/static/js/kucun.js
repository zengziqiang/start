//批量替换库存
$(document).ready(function(){
	
	tihuan();
	function tihuan(){
		var name = $(".main_top_left .city_p .city").html();
		for(var i=0 ;i<5 ;i++){
			var copym=$('table tr:eq('+i+') td');
			copym.each(function()
			{
				if($(this).html()=='库存'&&name=="重庆")
				{
					var cnum=$(this).index();
					$('table tr').each(function() {
						if($(this).index()!='0'){
							if($(this).children('td').eq(cnum).html()!=''&&typeof($(this).children('td').eq(cnum).html())!="undefined"&&$(this).children('td').eq(cnum).html()!="&nbsp;"){
								//数据处理
								if($(this).children('td').eq(cnum).html()<=0){
									$(this).children('td').eq(cnum).html("<img src='/static/images/zu.png' title='库存为0'/>");
								}else if($(this).children('td').eq(cnum).html()<=100){
									$(this).children('td').eq(cnum).html("1-100");
								}else{
									$(this).children('td').eq(cnum).html(">100");
								}
							}
						}

			        });
				
					
				}
			});
		}
	}
});
function kucunchuli(number){
	var name = $(".main_top_left .city_p .city").html();
	if(name=="重庆"){
		if(number<=0)return "<img src='/static/images/zu.png' title='库存为0'/>";
		else if (number<=100)return "1-100";
		else return ">100";
	}
	return number;
}