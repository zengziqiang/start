// JavaScript Document
//自动向上滚动：
//单独判断超出高度的div，并对其animate动画控制操作
$(document).ready(function(){
	$('.content_nav_help').append("<div class='cxw01'>&nbsp</div>");
	$("html,body").animate({scrollTop:0},0);
	var a1 = $('.top_help_cen_nav ul li.now1').index();
	var imgH = $('.box_c_01 img').css('height');
	$('.centent_box').css('height',imgH);	
	$('.box_c_02').css('height',imgH);	
	$('.centent_box').hide();
	$('.centent_box').eq(0).show();
	var isScroll = $('#isScroll').val();
	
	$('.content_nav_help ul li').click(function(){
		$('.content_nav_help ul li').removeClass('now1');
		$(this).addClass('now1');
		
		var index = $(this).index();
		if(index==0){
			$('.centent_box').hide();
			$('.centent_box').eq(index).show();
			$("html,body").animate({scrollTop:0},0);
		}else{
			$('.centent_box').hide();
			$('.centent_box').eq(index).show();
			if(isScroll == 1){//注册流程才进行滚动
				$.scrollTo('.cxw01',500); 
			}
			
		}
		
		
		
		})
	$('.button').click(function(){
		var i1 = $(this).parent().index();
		
		var i2 = $('.centent_box').length;
		if(i1==i2){
			$('.centent_box').hide();
			$('.centent_box').eq(0).show();
			$('.content_nav_help ul li').removeClass('now1');
			$('.content_nav_help ul li:first').addClass('now1');
			$("html,body").animate({scrollTop:0},0);
			}else{	
				$(this).parent().hide();
				$(this).parent().next().show();
				$('.content_nav_help ul li').removeClass('now1');
				$('.content_nav_help ul li').eq(i1).addClass('now1');
				if(isScroll == 1){//注册流程才进行滚动
					$.scrollTo('.cxw01',500); 
				}
			}
				
		
		})
//		$('.button15').click(function(){
//			window.location.reload();
//			})
//		$('.button10').click(function(){
//			window.location.reload();
//			})
//		$('.button4').click(function(){
//			window.location.reload();
//			})
		//$('.top_help').css({'position':fixed,'top':0});
		//if ($.browser.msie && ($.browser.version == "6.0") && !$.support.style){
//			$('.centent_box').css({'position':'absolute','bottom':'auto','top':expression(eval(document.documentElement.scrollTop))})
//			}
		if ($.browser.msie && ($.browser.version == "7.0") && !$.support.style){
			$('.centent_box').css({'top':'140px'});
			$('.bottom_help').css({'margin-top':'150px'});
			}
	})
