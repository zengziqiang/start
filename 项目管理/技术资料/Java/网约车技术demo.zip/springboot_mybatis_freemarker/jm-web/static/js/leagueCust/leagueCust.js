/*
 * 计算总金额
 * */
function sumPrices(){
	var sumPrice = 0;
	$("input[name='pk']").each(function(){
		var pk = this.value;
		if(this.checked){
			//根据当前选中的价格，和数量计算总金额
			sumPrice = sumPrice + Number($("#id_price_" + pk).val())*Number($("#amount_" + pk).val());
		}
	});
	$("#sumPrice").html("金额："+sumPrice.toFixed(2));
}

/**
 * 加减购买数量
 */
function changeNum(obj){
	var currentValue = 0;
	var pk = $("#"+obj.id).parent().children("input[name='PK']").val();
	if(obj.id == 'sub_quantity_' + pk){//减数量
		currentValue = $("#"+obj.id).next().val();
		if(currentValue == ''){
			$("#"+obj.id).next().val(0);
		} else if(currentValue < 10){
			$("#"+obj.id).next().val(0);
		} else {
			currentValue = Number(currentValue) - Number(10);
			$("#"+obj.id).next().val(currentValue);
		}
	}
	if(obj.id == 'add_quantity_' + pk){
		currentValue = $("#"+obj.id).prev().val();
		if(currentValue == ''){
			$("#"+obj.id).prev().val(10);
		} else {
			currentValue = Number(currentValue) + Number(10);
			$("#"+obj.id).prev().val(currentValue);
		}
	}
	//数量大于0 ，自动勾选
	if(currentValue > 0){
		$("#sigleChecked"+pk).prop("checked",true);
	}else{
		$("#sigleChecked"+pk).prop("checked",false);
	}
	$("#allChecked").prop("checked",$("input[name='pk']").length == $("input[name='pk']:checked").length ? true : false);
	sumPrices();
}

/**
 * 全选
 */
function checkedAll(){
	var allChecked = $("#allChecked").attr("checked");
	if(allChecked == 'checked'){
		$("input[name='pk']").attr("checked","checked");
	} else {
		$("input[name='pk']").removeAttr("checked");
	}
	sumPrices();
}

/**
 * 单选
 * @param obj
 */
function sigleChecked(obj){
	var checked = obj.checked;
	if(!checked){
		$("#allChecked").removeAttr("checked");
	} else {
		var isCheckedAll = true;
		$("input[name='pk']").each(function(){
			if(!this.checked){
				isCheckedAll = false;
			}
		});
		if(isCheckedAll){
			$("#allChecked").attr("checked","checked");
		} else {
			$("#allChecked").removeAttr("checked");
		}
	}
	sumPrices();
}

//首页全选
function checkedAll2(){
	var thisChecked = $("#allChecked").prop("checked");
	//alert(thisChecked);
	$("input[name='pk']").prop("checked",thisChecked);
	sumPrices();
}

//首页单选
function sigleChecked2(obj){
	//alert($("input[name='pk']").length);
	//alert($("input[name='pk']:checked").length);
	$("#allChecked").prop("checked",$("input[name='pk']").length == $("input[name='pk']:checked").length ? true : false);
	sumPrices();
}

function orderIntentionWeek(obj,branchId){
	//alert("本周重点"+obj+"--"+branchId);
	$.ajax({
		type:"post",
		url:"/leagueCust/orderIntention.htm",
		data:{
			isRecommend : obj,//0表示本周重点
			branchId : branchId,
			resource : 'home'
		},
		success : function(text){
			var data = parserToJson(text);
			if(data.success){
				var str="";
				var tabStr = "<table border='0' cellspacing='0' cellpadding='0' class='selected' id='orderIntentionTab'>";
				for(var i=0;i<data.list.length;i++){
					var prodName = data.list[i].PRODNAME;
					if(prodName.length > 8){
						prodName = prodName.substring(0,8)+"...";
					}
					str = str + "<tr><td width='2%'><input id='sigleChecked"+data.list[i].PK+"' name='pk' onclick='sigleChecked2(this)' type='checkbox' value='"+data.list[i].PK+"' /></td>"
					+"<td width='13%'><span>编号："+data.list[i].PRODNO+"</span><span title='"+data.list[i].PRODNAME+"'>"+prodName+"</span><span>"+data.list[i].PRODSPECIFICATION+"</span></td>"
					+"<td width='18%'> <sapn>"+data.list[i].MANUFACTURER+"</span><span>"+data.list[i].LINKPHONE+"</span></td>"
					+"<td width='25%' class='text_red'>促销政策： "+data.list[i].PROMOCONTENT+" 备注: "+data.list[i].NOTE+"</td>"
					+"<td width='12%' align='center'><span>最低购进："+data.list[i].SALENUM+"</span><span class='text_blue'>"+data.list[i].PROMOTIONSTATE+"</span></td>"
					+"<td width=12%' align='center'><span class='text_red'>零售价 : "+data.list[i].RETAILPRICE2+"</span><span class='text_red'>联盟价 : "+data.list[i].PRICE2+"</span></td>"
					+"<td width='20%' align='center'><input type='hidden' name='PK' value='"+data.list[i].PK+"'>"
					+"<a href='javascript:void(0)' id='sub_quantity_"+data.list[i].PK+"' class='a_plus' onclick='changeNum(this)'>-10</a>"
					+"<input id='amount_"+data.list[i].PK+"' name='quantity_"+data.list[i].PK+"' type='text' value='0' class='a_plus_input' onkeyup='checkInput(this)' />"
					+"<a href='javascript:void(0)' id='add_quantity_"+data.list[i].PK+"' class='a_plus' onclick='changeNum(this)'>+10</a></td>"
					+"<td width='10' align='center'>"
					+"<input type='hidden' name='prodNo_"+data.list[i].PK+"' id='id_prodNo_"+data.list[i].PK+"' value='"+data.list[i].PRODNO+"'/>"
					+"<input type='hidden' name='prodName_"+data.list[i].PK+"' id='id_prodName_"+data.list[i].PK+"' value='"+data.list[i].PRODNAME+"' />"
					+"<input type='hidden' name='manufacturer_"+data.list[i].PK+"' id='id_manufacturer_"+data.list[i].PK+"' value='"+data.list[i].MANUFACTURER+"' />"
					+"<input type='hidden' name='prodSpecification_"+data.list[i].PK+"' id='id_prodSpecification_"+data.list[i].PK+"' value='"+data.list[i].PRODSPECIFICATION+"' />"
					+"<input type='hidden' name='saleNum_"+data.list[i].PK+"' id='id_saleNum_"+data.list[i].PK+"' value='"+data.list[i].SALENUM+"' />"
					+"<input type='hidden' name='prodId_"+data.list[i].PK+"' id='id_prodId_"+data.list[i].PK+"' value='"+data.list[i].PRODID+"' />"
					+"<input type='hidden' name='promoContent_"+data.list[i].PK+"' id='id_promoContent_"+data.list[i].PK+"' value='"+data.list[i].PROMOCONTENT+"' />"
					+"<input type='hidden' name='price_"+data.list[i].PK+"' id='id_price_"+data.list[i].PK+"' value='"+data.list[i].PRICE2+"' />"
					+"</td>"
					+"</tr>";
					if(i>4){
						break;
					}
				}
				
				str2 = "<tr><td width='45' align='center'><input id='allChecked' type='checkbox' value='' onclick='checkedAll2()' /></td>"
					   +"<td width='15%' align='left'> 全选</td>"
					   +"<td id='sumPrice' align='right' class='money'>合计金额：0.00</td>"
					   +"<td colspan='4'><a href='javascript:void(0)' class='btn_tj' onclick='commitIntntionForm()'>一键提交意向单</a>"
					   +"<a href='javascript:void(0)' class='btn_tj' onClick='showCustMessage()' >一键提交订单</a></td></tr>";
				var tabStr2 = "</table>";
				$("#orderIntentionTab").remove();
				$("#appendTab").append(tabStr+str+str2+tabStr2);
			}
		}
	});
}

function checkInput(obj){
	if(obj.value.length==1){
		obj.value=obj.value.replace(/[^1-9]/g,'');
		}else{
			obj.value=obj.value.replace(/\D/g,'');
		}
}