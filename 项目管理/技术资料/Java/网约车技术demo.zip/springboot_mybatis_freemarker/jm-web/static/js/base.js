var initTitleFlag = false;
$(document).ready(function() {
	// help
	var handle1 = null;
	$('.help_img').hover(function() {

		$(this).children('.helpbox').fadeIn(150);

	}, function() {

		$(this).children('.helpbox').fadeOut(200);
	});

});

function addfavorite() {
	if (document.all) {
		window.external.addFavorite('http://www.yyjzt.com/', '九州通电子商务交易平台');
	} else if (window.sidebar) {
		window.sidebar.addPanel('九州通电子商务交易平台', 'http://www.yyjzt.com/', "");
	}
}

function initTitle(i) {
	if (initTitleFlag) {
		return;
	}
	// 初始化
	$('.nav_m>a').removeClass("na_h");
	$('.nav_m>div').hide();
	$('.nav_m>div').eq(i).show();
	$('.nav_m>a').eq(i).addClass("na_h");

	$('.nav_m>a').hover(function() {

		$('.nav_m>a').removeClass("na_h");
		$(this).addClass('na_h');
		$('.nav_m_d').hide();
		$(this).next('div').show();
		$(this).next('div').hover(function() {
			$('.nav_m>a').removeClass("na_h");
			$(this).prev('a').addClass("na_h");
		}, function() {
			$(this).prev('a').removeClass("na_h");
			$(this).hide();
			$(this).parent('.nav_m').children('div').eq(i).show();
		});

	}, function() {

	});
	$('.nav_m').hover(function() {

	}, function() {

		$('.nav_m>div').hide();
		$('.nav_m>div').eq(i).show();
		$('.nav_m>a').removeClass("na_h");
		$('.nav_m>a').eq(i).addClass("na_h");
	});
	initTitleFlag = true;
}

function initTopSelect() {
	// 顶部仿下拉框
	$('.am').click(function() {

		var nowis = $('.bm').css("display") == "none" ? "" : "none";
		$('.bm').css("display", nowis);
	});

	$('.cur').click(function() {
		$('.am').val($(this).html());
		$('.bm').css('display', 'none');
	});
	$('.cur').hover(function() {
		$(this).css('background-color', '#EBEBEB').css('color', '#f90');
	}, function() {
		$(this).css('background-color', '#fff').css('color', '#788F72');
	});
	$('.bm').hover(function() {
	}, function() {
		$(this).css('display', 'none');
	});
}


function initTopSelectSmall() {
	// 顶部仿下拉框
	$('.am_small').click(function() {
		var nowis = $('.bm_small').css("display") == "none" ? "" : "none";
		$('.bm_small').css("display", nowis);
	});

	$('.cur_small').click(function() {
		$('.am_small').val($(this).html());
		$('.bm_small').css('display', 'none');
	});
	$('.cur_small').hover(function() {
		$(this).css('background-color', '#EBEBEB').css('color', '#f90');
	}, function() {
		$(this).css('background-color', '#fff').css('color', '#788F72');
	});
	$('.bm_small').hover(function() {
	}, function() {
		$(this).css('display', 'none');
	});
}

function initSearchInput() {
	$('span.label_tip').mouseup(function() {
		$('.s_t').focus();
	});
	$(".s_t").autocomplete("/search/autoComplete.htm", {
		width : 328,
		scrollHeight : 220,
		selectFirst : false,
		extraParams : {
			category : function() {
				return $('#category').val();
			},
			keyword : function() {
				return $('#keyword').val();
			}
		},
		formatItem : function(row, i, max) {
			/**
			 * var pattern = /(.*)null$/; var temp = row[0];
			 * if(pattern.test(temp)){ //temp = temp.substr(0, temp.length-4);
			 * temp = temp.match(pattern)[1]; }
			 */
			return row[0];
		},
		formatResult : function(row, i, max) {
			/**
			 * var pattern = /(.*)null$/; var temp = row[0];
			 * if(pattern.test(temp)){ //temp = temp.substr(0, temp.length-4);
			 * temp = temp.match(pattern)[1]; }
			 */
			return row[0];
		}

	}).result(function(event, row) {
		// $("#keyword").val(row[0]);
		search();
	});

	// 火狐bug 开始就检查输入框提示
	if ($('.s_t').val() == '') {
		$('span.label_tip').show();

	} else {
		$('span.label_tip').animate({
			opacity : 0
		}, 100, function() {
			$(this).css('display', 'none');
		});
	}

	// 顶部输入框
	$('.s_t').focus(function() {
		if ($(this).val() == '') {
			$('span.label_tip').animate({
				opacity : 0
			}, 100, function() {
				$(this).css('display', 'none');
			});
		} else {
			$('span.label_tip').animate({
				opacity : 0
			}, 100, function() {
				$(this).css('display', 'none');
			});
		}
	}).blur(function() {
		var hidev = function() {
			$('.suggest').hide();
		};

		var kl = setTimeout(hidev, 200);
		var turfa = $("#showflash").length;

		if ($(this).val() == '' && turfa != '1') {
			$('span.label_tip').css('display', 'block').animate({
				opacity : 1
			}, 120);
		} else {
			$('span.label_tip').animate({
				opacity : 0
			}, 100, function() {
				$(this).css('display', 'none');
			});
		}
	}).keydown(function() {
		$(this).siblings('span.label_tip').animate({
			opacity : 0
		}, 100, function() {
			$(this).css('display		', 'none');
		});

	});
}

//首页顶部搜索框small
function initSearchInputSmall() {
	$('span.label_tip_small').mouseup(function() {
		$('.s_t_small').focus();
	});
	$(".s_t_small").autocomplete("/search/autoComplete.htm", {
		width : 328,
		scrollHeight : 220,
		selectFirst : false,
		extraParams : {
			category : function() {
				return $('#categorySmall').val();
			},
			keyword : function() {
				return $('#keywordSmall').val();
			}
		},
		formatItem : function(row, i, max) {
			/**
			 * var pattern = /(.*)null$/; var temp = row[0];
			 * if(pattern.test(temp)){ //temp = temp.substr(0, temp.length-4);
			 * temp = temp.match(pattern)[1]; }
			 */
			return row[0];
		},
		formatResult : function(row, i, max) {
			/**
			 * var pattern = /(.*)null$/; var temp = row[0];
			 * if(pattern.test(temp)){ //temp = temp.substr(0, temp.length-4);
			 * temp = temp.match(pattern)[1]; }
			 */
			return row[0];
		}

	}).result(function(event, row) {
		// $("#keyword").val(row[0]);
		searchSmall();
	});

	// 火狐bug 开始就检查输入框提示
	if ($('.s_t_small').val() == '') {
		$('span.label_tip_small').show();

	} else {
		$('span.label_tip_small').animate({
			opacity : 0
		}, 100, function() {
			$(this).css('display', 'none');
		});
	}

	// 顶部输入框
	$('.s_t_small').focus(function() {
		if ($(this).val() == '') {
			$('span.label_tip_small').animate({
				opacity : 0
			}, 100, function() {
				$(this).css('display', 'none');
			});
		} else {
			$('span.label_tip_small').animate({
				opacity : 0
			}, 100, function() {
				$(this).css('display', 'none');
			});
		}
	}).blur(function() {
//		var hidev = function() {
//			$('.suggest').hide();
//		}

//		var kl = setTimeout(hidev, 200);
//		var turfa = $("#showflash").length;

//		if ($(this).val() == '' && turfa != '1') {
		if ($(this).val() == '') {
			$('span.label_tip_small').css('display', 'block').animate({
				opacity : 1
			}, 120);
		} else {
			$('span.label_tip_small').animate({
				opacity : 0
			}, 100, function() {
				$(this).css('display', 'none');
			});
		}
	}).keydown(function() {
		$(this).siblings('span.label_tip_small').animate({
			opacity : 0
		}, 100, function() {
			$(this).css('display		', 'none');
		});

	});
}


function initCategory() {
	// 左侧菜单

	at_home = $('.nav_it').hasClass('home') ? true : false;

	if (!at_home) {
		$('.categorys').hover(function() {
			$('.nav_it').css('display', 'block');

			hide_select();
		}, function() {
			$('.nav_it').css('display', 'none');
			hide_select(false);
		});
	}
	;

	$(".nav_it ul[class!='categorys_bottom']").hover(function() {
		$(".nav_it ul[class!='categorys_bottom']").removeClass("on");
		$(this).addClass("on");
		$(".dis").hide();
		hide_select();
		$(this).next('div').show();

		$(this).next('div').hover(function() {
			$(this).prev('ul').addClass("on");
		}, function() {
			$(this).prev('ul').removeClass("on");
			$(this).hide();
		});
	}, function() {
	});

	$(".nav_it").hover(function() {
	}, function() {
		$(".nav_it ul[class!='categorys_bottom']").removeClass("on");
		$(".dis").hide();

	});
}

function initPrice() {
	// 添加、减少数量
	$("input.price")
			.live(
					'keydown',
					function(e) {
						var keyCode = e.keyCode ? e.keyCode : e.which ? e.which
								: e.charCode;
						if (keyCode == 13) {
							return true;
						}
						sk = e.shiftKey ? e.shiftKey : ((keyCode == 16) ? true
								: false);
						if (sk)
							return false;
					
					}).live('focus', function(event) {

				$(this).val('');

			}).live('blur', function(event) {
				this.value=this.value.replace(/\D/g,'');

				$(this).val(Math.round(this.value));
				if ($(this).val() < 0)
					$(this).val(0);
				if ($(this).val() > 99999)
					$(this).val(99999);
			}).live('keyup', function() {
				this.value=this.value.replace(/\D/g,'');

				// if ($(this).val()<1)$(this).val(1);
				if ($(this).val() > 99999)
					$(this).val(99999);
			});

	// 添加、减少数量
	$("input.price1")
			.live(
					'keydown',
					function(e) {

						var keyCode = e.keyCode ? e.keyCode : e.which ? e.which
								: e.charCode;
						if (keyCode == 13) {
							return true;
						}
						sk = e.shiftKey ? e.shiftKey : ((keyCode == 16) ? true
								: false);
						if (sk)
							return false;
						if (!(keyCode == 46) && !(keyCode == 8)
								&& !(keyCode == 9) && !(keyCode == 37)
								&& !(keyCode == 39))
							if (!((keyCode >= 48 && keyCode <= 57) || (keyCode >= 96 && keyCode <= 105) || keyCode == 110 || keyCode == 190))
								return false;
					
					}).live('focus', function(event) {
						
				$(this).val('');

			}).live('blur', function(event) {
			
				if($(this).val() == ''){
					$(this).val(0);
				}
				//$(this).val(Math.round(this.value));
				if ($(this).val() < 0)
					$(this).val(0);
				if ($(this).val() > 99999)
					$(this).val(99999);
			}).live('keyup', function() {
	

				// if ($(this).val()<1)$(this).val(1);
				if ($(this).val() > 99999)
					$(this).val(99999);
			});
	$('a.minus')
			.live(
					'click',
					function() {
						$(this).siblings('input').val() > 1 ? $(this).siblings(
								'input').val(
								parseInt($(this).siblings('input').val()) - 1)
								: 1;
					});
	$('a.plus').live(
			'click',
			function() {

				if ($(this).siblings('input').val() > 99998) {
					$(this).siblings('input').val(99999);
				} else {
					$(this).siblings('input').val(
							parseInt($(this).siblings('input').val()) + 1);
				}
			});

}

// 弹出层方法
/*
 * @auther ediosn @showBg(dialogdiv,w,h) dialogdiv //要显示的层绑定ID，在这里不用写#号 w //
 * 要显示层的宽度 h // 要显示层的高度 v // 如果加了此层，就显示默认提示层（前三个参数无效） t // 提示内容（自定义文字）
 * closeBg(dialogdiv) dialogdiv// 要关闭的层
 * 
 * 
 */

function showBg(dialogdiv, w, h) {
	if ($.browser.msie && ($.browser.version == "6.0") && !$.support.style) {
		var domThis = $(dialogdiv)[0];
		var wh = $(window).height() / 2;
		$("body").css({
			"background-image" : "url(about:blank)",
			"background-attachment" : "fixed"
		});
		$(dialogdiv).css({
			height : h,
			width : w,
			left : '50%',
			marginLeft : -0.5 * w,
			marginTop : -0.5 * h,
			zIndex : 16000

		});

		domThis.style.setExpression('top',
				'eval((document.documentElement).scrollTop + ' + wh
						+ ' -30) + "px"');

	} else {

		var str = "position: fixed !important;position: absolute; ";
		$(dialogdiv).attr('style', str);

		$(dialogdiv).css({
			height : h,
			width : w,
			left : '50%',
			top : '50%',
			marginLeft : -0.5 * w,
			marginTop : -0.5 * h,
			zIndex : 16000

		});

	}

	var bh = $("body").height();
	var bw = $("body").width();
	$("#fullbg").css({
		height : bh,
		width : bw,
		display : "block"
	});

	$(dialogdiv).show();
}

// 关闭灰色 jQuery 遮罩
function closeBg(dialogdiv) {
	$("#fullbg").hide();
	$(dialogdiv).hide();
	if ($(dialogdiv).hasClass('box_main')) {
		$('.box_main').remove();
	}
}
$(window).resize(function() {
	var bh = $("body").height();
	var bw = $("body").width();
	if ($('#dialog').css('display') == 'block') {
		$("#fullbg").css({
			height : bh,
			width : bw
		});

	}
    var _width = $(window).width();  
    if(_width < 1024){  
      $('#toolBackTop').hide();
		}
    var bt = $('#toolBackTop');
	var sw = $(document.body)[0].clientWidth;
	var limitsw = (sw - 1060) / 2 - 40;
	if (limitsw > 0) {
		limitsw = parseInt(limitsw);
		bt.css("right", 0);
	}

});

// 弹出层方法
/*
 * @auther ediosn @showdemo(v,t)
 * 
 * v // 提示层状态（四种状态:ok(确认)、err(报错)、warn(警告)、query（问号）） t // 提示内容（自定义文字） q //
 * 按钮关闭弹出层后执行的方法，可自定义 b // 第二个按钮关闭弹出层后执行的方法，可自定义
 * 
 */
function showdemo(v, t, q, b) {
	var staticUrl = $("#staticUrl").val();
	if (v == 'ok') {
		v = 'box_button';
	}
	;
	if (v == 'err') {
		v = 'box_button1';
	}
	;
	if (v == 'warn') {
		v = 'box_button2';
	}
	;
	if (v == 'query') {
		v = 'box_button3';
	}
	;
	if ($('#show_info_dialog').length > 0) {
		$('#show_info_dialog').remove();
	}
	if ($('#show_info_dialog').length <= 0) {
		var str = '<div id="show_info_dialog" class="box_main"><div class="box_top"><P class="box_top_title">'
				+ '<span style="margin-left:20px;"><img src="'+staticUrl+'/images/image/box_ico.gif" width="18" height="18" /></span><span style="margin-left:5px;">提示</span>'
				+ '</P><p class="box_top_close"><img src="'+staticUrl+'/images/image/box_close.gif"  /></p></div>'
				+ '<div class="box_middle"><div class='
				+ v
				+ ' id="boxbutton"><p class="box_font">'
				+ t
				+ '</p></div></div><div class="box_bottom"><a class="btn-bar btnmargin140" href="javascript:void(0)"><span>确定</span></a><a class="btn-bar btnmargin20" href="javascript:void(0)"><span>取消</span></a></div></div>';

		$('body').append(str);
	}

	showBg('#show_info_dialog', 400, 215);
	$('.box_top_close img,.btn-bar').click(function() {
		$("#fullbg").hide();
		$("#show_info_dialog").hide();
		//closeBg(show_info_dialog);
	});
	if (typeof q == 'function') {

		$(".btn-bar:eq(0)").unbind('click');
		$(".btn-bar:eq(0)").click(q);
		$(".btn-bar:eq(0)").click(function() {
			closeBg(show_info_dialog);

		});
	}
	;
	if (q == 'no') {
		$('.btn-bar').eq(1).hide();
		$('.btn-bar').eq(0).css('margin-left', '170px');

	}
	;
	if (typeof b == 'function') {
		$(".btn-bar:eq(1)").unbind('click');
		$(".btn-bar:eq(1)").click(b);
		$(".btn-bar:eq(1)").click(function() {
			closeBg(show_info_dialog);
		});
	}
	;

};

/**
 * 隐藏或显示页面上所有不包含class为dialog_select的select对象
 * 
 * @param action
 *            {bool} 为false表示显示其他则隐藏
 * @returns
 */
var hide_select = function(action) {
	var selects = document.getElementsByTagName("SELECT");
	for ( var i = 0; i < selects.length; i++) {
		if (action == false
				&& selects[i].className.indexOf('dialog_select') < 0) {
			selects[i].style.display = "inline";
		} else if (selects[i].className.indexOf('dialog_select') < 0) {
			selects[i].style.display = "none";
		}
	}
	;
};

/**
 * 微信效果
 */
function close_ufo() {
	if (!$('#wx_ufo').hasClass('yes_c')) {

		$('#wx_tb').css({
			left : '865px',
			top : '30px;',
			height : '40px',
			width : '40px',
			opacity : '1',
			marginTop : '0px'
		});
		$('#wx_ufo').css({
			left : '905px',
			top : '0px;',
			height : '110px',
			width : '110px',
			opacity : '0',
			marginTop : '-20px'
		});
		$('#wx_ufo').animate({
			left : '865px',
			top : '30px;',
			height : '40px',
			width : '40px',
			opacity : '0',
			marginTop : '30px'
		}, 800);
		$('#wx_tb').fadeIn();
		$('#wx_ufo').addClass('yes_c');
		$('#wx_ufo a').hide();

	} else {
		$('#wx_ufo').css({
			display : 'none',
			left : '905px',
			top : '0px;',
			height : '110px',
			width : '110px',
			opacity : '1',
			marginTop : '-20px'
		});
		$('#wx_tb').css({
			left : '865px',
			top : '30px;',
			height : '40px',
			width : '40px',
			opacity : '1',
			marginTop : '0px'
		});
		$('#wx_tb').animate({
			left : '905px',
			top : '0px;',
			height : '110px',
			width : '110px',
			opacity : '0',
			marginTop : '-20px'
		}, 200);
		$('#wx_ufo').stop().fadeIn();

		$('#wx_ufo').removeClass('yes_c');
		$('#wx_ufo a').show();

	}
}

// 选项卡
$(document).ready(function() {
	init();
});

function init() {

	$(".map11 .map_right img").eq(0).css('display', 'block');

	$('.qlink span a').hover(function() {
		$(this).parent('span').addClass('newv');
	}, function() {
		$(this).parent('span').removeClass('newv');
	});
	$('.tabus_box div a img,.left_img a img').hover(function() {
		$(this).css('opacity', 0.7);
	}, function() {
		$(this).css('opacity', 1);
	});

	$('.tabus').children('div').children('span').click(
			function() {
				$(this).parent('div').children('span').removeClass(
						'tabchoose tabright_choose ad_choose');
				$(this).addClass('tabchoose tabright_choose ad_choose');
				$(this).parent('div').parent('div').children('div').hide();
				$(this).parent('div').parent('div').children('div').eq(0)
						.show();
				var tab_bum = $(this).parent('div').children('span')
						.index(this) + 1;
				$(this).parent('div').parent('div').children('div').eq(tab_bum)
						.show();

			});
	$('.tabus1').children('div').children('div').children('span')
			.click(
					function() {
						$(this).parent('div').children('span').removeClass(
								'ad_choose');
						$(this).addClass('ad_choose');
						$(this).parent('div').parent('div').parent('div')
								.children('div').hide();
						$(this).parent('div').parent('div').parent('div')
								.children('div').eq(0).show();

						var tab_bum = $(this).parent('div').children('span')
								.index(this) + 1;
						$(this).parent('div').parent('div').parent('div')
								.children('div').eq(tab_bum).show();
					});
	$('.map_left p').click(function() {
		$('.map_left p').removeClass('yd_choose');
		$(this).addClass('yd_choose');
		$('.map_right img').hide();
		$('.map_right img').eq($(this).index()).show();
	});
	var n = 3;

	$('.message_l:lt(' + n + ')').show();
	$('.message_l:odd').addClass('bs');
	$('.message_dot .dot').mouseover(function() {
		$('.message_dot .dot').removeClass('now_in');
		$(this).addClass('now_in');
		if ($(this).index() == 1) {
			$('.message_l').hide();
			$('.message_l:lt(' + n + ')').show();
		} else if ($(this).index() == $('.message_dot .dot:last').index()) {
			$('.message_l').hide();

			$('.message_l:gt(' + 5 + ')').show();
		} else {
			var m = $('.message_l:last').index() - n;
			$('.message_l').show();
			var x = n * ($(this).index() - 1);
			$('.message_l:lt(' + 3 + ')').hide();
			$('.message_l:gt(' + 5 + ')').hide();
		}

	});
};

//返回顶部
$(document).ready(function() {
	var bt = $('#toolBackTop');
	var sw = $(document.body)[0].clientWidth;
	var limitsw = (sw - 1060) / 2 - 40;
	if (limitsw > 0) {
		limitsw = parseInt(limitsw);
		bt.css("right", 0);
	}
	
	var isShow = false;
    var isHidd = true;
	$(window).scroll(function() {
		
		//底部返回页面的固定
		var st = $(window).scrollTop();
		var _width = $(window).width(); 
	
		if (st > 500 && _width>1330) {
			bt.show();
		} else {
			bt.hide();
		}
		
		//顶部搜索框的固定
		var scrollTop = $(window).scrollTop();
		
		var tskeep;
		if($('.top_ad').css('display')=="none"){
			tskeep=170;
		}else{tskeep=340;};
		
	    
       if(scrollTop>tskeep){
    	   $('.small_logo_area').show();
    	   if(!isShow){
    		   isShow = true;
    		   isHidd = false;
    		   $('#keywordSmall').val($('#keyword').val());
    		   $('#categorySmall').val($('#category').val());
    	   }
       }else{
		   $('.small_logo_area').hide();
		   if(!isHidd){
			   isShow = false;
    		   isHidd = true;
			   $('#keyword').val($('#keywordSmall').val());
			   $('#category').val($('#categorySmall').val());
		   }
	   };
		
		
	});
});


// 详情页面飞入购物车
function fly_cart(isFlyToCart) {
	//实现飞入购物车的效果
	if(isFlyToCart != null && isFlyToCart){
		var boximg = $(".product_areaimg").find('img');
	
		var removep = function() {
			$("._box").remove();
		};
		var f_top = (boximg.offset().top - $(document)
				.scrollTop())
				+ 'px';
		var f_left = boximg.offset().left + 'px';
		var f_width = boximg.width();
		var f_height = boximg.height();
		$(".product_areaimg").append(
				' <img class="_box" src="/static/images/imgsrc1.jpg" width="'
						+ f_width + '" height="' + f_height
						+ '" style="position: fixed;top:'
						+ f_top + ';left:' + f_left
						+ '; "/> ');
		var st = $(window).scrollTop();
		 var dddd=$('.car_ctn').offset().top-st;
		 
         if(st >= 0 && st <= 517){
			$("._box").animate({
				left : '1028px',
				top : dddd,
				height : '26px',
				width : '180px',
				opacity : '0'
			}, 500);
			setTimeout(removep, 500);
		} else {
			var s_top = $(document).scrollTop();
			var o_top = $('.gwc_top11').offset().top
					- s_top;
			var o_width = $('.gwc_top11').width();
			var o_left = $('.gwc_top11').offset().left;
			var o_height = $('.gwc_top11').height();
			$("._box").animate({
				left : o_left,
				top : o_top,
				height : o_height,
				width : o_width,
				opacity : '0'
			}, 500);
			setTimeout(removep, 500);
		}
	}
};



//搜索结果列表页面飞入购物车
function fly_cart_merchandiselist(fbox) {
	
	if(fbox != null){
		var boximg = $("." + fbox + "").find('a');
		var content = boximg.html().trim();
		var url = boximg.attr('href');
	
	
		var removep = function() {
			$("._box").remove();
		};
		var f_top = (boximg.offset().top
				- $(document).scrollTop() - 12)
				+ 'px';
		var f_left = boximg.offset().left + 'px';
	
		var f_width = boximg.width();
		var f_height = boximg.height();
		
		$("." + fbox + "")
				.append(
						'<a class="_box" width="'
								+ f_width
								+ '" height="'
								+ f_height
								+ '"  style="position: fixed;  top:'
								+ f_top
								+ ';  left:'
								+ f_left
								+ ';color:#007BCF;font-weight:bold; "><img src='+url+' width="15" height="15" />'+content+'</a> ');
	
		var st = $(window).scrollTop();
		var dddd = $('.car_ctn').offset().top - st;
	
		if (st >= 0 && st <= 517) {
			$("._box").animate({
				left : '1028px',
				top : dddd,
				height : '40px',
				width : '281px',
				opacity : '0'
			}, 500);
	
			setTimeout(removep, 500);
	
		} else {
			var s_top = $(document).scrollTop();
			var o_top = $('.gwc_top11').offset().top - s_top;
			var o_width = $('.gwc_top11').width();
			var o_left = $('.gwc_top11').offset().left;
			var o_height = $('.gwc_top11').height();
	
			$("._box").animate({
				left : o_left,
				top : o_top,
				height : o_height,
				width : o_width,
				opacity : '0'
			}, 500);
			setTimeout(removep, 500);
	
		}

	}

}




//搜索结果大图页面飞入购物车
function fly_cart_merchandisepic(fbox) {

	if(fbox != null){

		var boximg = $("." + fbox + "").find('img');
		var url = boximg.attr('src');
	

		var removep = function() {
			$("._box").remove();
		};
		var f_top = (boximg.offset().top - $(document).scrollTop())+ 'px';
		var f_left = boximg.offset().left + 'px';
	
		var f_width = boximg.width();
		var f_height = boximg.height();
	
		$("." + fbox + "")
				.append(
						'<img src="'+url+'" class="_box" width="'
								+ f_width
								+ '" height="'
								+ f_height
								+ '"  style="position: fixed; border-bottom:none; top:'
								+ f_top + ';  left:' + f_left
								+ ';"></>');
	
		var st = $(window).scrollTop();
		var dddd = $('.car_ctn').offset().top - st;
		if (st >= 0 && st <= 517) {
			$("._box").animate({
				left : '1028px',
				top : dddd,
				height : '68px',
				width : '90px',
				opacity : '0'
			}, 500);
	
			setTimeout(removep, 500);
	
		} else {
			var s_top = $(document).scrollTop();
			var o_top = $('.gwc_top11').offset().top - s_top;
			var o_width = $('.gwc_top11').width();
			var o_left = $('.gwc_top11').offset().left;
			var o_height = $('.gwc_top11').height();
	
			$("._box").animate({
				left : o_left,
				top : o_top,
				height : o_height,
				width : o_width,
				opacity : '0'
			}, 500);
			setTimeout(removep, 500);
	
		}

	}

}


