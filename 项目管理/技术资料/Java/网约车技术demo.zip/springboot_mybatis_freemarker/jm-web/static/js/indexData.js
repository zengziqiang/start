var picIndex = 5;
var picList;
$(document).ready(function(){
	//加载首页图片
	//loadIndexPic();
	//innerIndexPic(1,picIndex);
	
	//加载资讯栏 -- 已经改成非ajax调用
	//loadInformation(); 
	
	//加载下载 -- 已经改成非ajax调用
	//loadDownloadInfo();

	//加载栏目信息
	//getColumnInfo();
	
	//加载排行榜 -- 已经改成非ajax调用
	//loadRank(); 
	
	//加载客户评价 -- 已经改成非ajax调用
	//loadCustService();
	
	//初始化页面脚本
	init();
});

//加载首页图片
function loadIndexPic(){
	var url = '/front/indexPic/list.json?'+Math.random();
	$.ajax({   
		type : "get",   
		url : url,   
		async : false,   
		success : function(data){   
			picList = parserToJson(data);
		}   
	}); 
}

function getBeginIndex(index){
	var tempIndex = index-16;
	var isFirst = true;
	while(tempIndex>6){
		tempIndex = tempIndex - 6;
		if(isFirst){
			tempIndex = tempIndex - 1;
			isFirst = false;
		}
	}
	if(!(tempIndex >=3 && tempIndex <=6) ){
		return "";
	}else {
		return index-(tempIndex - 3);
	}
}

//将页面数据加入到页面
function innerIndexPic(startIndex,endIndex){
	for(var i=startIndex;i<endIndex;i++){
		var currentIndex = i;
		if(picList[currentIndex] != undefined){
			$('#indexPic_'+currentIndex).attr('src',picList[currentIndex].url+'');
			if(picList[currentIndex].link != null ){
				if((picList[currentIndex].link).indexOf('/front/manufacturerTopic/view.htm')>=0 && getBeginIndex(currentIndex) != ''){
					$('#indexPic_'+currentIndex).parent().attr('href',picList[currentIndex].link+'&beginPicIndex='+getBeginIndex(currentIndex));
				}else {
					$('#indexPic_'+currentIndex).parent().attr('href',picList[currentIndex].link);
				}
				if(picList[currentIndex].openType==1){
					$('#indexPic_'+currentIndex).parent().attr('target','_blank');
				}
			}
		}
	}
}


/**************************加载栏目及明细开始********************************************/

//加载首页栏目信息
function getColumnInfo(){
	getAllColumn();
}

//得到所有栏目
function getAllColumn(){
	var url = '/front/info/column/selectAllColumnGroupByType.json';
	var columnList;
	$.ajax({   
		type : "get",   
		url : url,   
		async : false,   
		success : function(data){   
			data = parserToJson(data);
//			$.each(data['typeOneList'],function(i,row){
//				var tempIndex = picIndex;
//				innerHtmlColumnInfoOne(i,row);
//				innerIndexPic(tempIndex,picIndex);
//			});
//			picIndex=8;
//			$.each(data['typeTwoList'],function(i,row){
//				var tempIndex = picIndex;
//				innerHtmlColumnInfoTwo(i,row);
//				innerHtmlColumnInfoTwoTab(i,row);
//				innerIndexPic(tempIndex,tempIndex+3);
//			});
//			picIndex=17;
//			$.each(data['typeThreeList'],function(i,row){
//				var tempIndex = picIndex;
//				innerHtmlColumnInfoThree(i,row);
//				innerIndexPic(tempIndex,picIndex);
//			});
		}   
	}); 
}

//得到栏目下的药品信息
function getcolumnInfoByColumnId(columnId,size){
	var url = '/front/info/columnInfo/selectColumnInfoByColumnIdForIndex.json?'+Math.random();
	var columnList;
	$.ajax({   
		type : "get",   
		url : url,   
		data:{columnId:columnId,size:size},
		async : false,   
		success : function(data){   
			columnList = parserToJson(data);
		}   
	}); 
	return columnList;
}

function selectWrittnWords(columnId,page,rows){
	var url = '/front/news/newslist.json';
	var list;
	$.ajax({   
		type : "get",   
		url : url,   
		data:{columnId:columnId,page:page,rows:rows},
		async : false,   
		success : function(data){   
			list = parserToJson(data);
		}   
	}); 
	return list;
}


//将栏目明细数据加入到区域3的栏目
function innerHtmlColumnInfoThree(index,column){
	var columnInfoHtml= 
	'<div class="clearit blank10"></div> '+
	'<div class="content_middle_box">'+
	'<div class="content_box_title">'+
	'<span>'+column.name+'</span>'+
	'<dl>'+
	'<dt>热门产品推荐：</dt>';
	var writtnWordsList = selectWrittnWords(column.columnId,1,6);
	$.each(writtnWordsList.rows,function(i,row){
		columnInfoHtml=columnInfoHtml+
		'<dd><a href="'+row.twwLink+'">'+row.twwName+'</a></dd>';
	});
	columnInfoHtml=columnInfoHtml+
	'</dl>'+
	'<em><a href="'+column.link+'">更多>></a></em>'+
	'</div>'+
	'<div class="blank10"></div>'+
	'<div class="content_box_main">'+
	'<div><a href="javascript:void(0);"><img onerror="this.src=\'/static/images/nophoto.png\'" id="indexPic_'+(picIndex++)+'" src="" width="170" height="250" /></a></div>'+
	'<div class="content_table_box">'+
	'<table width="100%" cellspacing="0" cellpadding="0" border="0" class="table-03">'+
	'  <tr>'+
	'    <th>药品名称/规格</th>'+
	'    <th>生产厂家</th>'+
	'    <th>会员价</th>'+
	'    <th>零售价</th>'+
	'    <th>库存 </th>'+
	'    <th>数量</th>'+
	'    <th>操作</th>'+
	'  </tr>';
	var columnInfos = getcolumnInfoByColumnId(column.columnId,7);
	$.each(columnInfos,function(i,row){
		columnInfoHtml = columnInfoHtml +
		'  <tr>'+
		'    <td class="drug_name"><a target="blank" href="/front/merchandise/detail.htm?id='+row.merchandiseId+'" title="'+row.merchandiseName+'" >'+row.merchandiseName+'</a></td>'+
		'    <td class="drug_company"><span title="'+(row.manufacturerId==null?'':row.manufacturerId)+'">'+(row.manufacturerId==null?'':row.manufacturerId)+'</span></td>';
		if(isCustLogin){
			columnInfoHtml=columnInfoHtml+
			'    <td><span>'+row.formatMermberPrice+'</span></td>';
		}else {
			columnInfoHtml=columnInfoHtml+
			'    <td><span>--</span></td>';
		}
		columnInfoHtml=columnInfoHtml+
		'    <td>'+row.formatRetailPrice+'</td>'+
		'    <td>'+formatStorage(row.storageNumber,row.merchandiseId)+'</td>'+
		'    <td><a class="minus" href="javascript:void(0);"><img src="/static/images/minus.gif"></a>';
		if(row.isDecimal){
			columnInfoHtml=columnInfoHtml+
			' <input name="buyNumber" class="price1" value="1"> ';
		}else {
			columnInfoHtml=columnInfoHtml+
			' <input name="buyNumber" class="price" value="1"> ';
		}
		columnInfoHtml=columnInfoHtml+
		'<a class="plus" href="javascript:void(0);"><img src="/static/images/plus.gif"></a></td>'+
		'    <td><button class="small_btn" onclick="localAddCart('+row.merchandiseId+',this)"></button></td>'+
		'  </tr>';		
	});
	columnInfoHtml = columnInfoHtml +
	'</table>'+
	'</div>'+
	'<div class="content_img_box" >'+
	'<div class="tabus1" id="lunb'+(index+1)+'" >'+
	'<div class="lunblock"><a href="javascript:void(0);"><img onerror="this.src=\'/static/images/nophoto.png\'" id="indexPic_'+(picIndex++)+'" src="" width="220" height="110" /></a></div>'+
	'</div>'+
	'<div class="small_ad">'+
	'<a href="javascript:void(0);"><img onerror="this.src=\'/static/images/nophoto.png\'" id="indexPic_'+(picIndex++)+'" src="" width="105" height="60" /></a>'+
	'  <a href="javascript:void(0);"><img onerror="this.src=\'/static/images/nophoto.png\'" id="indexPic_'+(picIndex++)+'" src="" width="105" height="60" /></a>'+
	'  <a href="javascript:void(0);"><img onerror="this.src=\'/static/images/nophoto.png\'" id="indexPic_'+(picIndex++)+'" src="" width="105" height="60" /></a>'+
	'  <a href="javascript:void(0);"><img onerror="this.src=\'/static/images/nophoto.png\'" id="indexPic_'+(picIndex++)+'" src="" width="105" height="60" /></a>'+
	'</div>'+
	'</div>'+
	'</div>'+
	'</div>';
	if(index == 0){
		columnInfoHtml = columnInfoHtml +
			'<div class="clearit blank10"></div>'+
			'<div class="indexgg"><a href="javascript:void(0);"><img onerror="this.src=\'/static/images/nophoto.png\'" id="indexPic_'+(picIndex++)+'" src="/static/images/guanggao2.jpg" width="990" height="60"/></a></div>';
	}
$('#columnAreaThree').append(columnInfoHtml);
}

//将栏目明细数据加入到区域1的栏目
function innerHtmlColumnInfoOne(index,column){
	var columnInfoHtml= 
	'<div class="tabus">'+
	 
	 '<div class="tabus_title">'+
	 '<span class="tabchoose">促销精选</span>'+
	 '</div>'+
	 
	 '<div class="tabus_main">';
	var columnInfos = getcolumnInfoByColumnId(column.columnId,3);
	$.each(columnInfos,function(i,row){
		columnInfoHtml = columnInfoHtml +
		 '<div class="tabus_box">'+
		 '<div><a href="javascript:void(0);"><img onerror="this.src=\'/static/images/nophoto.png\'" id="indexPic_'+(picIndex++)+'" src="/static/images/y_img.jpg" width="90" height="90" /></a></div>'+
		'<div>'+
		 '<p><a target="blank" href="/front/merchandise/detail.htm?id='+row.merchandiseId+'" title="'+row.merchandiseName+'">'+substrVal(row.merchandiseName,7)+'</a></p>'+
		 '<p class="yuanj">零售价:'+row.formatRetailPrice+'元</p>';
		if(isCustLogin){
			columnInfoHtml=columnInfoHtml+
			 '<p class="xianj">会员价:'+row.formatMermberPrice+'元</p>';
		}else {
			columnInfoHtml=columnInfoHtml+
			'<p class="xianj">会员价:--</p>';
		}
		columnInfoHtml=columnInfoHtml+
		 '<p><span><a href="javascript:void(0);" onclick="openBuyWindow('+row.merchandiseId+');">加入购物车</a></span><span><img src="/static/images/icon.gif" width="5" height="10" /></span> </p>'+
		' </div>'+
		 '</div>';
	});
	 columnInfoHtml = columnInfoHtml +
	'</div>'+
	 '</div>';
$('#columnAreaOne').append(columnInfoHtml);
}

//将栏目明细数据加入到区域2的栏目
function innerHtmlColumnInfoTwo(index,column){
	var columnInfoHtml= 
	'<div';
	if(index != 0){
		 columnInfoHtml = columnInfoHtml + ' style="display:none"'; 
	 }
	columnInfoHtml = columnInfoHtml +
	 ' class="tabus_main">';
	
	 var columnInfos = getcolumnInfoByColumnId(column.columnId,3);
	 $.each(columnInfos,function(i,row){
		columnInfoHtml = columnInfoHtml +
		'<div class="tabus_box">'+
		 '<div><a href="javascript:void(0);"><img onerror="this.src=\'/static/images/nophoto.png\'" id="indexPic_'+(picIndex++)+'" src="/static/images/y_img.jpg" width="90" height="90" /></a></div>'+
		 
		 '<div>'+
		 '<p><a target="blank" href="/front/merchandise/detail.htm?id='+row.merchandiseId+'"  title="'+row.merchandiseName+'">'+substrVal(row.merchandiseName,7)+'</a></p>'+
		 '<p class="yuanj">零售价:'+row.formatRetailPrice+'元</p>';
		 if(isCustLogin){
			columnInfoHtml=columnInfoHtml+
			 '<p class="xianj">会员价:'+row.formatMermberPrice+'元</p>';
		 }else {
			 columnInfoHtml=columnInfoHtml+
			 '<p class="xianj">会员价:--</p>';
		}
		 columnInfoHtml=columnInfoHtml+
		 '<p><span><a href="javascript:void(0);" onclick="openBuyWindow('+row.merchandiseId+');">加入购物车</a></span><span><img src="/static/images/icon.gif" width="5" height="10" /></span> </p>'+
		 '</div>'+
		 '</div>';
	 });
	 columnInfoHtml = columnInfoHtml + '</div>';
$('#columnAreaTwo').append(columnInfoHtml);
}
//注入区域2栏目TAB
function innerHtmlColumnInfoTwoTab(index,column){
	var columnInfoHtml= 
		 '<span';
		 if(index == 0){
			 columnInfoHtml = columnInfoHtml + ' class="tabchoose"'; 
		 }
		 columnInfoHtml = columnInfoHtml +'>'+column.name+'</span>';
$('#columnAreaTwoTab').append(columnInfoHtml);
}
/**************************加载栏目及明细结束********************************************/



/**************************加载排行榜开始********************************************/

//加载排行榜
function loadRank(){
	getSaleRankInfo();
	getClickRankInfo();
}
//查询销售排行信息
function getSaleRankInfo(){
	var url = '/front/rank/selectMerchandiseForSaleRank.json';
	var list;
	$.ajax({   
		type : "get",   
		url : url, 
		data:{page:1,rows:10},
		async : true,   
		success : function(data){   
			list = parserToJson(data);
			$.each(list,function(i,row){
				innerSaleRank(i,row);
			});
		}   
	}); 
}
//查询点击排行信息
function getClickRankInfo(){
	var url = '/front/rank/selectClickRank.json';
	var list;
	$.ajax({   
		type : "get",   
		url : url, 
		data:{page:1,rows:10},
		async : true,   
		success : function(data){   
			list = parserToJson(data);
			$.each(list,function(i,row){
				innerClickRank(i,row);
			});
		}   
	}); 
}

//页面注入点击排行
function innerClickRank(i,row){
	var innerHtml='<li><a target="blank" href="/front/merchandise/detail.htm?id='+row.merchandiseId+'"  title="'+row.merchandiseName+'">'+(i+1)+'.'+substrVal(row.merchandiseName,12)+'<span>'+row.num+'次</span></a></li>'; 
	$('#clickRank').append(innerHtml);
}
//页面注入销售排行
function innerSaleRank(i,row){
	var innerHtml='<li><a target="blank" href="/front/merchandise/detail.htm?id='+row.merchandiseId+'"  title="'+row.merchandiseName+'">'+(i+1)+'.'+substrVal(row.merchandiseName,12)+'<span>'+row.saleNumber+row.merchandiseUnit+'</span></a></li>'; 
	$('#saleRank').append(innerHtml);
}

/**************************加载排行榜结束********************************************/


/*************************加载客户评价开始**************************************************/

function loadCustService(){
	selectCustService(1,9);
}

//异步查询客户评价信息
function selectCustService(page,rows){
	var url = '/front/custService/list.json';
	var list;
	$.ajax({   
		type : "get",   
		url : url, 
		data:{page:page,rows:rows,type:2,status:1},
		async : false,   
		success : function(data){   
			list = parserToJson(data);
			innerCustService(list);
		}   
	}); 
}

function innerCustService(list){
	$('#custServiceArea').html('');
	$.each(list.rows,function(i,row){
		var innerHtml = 
		'<div class="message_l">'+
		'<div class="message_one" >'+
		'<p class="p_user">用户:<span>'+row.custName+'</span></p> <P class="p_din">订单号：'+row.orderCode+'</P><p class="p_time">评价时间：'+row.createDateString+'</p>'+
		'</div>'+
		'<div class="clearit"></div>'+
		'<div class="message_two">'+
		'<p>评价：'+row.content+'</p>'+
		'</div>'+
		'<div class="message_three">'+
		'<p>回复：';
		if(row.reply != null){
			innerHtml = innerHtml+row.reply;
		}
		innerHtml = innerHtml+
		'</p>'+
		'</div>'+
		'</div>';
		$('#custServiceArea').append(innerHtml);
	});
}

/*************************加载客户评价结束**************************************************/

/*************************加载资讯开始**************************************************/
function loadInformation(){
	selectInfomation(1,5,7,"newsAreaOne");
	selectInfomation(1,5,8,"newsAreaTwo");
}

function selectInfomation(page,rows,timTitid,areaName){
	var url = '/front/infomation/list.json';
	var list;
	$.ajax({   
		type : "get",   
		url : url, 
		data:{page:page,rows:rows,type:2,timTitid:timTitid},
		async : true,   
		success : function(data){   
			list = parserToJson(data);
			innerInformation(list,areaName);
		}   
	}); 
	return list;
}

function innerInformation(data,objName){
	$('#'+objName).html('');
	$.each(data.list,function(i,row){
		var innerHtml = 
			'<li><a href="/front/infomation/newsdetail.htm?timId='+row.timId+'&&title='+encodeURI(row.titName)+'">·'+row.timTitle+'</a></li>';
		$('#'+objName).append(innerHtml);
	});
}

/*************************加载资讯结束**************************************************/

/*************************加载下载信息开始**************************************************/

function loadDownloadInfo(){
	selectDownloadInfo(1,5,"newsAreaThree");
}

function selectDownloadInfo(pageNum,pageSize,areaName){
	var url = '/front/download/list.json?'+Math.random();
	var dataResult;
	$.ajax({   
		type : "get",   
		url : url,   
		data:{page:pageNum,rows:pageSize},
		async : true,   
		success : function(data){   
			dataResult = parserToJson(data);
			innerDownload(dataResult,areaName);
		}   
	});
	return dataResult;
}

function innerDownload(data,objName){
	$('#'+objName).html('');
	$.each(data.rows,function(i,row){
		var innerHtml = 
			'<li><a href="'+row.link+'">·'+row.title+'</a></li>';
		$('#'+objName).append(innerHtml);
	});
}
/*************************加载下载信息结束**************************************************/


function localAddCart(merchandiseId,obj){
	var buyNumber = $(($(obj).parent().parent().find('[name=buyNumber]'))[0]).val();
	add_one_merchandise_to_cart2(merchandiseId,buyNumber)
}


