function openMessageBox(){
	//$("#messageBox").html("<div class=\"content\"><div class=\"title\">提示信息<a  href=\"#\" class=\"colse\"></a></div></div>");
	//alert($("#messageBox").html);
}