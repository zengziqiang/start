﻿
$(document).ready(function() {
	$('#downloadArea').click(function(){
		loadDownloadInfo();
	});
	if(menuId != '' && menuId != undefined){
		$('#'+menuId).click();
	}
	initTitle(4);
});		 

function loadDownloadInfo(){
	$('#titlea').text($('#downloadArea').text());
	$('#titlep').text($('#downloadArea').text());
	pageInit(loadDownloadList,10);
}

function loadDownloadList(pageNum,pageSize){
	$('#newsList').html('');
	var data = selectDownloadInfo(pageNum,pageSize);
	innerDownload(data.rows);
	return data.pagination;
}

function selectDownloadInfo(pageNum,pageSize){
	var url = '/front/download/list.json?'+Math.random();
	var dataResult;
	$.ajax({   
		type : "get",   
		url : url,   
		data:{page:pageNum,rows:pageSize},
		async : false,   
		success : function(data){   
			dataResult = parserToJson(data);
		}   
	});
	return dataResult;
}

function innerDownload(downloadList){
	$.each(downloadList,function(i,row){
		
		if(row.openType == 1){
			var url = row.link;
			var innerHtml = '<li><a href="#" onclick=gotoUrl("'+url+'");>'+row.title+'</a><span>'+row.formatCreateTime+'</span></li>';
		}else {
			var innerHtml = '<li><a href="#" onclick=gotoUrl("'+row.link+'");>'+row.title+'</a><span>'+row.formatCreateTime+'</span></li>';
		}
		$('#newsList').append(innerHtml);
	});
}

function gotoUrl(url){
	window.open(url);
}
