var isEdit = false;
var tacticID=0;

var editData = [];


/**
 * 获取买方
 */
function getCust(id) {
	$('#custDiv').window('open');
	loadCustomerType(id);
	$('#custTable').datagrid({
		fit : true,
		nowrap : true,
		striped : true,
		fitColumns : false,
		rownumbers: true,
		toolbar : "#cust_bar",
		url : '/admin/tactic/getCustomer.htm',
		method : 'post',
		pageSize : 10,
		pageNumber : 1,
		pagination : true,
		singleSelect : true,
		idField : 'customerId',
		frozenColumns : [ [ {
			field : 'customerId',
			checkbox : true
		} ] ],
		columns : [ [ {
			field : 'customerName',
			title : '客户名称',
			align : 'left',
			resizable : true,
			formatter : function(customerName) {
				return customerName ? customerName : "";
			}
		}, {
			field : 'customerTypeName',
			title : '客户类型',
			align : 'left',
			resizable : true,
			formatter : function(customerName) {
				return customerName ? customerName : "";
			}
		}, {
			field : 'customerAreaName',
			title : '客户区域',
			align : 'left',
			resizable : true,
			formatter : function(customerAreaName) {
				return customerAreaName ? customerAreaName : "";
			}
		}

		] ]
	});

}

/**
 * 根据条件查询客户
 */
function searchCust() {
	$('#custTable').datagrid('options').queryParams = {
		"customerShortCode" : $("#customerName").val(),
		"customerName" : $("#customerName").val(),
		"customerTypeName" : $("#customerTypeName").combobox('getText')
	};
	$("#custTable").datagrid('reload');
}

/**
 * 提交选择的客户
 */
function sendCust() {
	var row = $('#custTable').datagrid('getSelected');
	if (!row) {
		$.messager.alert('警告', '请选择一个客户');
		return;
	}
	$('#cName').val(row.customerName);
	$('#cType').val(row.customerTypeName);
	$('#cArea').val(row.customerAreaName);
	$('#custId').val(row.customerId);
	$('#custDiv').window('close');
}

/**
 * 选择客户的取消
 */
function custBtnCancle() {
	$('#custDiv').window('close');
}




/**
 * 加载客户列表
 * 
 */

function loadCustomerType(id) {
	$(id).combobox({
		url : '/admin/tactic/getCustomerType.htm',
		valueField : 'id',
		textField : 'text',
		panelHeight : 'auto'
	});
}




