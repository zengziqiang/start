function checkType() {
	var type_name = $("#checkType").attr("value");

	if (type_name == 0) {
		alert("请选择一个统计栏目");
	} else {
		if (type_name == 1) {
			showRegisterData();
		} else if (type_name == 2) {
			showEorderData();
		} else if (type_name == 3) {
			showNoEorderData();
		} else if (type_name == 4) {
			showBranchEorderData();
		} else if (type_name == 5) {
			showSaleFairsData();
		} else if (type_name == 6) {
			showSellDetailData();
		} else if (type_name == 8) {
			showBasket();
		} else if (type_name == 9) {
			showNewProduct();
		} else if (type_name == 10) {
			showAttention();
		}
	}
}
// 推广栏统计
function showTGLData() {
	$('#searchTGLTable').datagrid({
		nowrap : true,
		striped : true,
		fitColumns : true,
		toolbar : "#toolbar",
		url : '/admin/tgltj/index.json',
		method : 'post',
		pagination : true,
		singleSelect : false,
		idField : 'custId',
		toolbar : [ {
			text : '查询',
			disabled : false,
			iconCls : 'icon-search',
			handler : function() {
				$("#searchTGL").window("center");
				$("#searchTGL").window("open");
			}
		}/*, {
			text : '导出Excel',
			disabled : false,
			iconCls : 'icon-save',
			handler : function() {
				window.location = "/admin/tgltj/excelRegister.htm";
			}
		} */],
		columns : [ [ {
			title : '买方名称',
			field : 'custName',
			resizable : true,
		}, {
			title : '卖方名称',
			field : 'branchName',
			resizable : true,

		}, {
			title : '客户账号',
			field : 'loginName',
			align : 'left',
			resizable : true,
		}, {
			title : '推广员账号',
			field : 'pyName',
			align : 'left',
			resizable : true,
		}, {
			title : '业务员姓名',
			field : 'ywyName',
			align : 'left',
			resizable : true,
		}, {
			title : '业务员手机号',
			field : 'ywyTel',
			align : 'left',
			resizable : true,
		}, {
			title : '申请人账号',
			field : 'qtName',
			align : 'left',
			resizable : true,
		}, {
			title : '登陆次数',
			field : 'loginCount',
			align : 'left',
			resizable : true,
		}, {
			title : '审批日期',
			field : 'modifiedTime',
			align : 'left',
			resizable : true,
			formatter : function(dateString) {
				return dateString.substr(0, 10);
			}
		} ] ]
	});

}
// 注册用户
function showRegisterData() {
	$('#searchRegisterCustTable').datagrid({
		nowrap : true,
		striped : true,
		fitColumns : true,
		toolbar : "#toolbar",
		url : '/admin/analysis/register.json?',
		method : 'post',
		pagination : true,
		singleSelect : false,
		idField : 'custId',
		toolbar : [ {
			text : '查询',
			disabled : false,
			iconCls : 'icon-search',
			handler : function() {
				$("#searchRegister").window("center");
				$("#searchRegister").window("open");
			}
		}, {
			text : '导出Excel',
			disabled : false,
			iconCls : 'icon-save',
			handler : function() {
				excelRegister();
			}
		} ],
		columns : [ [ {
			title : '卖方名称',
			field : 'branchName',
			resizable : true

		}, {
			title : '买方名称',
			field : 'custName',
			resizable : true
		}, {
			title : '区域',
			field : 'areaName',
			align : 'left',
			resizable : true
		}, {
			title : '联系人',
			field : 'custMan',
			align : 'left',
			resizable : true
		}, {
			title : '联系电话',
			field : 'manTel',
			align : 'left',
			resizable : true
		}, {
			title : '企业联系人电话',
			field : 'mobile',
			align : 'left',
			resizable : true
		}, {
			title : '客户类型',
			field : 'custType',
			align : 'left',
			resizable : true
		}, {
			title : '报价方式',
			field : 'custLevel',
			align : 'left',
			resizable : true
		}, {
			title : '客户积分',
			field : 'custScore',
			align : 'left',
			resizable : true
		}, {
			title : '客户编码',
			field : 'custBh',
			align : 'left',
			resizable : true
		}, {
			title : '客户内码',
			field : 'custNm',
			align : 'left',
			resizable : true
		}, {
			title : '帐号名',
			field : 'loginName',
			align : 'left',
			resizable : true
		}, {
			title : '登陆次数',
			field : 'loginCount',
			align : 'left',
			resizable : true
		}, {
			title : '注册日期',
			field : 'createDate',
			align : 'left',
			resizable : true,
			formatter : function(dateString) {
				return dateString.substr(0, 10);
			}
		} ] ]
	});

}

// 订单用户
function showEorderData() {
	$('#searchRegisterCustTable').datagrid({
		nowrap : true,
		striped : true,
		fitColumns : true,
		toolbar : "#toolbar",
		url : '/admin/analysis/eorder.json',
		method : 'post',
		pagination : true,
		singleSelect : false,
		idField : 'custId',
		toolbar : [ {
			text : '查询',
			disabled : false,
			iconCls : 'icon-search',
			handler : function() {
				$("#searchEorder").window("center");
				$("#searchEorder").window("open");
			}
		}, {
			text : '导出Excel',
			disabled : false,
			iconCls : 'icon-save',
			handler : function() {
				excelEorder();
			}
		} ],
		columns : [ [ {
			title : '卖方名称',
			field : 'branchName',
			resizable : true

		}, {
			title : '买方名称',
			field : 'custName',
			resizable : true
		}, {
			title : '区域',
			field : 'areaName',
			align : 'left',
			resizable : true
		}, {
			title : '联系人',
			field : 'custMan',
			align : 'left',
			resizable : true
		}, {
			title : '联系电话',
			field : 'manPhone',
			align : 'left',
			resizable : true
		}, {
			title : '客户类型',
			field : 'custType',
			align : 'left',
			resizable : true
		}, {
			title : '报价方式',
			field : 'custLevel',
			align : 'left',
			resizable : true
		}, {
			title : '帐号名',
			field : 'loginName',
			align : 'left',
			resizable : true
		}, {
			title : '下单次数',
			field : 'orderCount',
			align : 'left',
			resizable : true
		}, {
			title : '订单总额',
			field : 'totalMoney',
			align : 'left',
			resizable : true
		}, {
			title : '客户编码',
			field : 'custBh',
			align : 'left',
			resizable : true
		}, {
			title : '客户内码',
			field : 'custNm',
			align : 'left',
			resizable : true
		}, {
			title : '首次下单',
			field : 'fristOrderDate',
			align : 'left',
			resizable : true,
			formatter : function(dateString) {
				if(dateString==null)
					return "";
				else
					return dateString.substr(0, 10);
			}
		}, {
			title : '最后下单',
			field : 'lastOrderDate',
			align : 'left',
			resizable : true,
			formatter : function(dateString) {
				if(dateString==null)
					return "";
				else
					return dateString.substr(0, 10);
			}
		} ] ]
	});

}

// 无单用户
function showNoEorderData() {
	$('#searchRegisterCustTable').datagrid({
		nowrap : true,
		striped : true,
		fitColumns : true,
		toolbar : "#toolbar",
		url : '/admin/analysis/noEorder.json',
		method : 'post',
		pagination : true,
		singleSelect : false,
		idField : 'custId',
		toolbar : [ {
			text : '查询',
			disabled : false,
			iconCls : 'icon-search',
			handler : function() {
				$("#searchNoEorder").window("center");
				$("#searchNoEorder").window("open");
			}
		}/*, {
			text : '导出Excel',
			disabled : false,
			iconCls : 'icon-save',
			handler : function() {
				excelNoEorder();
			}
		} */],
		columns : [ [ {
			title : '卖方名称',
			field : 'branchName',
			resizable : true

		}, {
			title : '买方名称',
			field : 'custName',
			resizable : true
		}, {
			title : '区域',
			field : 'areaName',
			align : 'left',
			resizable : true
		}, {
			title : '联系人',
			field : 'custMan',
			align : 'left',
			resizable : true
		}, {
			title : '联系电话',
			field : 'manTel',
			align : 'left',
			resizable : true
		}, {
			title : '客户类型',
			field : 'custType',
			align : 'left',
			resizable : true
		}, {
			title : '报价方式',
			field : 'custLevel',
			align : 'left',
			resizable : true
		}, {
			title : '帐号名',
			field : 'loginName',
			align : 'left',
			resizable : true
		}, {
			title : '客户编码',
			field : 'custBh',
			align : 'left',
			resizable : true
		}, {
			title : '客户内码',
			field : 'custNm',
			align : 'left',
			resizable : true
		}, {
			title : '开通日期',
			field : 'createDate',
			align : 'left',
			resizable : true,
			formatter : function(dateString) {
				return dateString.substr(0, 10);
			}
		} ] ]
	});

}

// 分公司订单
function showBranchEorderData() {
	$('#showTimes').hide();
	$('#searchRegisterCustTable').datagrid({

		nowrap : true,
		striped : true,
		fitColumns : true,
		toolbar : "#toolbar",
		url : '/admin/analysis/branchEorder.json',
		method : 'post',
		pagination : true,
		singleSelect : false,
		idField : 'branchId',
		toolbar : [ {
			text : '根据天查询',
			disabled : false,
			iconCls : 'icon-save',
			handler : function() {
				showBranchEorderDataByDay();
			}
		}, {
			text : '查询',
			disabled : false,
			iconCls : 'icon-search',
			handler : function() {
				$("#searchBranch").window("center");
				$("#searchBranch").window("open");
			}
		}/*, {
			text : '导出Excel',
			disabled : false,
			iconCls : 'icon-save',
			handler : function() {
				excelBranchEorder();
			}
		} */],
		columns : [ [ {
			title : '年-月',
			field : 'lastDate',
			resizable : true

		}, {
			title : '卖方名称',
			field : 'branchName',
			align : 'left',
			resizable : true
		}, {
			title : '订单总数',
			field : 'orderCount',
			align : 'left',
			resizable : true
		}, {
			title : '买方数量',
			field : 'custCount',
			align : 'left',
			resizable : true
		}, {
			title : '订单总额',
			field : 'totalOrderMoney',
			align : 'left',
			resizable : true
		}, {
			title : '平均金额',
			field : 'averageMoney',
			align : 'left',
			resizable : true
		} ] ]
	});

}

function showBranchEorderDataByDay() {
	$('#showTimes').show();
	$('#searchRegisterCustTable').datagrid({

		nowrap : true,
		striped : true,
		fitColumns : true,
		toolbar : "#toolbar",
		url : '/admin/analysis/branchEorderByDay.json',
		method : 'post',
		pagination : true,
		singleSelect : false,
		idField : 'branchId',
		toolbar : [ {
			text : '根据月查询',
			disabled : false,
			iconCls : 'icon-save',
			handler : function() {
				showBranchEorderData();
			}
		}, {
			text : '查询',
			disabled : false,
			iconCls : 'icon-search',
			handler : function() {
				$("#searchBranch").window("center");
				$("#searchBranch").window("open");
			}
		}/*, {
			text : '导出Excel',
			disabled : false,
			iconCls : 'icon-save',
			handler : function() {
				excelBranchEorderDay();
			}
		} */],
		columns : [ [ {
			title : '年-月-日',
			field : 'lastDate',
			resizable : true

		}, {
			title : '卖方名称',
			field : 'branchName',
			align : 'left',
			resizable : true
		}, {
			title : '订单总数',
			field : 'orderCount',
			align : 'left',
			resizable : true
		}, {
			title : '买方数量',
			field : 'custCount',
			align : 'left',
			resizable : true
		}, {
			title : '订单总额',
			field : 'totalOrderMoney',
			align : 'left',
			resizable : true
		}, {
			title : '平均金额',
			field : 'averageMoney',
			align : 'left',
			resizable : true
		} ] ]
	});
}

// 订货会数据统计
function showSaleFairsData() {
	$('#searchRegisterCustTable').datagrid({
		nowrap : true,
		striped : true,
		fitColumns : true,
		toolbar : "#toolbar",
		url : '/admin/analysis/saleFairs.json',
		method : 'post',
		pagination : true,
		singleSelect : false,
		idField : 'custId',
		toolbar : [ {
			text : '查询',
			disabled : false,
			iconCls : 'icon-search',
			handler : function() {
				$("#searchSaleFairs").window("center");
				$("#searchSaleFairs").window("open");
			}
		}, {
			text : '导出Excel',
			disabled : false,
			iconCls : 'icon-save',
			handler : function() {
				excelSaleFairs();
			}
		} ],
		columns : [ [ {
			title : '购买时间',
			field : 'makeDate',
			resizable : true,
			formatter : function(dateString) {
				return dateString.substr(0, 10);
			}
		}, {
			title : '客户名称',
			field : 'custName',
			resizable : true
		}, {
			title : '客户类型',
			field : 'custTypeName',
			resizable : true
		}, {
			title : '药品编码',
			field : 'merchandiseCode',
			align : 'left',
			resizable : true
		}, {
			title : '药品品名/规格',
			field : 'merchandiseName',
			align : 'left',
			resizable : true
		}, {
			title : '单位/中包装',
			field : 'merchandiseSpec',
			align : 'left',
			resizable : true
		}, {
			title : '包装数量',
			field : 'packingNumber',
			align : 'left',
			resizable : true
		}, {
			title : '生产产地',
			field : 'producingName',
			align : 'left',
			resizable : true
		}, {
			title : '购买数量',
			field : 'amount',
			align : 'left',
			resizable : true
		}, {
			title : '购买价格',
			field : 'sellPrice',
			align : 'left',
			resizable : true
		}, {
			title : '所属展馆',
			field : 'flagName',
			align : 'left',
			resizable : true
		},

		{
			title : '卖方名称',
			field : 'branchName',
			resizable : true
		} ] ]
	});

}

// 销售数据统计
function showSellDetailData() {
	$('#searchRegisterCustTable').datagrid({
		nowrap : true,
		striped : true,
		fitColumns : true,
		toolbar : "#toolbar",
		url : '/admin/analysis/sellDetail.json',
		method : 'post',
		pagination : true,
		singleSelect : false,
		idField : 'merchandiseId',
		toolbar : [ {
			text : '查询',
			disabled : false,
			iconCls : 'icon-search',
			handler : function() {
				$("#searchSellDetail").window("center");
				$("#searchSellDetail").window("open");
			}
		}/*, 
		{
			text : '导出Excel',
			disabled : false,
			iconCls : 'icon-save',
			handler : function() {
				excelSellDetail();
			}
		}*/
		],
		columns : [ [ {
			title : '卖方名称',
			field : 'branchName',
			resizable : true

		}, {
			title : '药品品名/规格',
			field : 'merchandiseName',
			resizable : true

		}, {
			title : '药品编码',
			field : 'merchandiseCode',
			resizable : true
		}, {
			title : '药品内码',
			field : 'exteriorSystemId',
			align : 'left',
			resizable : true
		}, {
			title : '单位/中包装',
			field : 'unitMidd',
			align : 'left',
			resizable : true
		}, {
			title : '生产产地',
			field : 'producingName',
			align : 'left',
			resizable : true
		}, {
			title : '销售数量',
			field : 'sellCount',
			align : 'left',
			resizable : true
		}, {
			title : '销售金额',
			field : 'sellMoney',
			align : 'left',
			resizable : true
		} ] ]
	});

}
function showSellDetailDataMX() {
	$('#searchRegisterCustTable').datagrid({
		fit : true,
		nowrap : true,
		striped : true,
		fitColumns : true,
		toolbar : "#toolbar",
		url : '/admin/analysis/sellDetailMX.json',
		method : 'post',
		pagination : true,
		singleSelect : false,
		idField : 'sellDetailId',
		toolbar : [ {
			text : '查询',
			disabled : false,
			iconCls : 'icon-search',
			handler : function() {
				$("#searchSellDetail").window("center");
				$("#searchSellDetail").window("open");
			}
		}/*, {
			text : '导出Excel',
			disabled : false,
			iconCls : 'icon-save',
			handler : function() {
				excelSellDetailMX();
			}
		} */],
		columns : [ [ {
			title : '药品品名/规格',
			field : 'merchandiseName',
			resizable : true
			
		}, {
			title : '药品编码',
			field : 'merchandiseCode',
			resizable : true
		}, {
			title : '单位编号',
			field : 'danwBh',
			align : 'left',
			resizable : true
		}, {
			title : '单位/中包装',
			field : 'unitMidd',
			align : 'left',
			resizable : true
		}, {
			title : '生产产地',
			field : 'producingName',
			align : 'left',
			resizable : true
		}, {
			title : '客户名称',
			field : 'custName',
			align : 'left',
			resizable : true
		}, {
			title : '客户编码',
			field : 'danwBh',
			align : 'left',
			resizable : true
		}, {
			title : '销售数量',
			field : 'sellCount',
			align : 'left',
			resizable : true
		}, {
			title : '销售金额',
			field : 'sellMoney',
			align : 'left',
			resizable : true
		}, {
			title : '日期',
			field : 'createTimes',
			align : 'left',
			resizable : true
		} ] ]
	});
	
}
// 缺货篮
function showBasket() {
	$('#searchRegisterCustTable').datagrid({

		nowrap : true,
		striped : true,
		fitColumns : true,
		toolbar : "#toolbar",
		url : '/admin/analysis/basket.json',
		method : 'post',
		pagination : true,
		singleSelect : false,

		idField : 'basketId',
		toolbar : [ {
			text : '查看药品缺货汇总',
			disabled : false,
			iconCls : 'icon-search',
			handler : function() {
				showBasketByMed();
			}
		}, {
			text : '查询',
			disabled : false,
			iconCls : 'icon-search',
			handler : function() {
				$("#searchBasket").window("center");
				$("#searchBasket").window("open");
			}
		}/*, {
			text : '导出Excel',
			disabled : false,
			iconCls : 'icon-save',
			handler : function() {
				excelBasket();
			}
		}*/ ],
		columns : [ [ {
			title : '卖方名称',
			field : 'branchName',
			resizable : true

		}, {
			title : '药品名称/规格',
			field : 'merchandiseName',
			resizable : true
		}, {
			title : '药品编码',
			field : 'merchandiseCode',
			align : 'left',
			resizable : true
		}, {
			title : '单位/中包装',
			field : 'merchandiseUnit',
			align : 'left',
			resizable : true
		}, {
			title : '客户单位',
			field : 'custName',
			align : 'left',
			resizable : true
		}, {
			title : '生产厂家',
			field : 'manufacturer',
			align : 'left',
			resizable : true
		}, {
			title : '购买数量',
			field : 'amount',
			align : 'left',
			resizable : true
		}, {
			title : '购买时间',
			field : 'createDate',
			align : 'left',
			resizable : true,
			formatter : function(dateString) {
				return dateString.substr(0, 10);
			}
		}, {
			title : '单位编码',
			field : 'danwbh',
			align : 'left',
			resizable : true
		} ] ]
	});

}

function showBasketByMed() {
	$('#searchRegisterCustTable').datagrid({
		fit : true,
		nowrap : true,
		striped : true,
		fitColumns : true,
		toolbar : "#toolbar",
		url : '/admin/analysis/basketByMed.json',
		method : 'post',
		pagination : true,
		singleSelect : false,

		idField : 'basketId',
		toolbar : [ {
			text : '查看客户缺货明细',
			disabled : false,
			iconCls : 'icon-search',
			handler : function() {
				showBasket();
			}
		}, {
			text : '查询',
			disabled : false,
			iconCls : 'icon-search',
			handler : function() {
				$("#searchBasketMed").window("center");
				$("#searchBasketMed").window("open");
			}
		}/*, {
			text : '导出Excel',
			disabled : false,
			iconCls : 'icon-save',
			handler : function() {
				excelBasketMed();
			}
		} */],
		columns : [ [ {
			title : '卖方名称',
			field : 'branchName',
			resizable : true

		}, {
			title : '药品名称/规格',
			field : 'merchandiseName',
			resizable : true
		}, {
			title : '药品编码',
			field : 'merchandiseCode',
			align : 'left',
			resizable : true
		}, {
			title : '单位/中包装',
			field : 'merchandiseUnit',
			align : 'left',
			resizable : true
		}, {
			title : '生产厂家',
			field : 'manufacturer',
			align : 'left',
			resizable : true
		}, {
			title : '购买数量',
			field : 'amount',
			align : 'left',
			resizable : true
		} ] ]
	});

}

// 客户关注
function showAttention() {
	$('#searchRegisterCustTable').datagrid({
		nowrap : true,
		striped : true,
		fitColumns : true,
		toolbar : "#toolbar",
		url : '/admin/analysis/attention.json',
		method : 'post',
		pagination : true,
		singleSelect : false,
		idField : 'attentionId',
		toolbar : [ {
			text : '查询',
			disabled : false,
			iconCls : 'icon-search',
			handler : function() {
				$("#searchAttention").window("center");
				$("#searchAttention").window("open");
			}
		}/*, {
			text : '导出Excel',
			disabled : false,
			iconCls : 'icon-save',
			handler : function() {
				excelAttention();
			}
		} */],
		columns : [ [ {
			title : '卖方名称',
			field : 'branchName',
			resizable : true

		}, {
			title : '药品名称/规格',
			field : 'merchandiseName',
			resizable : true
		}, {
			title : '生产厂家',
			field : 'producingName',
			align : 'left',
			resizable : true
		}, {
			title : '批准文号',
			field : 'merchandisePass',
			align : 'left',
			resizable : true
		}, {
			title : '单位/中包装',
			field : 'merchandiseUnit',
			align : 'left',
			resizable : true
		}, {
			title : '库存',
			field : 'storeInfo',
			align : 'left',
			resizable : true
		}, {
			title : '关注次数',
			field : 'attentCount',
			align : 'left',
			resizable : true
		}, {
			title : '客户单位',
			field : 'custName',
			align : 'left',
			resizable : true
		}, {
			title : '客户账号',
			field : 'userName',
			align : 'left',
			resizable : true
		} ] ]
	});

}

// 新品统计
function showNewProduct() {
	$('#searchRegisterCustTable').datagrid({
		nowrap : true,
		striped : true,
		fitColumns : true,
		toolbar : "#toolbar",
		url : '/admin/analysis/newProduct.json',
		method : 'post',
		pagination : true,
		singleSelect : false,
		idField : 'newProductId',
		toolbar : [ {
			text : '查询',
			disabled : false,
			iconCls : 'icon-search',
			handler : function() {
				$("#searchNewProduct").window("center");
				$("#searchNewProduct").window("open");
			}
		}/*, {
			text : '导出Excel',
			disabled : false,
			iconCls : 'icon-save',
			handler : function() {
				excelProduct();
			}
		}*/ ],
		columns : [ [ {
			title : '卖方名称',
			field : 'branchName',
			resizable : true

		}, {
			title : '药品名称',
			field : 'merchandiseName',
			resizable : true
		}, {
			title : '规格',
			field : 'merchandiseSpec',
			resizable : true
		}, {
			title : '生产厂家',
			field : 'producingName',
			align : 'left',
			resizable : true
		}, {
			title : '批准文号',
			field : 'passFileNumber',
			align : 'left',
			resizable : true
		}, {
			title : '建议价格',
			field : 'suggestPrice',
			align : 'left',
			resizable : true
		}, {
			title : '需求数量',
			field : 'amount',
			align : 'left',
			resizable : true
		}, {
			title : '添加时间',
			field : 'createDate',
			align : 'left',
			resizable : true,
			formatter : function(dateString) {
				return dateString.substr(0, 10);
			}
		}, {
			title : '客户单位',
			field : 'custName',
			align : 'left',
			resizable : true
		}, {
			title : '客户账号',
			field : 'loginName',
			align : 'left',
			resizable : true
		} ] ]
	});

}

// 查询
function searchEorderTable() {

	var sDate = $('#start_Date').datebox('getValue');
	var eDate = $('#end_Date').datebox('getValue');
	// 判断时间大小
	if ((null != sDate && "" != sDate) && (null != eDate && "" != eDate)) {
		if (sDate > eDate) {
			$.messager.alert('警告', '开始时间要小于结束时间!');
			return;
		}
	}

	$('#searchRegisterCustTable').datagrid('options').queryParams = {
		"cust_Bh" : $("#cust_Bh").val(),
		"cust_Man" : $("#cust_Man").val(),
		"login_Name" : $("#login_Name").val(),
		"cust_Level" : $("#cust_Level").combobox("getValue"),
		"start_Date" : $("#start_Date").datebox('getValue'),
		"branch_Name" : $("#branch_Name").combobox("getValue"),
		"end_Date" : $("#end_Date").datebox('getValue')
	}, $("#searchRegisterCustTable").datagrid('reload');
	$('#searchEorder').window('center');
	$("#searchEorder").window("close");
}

function searchRegisterTable() {

	var sDate = $('#startDater').datebox('getValue');
	var eDate = $('#endDater').datebox('getValue');
	// 判断时间大小
	if ((null != sDate && "" != sDate) && (null != eDate && "" != eDate)) {
		if (sDate > eDate) {
			$.messager.alert('警告', '开始时间要小于结束时间!');
			return;
		}
	}

	$('#searchRegisterCustTable').datagrid('options').queryParams = {
		"custBh" : $("#custBh").val(),
		"custMan" : $("#custMan").val(),
		"loginName" : $("#loginName").val(),
		"custLevel" : $('#custLevel').combobox('getValue'),
		"startDate" : $("#startDater").datebox('getValue'),
		"branchName" : $("#branchNamer").combobox("getValue"),
		"endDate" : $("#endDater").datebox('getValue')
	}, $("#searchRegisterCustTable").datagrid('reload');
	$('#searchRegister').window('center');
	$("#searchRegister").window("close");
}

function searchNoEorderTable() {

	var sDate = $('#start_Date1').datebox('getValue');
	var eDate = $('#end_Date1').datebox('getValue');
	// 判断时间大小
	if ((null != sDate && "" != sDate) && (null != eDate && "" != eDate)) {
		if (sDate > eDate) {
			$.messager.alert('警告', '开始时间要小于结束时间!');
			return;
		}
	}

	$('#searchRegisterCustTable').datagrid('options').queryParams = {
		"cust_Bh1" : $("#cust_Bh1").val(),
		"cust_Man1" : $("#cust_Man1").val(),
		"login_Name1" : $("#login_Name1").val(),
		"cust_Level1" : $("#cust_Level1").combobox("getValue"),
		"start_Date1" : $("#start_Date1").datebox('getValue'),
		"branch_Name1" : $("#branch_Name1").combobox("getValue"),
		"end_Date1" : $("#end_Date1").datebox('getValue')
	}, $("#searchRegisterCustTable").datagrid('reload');
	$('#searchNoEorder').window('center');
	$("#searchNoEorder").window("close");
}

function searchBranchTable() {

	var sDate = $('#start_Date2').datebox('getValue');
	var eDate = $('#end_Date2').datebox('getValue');
	// 判断时间大小
	if ((null != sDate && "" != sDate) && (null != eDate && "" != eDate)) {
		if (sDate > eDate) {
			$.messager.alert('警告', '开始时间要小于结束时间!');
			return;
		}
	}

	$('#searchRegisterCustTable').datagrid('options').queryParams = {
		"start_Date2" : $("#start_Date2").datebox('getValue'),
		"end_Date2" : $("#end_Date2").datebox('getValue'),
		"branch_Name2" : $("#branch_Name2").combobox("getValue")
	}, $("#searchRegisterCustTable").datagrid('reload');
	$('#searchBranch').window('center');
	$("#searchBranch").window("close");
}

function searchSaleFairsTable() {

	var sDate = $('#startDate').datebox('getValue');
	var eDate = $('#endDate').datebox('getValue');
	// 判断时间大小
	if ((null != sDate && "" != sDate) && (null != eDate && "" != eDate)) {
		if (sDate > eDate) {
			$.messager.alert('警告', '开始时间要小于结束时间!');
			return;
		}
	}

	$('#searchRegisterCustTable').datagrid('options').queryParams = {
		"startDate" : $("#startDate").datebox('getValue'),
		"endDate" : $("#endDate").datebox('getValue'),
		"custName" : $("#custName").val(),
		"merchandiseCode" : $("#merchandiseCode").val(),
		"merchandiseName" : $("#merchandiseName").val(),
		"branchName" : $("#branchName").combobox("getValue"),
		"searchPavilionCob" : $("#searchPavilionCob").combobox("getValue")
	}, $("#searchRegisterCustTable").datagrid('reload');
	$('#searchSaleFairs').window('center');
	$("#searchSaleFairs").window("close");
}

function searchSellDetailTable() {

	$('#searchRegisterCustTable').datagrid('options').queryParams = {
		"minPrice" : $("#minPrice").val(),
		"maxPrice" : $("#maxPrice").val(),
		"merchandiseCodes" : $("#merchandiseCodes").val(),
		"merchandiseNames" : $("#merchandiseNames").val(),
		"branchNames" : $("#branchNames").combobox("getValue"),
		"startDates" : $("#startDates").datebox('getValue'),
		"endDates" : $("#endDates").datebox('getValue'),
		"producingNames" : $("#producuingNames").val()
	}, $("#searchRegisterCustTable").datagrid('reload');
	$('#searchSellDetail').window('center');
	$("#searchSellDetail").window("close");
}
function searchSellDetailTableMX() {
	
	var sDate = $('#startDates').datebox('getValue');
	var eDate = $('#endDates').datebox('getValue');
	// 判断时间大小
	if ((null != sDate && "" != sDate) && (null != eDate && "" != eDate)) {
		if (sDate > eDate) {
			$.messager.alert('警告', '开始时间要小于结束时间!');
			return;
		}
	}
	
	$('#searchRegisterCustTable').datagrid('options').queryParams = {
		"minPrice" : $("#minPrice").val(),
		"maxPrice" : $("#maxPrice").val(),
		"merchandiseCodes" : $("#merchandiseCodes").val(),
		"merchandiseNames" : $("#merchandiseNames").val(),
		"danwBhs" : $("#danwBhs").val(),
		"startDates" : $("#startDates").datebox('getValue'),
		"endDates" : $("#endDates").datebox('getValue'),
		"producingNames" : $("#producuingNames").val()
	}, $("#searchRegisterCustTable").datagrid('reload');
	$('#searchSellDetail').window('center');
	$("#searchSellDetail").window("close");
}
function searchBasketTable() {

	$('#searchRegisterCustTable').datagrid('options').queryParams = {
		"merchandiseName" : $("#merchandiseNameq").val(),
		"merchandiseCode" : $("#merchandiseCodeq").val(),
		"manufacturer" : $("#manufacturerq").val(),
		"custName" : $("#custNameq").val(),
		"branchName" : $("#branchNameq").combobox("getValue"),
		"danwbh" : $("#danwbhq").val()
	}, $("#searchRegisterCustTable").datagrid('reload');
	$('#searchBasket').window('center');
	$("#searchBasket").window("close");
}

function searchBasketMedTable() {

	$('#searchRegisterCustTable').datagrid('options').queryParams = {
		"merchandiseNameqq" : $("#merchandiseNameqq").val(),
		"merchandiseCodeqq" : $("#merchandiseCodeqq").val(),
		"branchNameqq" : $("#branchNameqq").combobox("getValue"),
		"manufacturerqq" : $("#manufacturerqq").val()
	}, $("#searchRegisterCustTable").datagrid('reload');
	$('#searchBasketMed').window('center');
	$("#searchBasketMed").window("close");
}

function searchAttentTable() {

	$('#searchRegisterCustTable').datagrid('options').queryParams = {
		"merchandiseNamea" : $("#merchandiseNamea").val(),
		"merchandiseCodea" : $("#merchandiseCodea").val(),
		"branchNamea" : $("#branchNamea").combobox("getValue"),
		"producingNamea" : $("#producingNamea").val()
	}, $("#searchRegisterCustTable").datagrid('reload');
	$('#searchAttention').window('center');
	$("#searchAttention").window("close");
}

function searchNewProductTable() {

	var sDate = $('#beginDatex').datebox('getValue');
	var eDate = $('#endDatex').datebox('getValue');
	// 判断时间大小
	if ((null != sDate && "" != sDate) && (null != eDate && "" != eDate)) {
		if (sDate > eDate) {
			$.messager.alert('警告', '开始时间要小于结束时间!');
			return;
		}
	}

	$('#searchRegisterCustTable').datagrid('options').queryParams = {
		"beginDate" : $("#beginDatex").datebox('getValue'),
		"endDate" : $("#endDatex").datebox('getValue'),
		"branchName" : $("#branchNamex").combobox("getValue")
	}, $("#searchRegisterCustTable").datagrid('reload');
	$('#searchNewProduct').window('center');
	$("#searchNewProduct").window("close");
}

function searchUnionTable() {

	var sDate = $('#beginDate').datebox('getValue');
	var eDate = $('#endDate').datebox('getValue');
	// 判断时间大小
	if ((null != sDate && "" != sDate) && (null != eDate && "" != eDate)) {
		if (sDate > eDate) {
			$.messager.alert('警告', '开始时间要小于结束时间!');
			return;
		}
	}

	$('#searchRegisterCustTable').datagrid('options').queryParams = {
		"merchandiseNameu" : $("#merchandiseNameu").val(),
		"merchandiseCodeu" : $("#merchandiseCodeu").val(),
		"beginDate" : $("#beginDate").datebox('getValue'),
		"endDate" : $("#endDate").datebox('getValue'),
		"branchNameu" : $("#branchNameu").combobox("getValue"),
		"producuingNameu" : $("#producuingNameu").val()
	}, $("#searchRegisterCustTable").datagrid('reload');
	$('#searchUnion').window('center');
	$("#searchUnion").window("close");
	$('#bdate').val($('#beginDate').datebox('getValue'));
	$('#edate').val($('#endDate').datebox('getValue'));
}

function searchUnionCustTable() {

	var sDate = $('#beginDateun').datebox('getValue');
	var eDate = $('#endDateun').datebox('getValue');
	// 判断时间大小
	if ((null != sDate && "" != sDate) && (null != eDate && "" != eDate)) {
		if (sDate > eDate) {
			$.messager.alert('警告', '开始时间要小于结束时间!');
			return;
		}
	}

	$('#searchRegisterCustTable').datagrid('options').queryParams = {
		"custName" : $("#custNameun").val(),
		"loginName" : $("#loginNameun").val(),
		"beginDateun" : $("#beginDateun").datebox('getValue'),
		"endDateun" : $("#endDateun").datebox('getValue'),
		"branchNameu" : $("#branchNameun").combobox("getValue")
	}, $("#searchRegisterCustTable").datagrid('reload');
	$('#searchCustUnion').window('center');
	$("#searchCustUnion").window("close");
	$('#bdateun').val($('#beginDateun').datebox('getValue'));
	$('#edateun').val($('#endDateun').datebox('getValue'));
}

function showUnionMedData() {

	$('#searchRegisterCustTable').datagrid(
			{
				nowrap : true,
				striped : true,
				fitColumns : true,
				toolbar : "#toolbar",
				url : '/admin/analysis/union.json',
				method : 'post',
				pagination : true,
				singleSelect : false,
				idField : 'merchandiseId',
				frozenColumns : [ [ {
					field : 'merchandiseId',
					checkbox : true
				} ] ],
				toolbar : [
						{
							text : '查看客户信息',
							disabled : false,
							iconCls : 'icon-search',
							handler : function() {
								showCustMessage();
							}
						},
						{
							text : '查询',
							disabled : false,
							iconCls : 'icon-search',
							handler : function() {
								$("#searchUnion").window("center");
								$("#searchUnion").window("open");
							}
						},
						{
							text : '导出Excel',
							disabled : false,
							iconCls : 'icon-save',
							handler : function() {
								excelunion();
							}
						},
						{
							text : '查看详细信息',
							disabled : false,
							iconCls : 'icon-save',
							data : 'merchandiseId',
							handler : function() {
								var selected = $('#searchRegisterCustTable')
										.datagrid('getSelections');
								if (selected && selected.length == 1) {
									selected = selected[0];

									var bdate = $("#bdate").val();
									var edate = $("#edate").val();

									searchUniolCust(selected.merchandiseId,
											bdate, edate);
									$("#showUnionCust").window("center");
									$("#showUnionCust").window("open");
								} else {
									alert("只能查看一条明细!");
								}

							}
						} ],
				columns : [ [ {
					title : '分公司',
					field : 'branchName',
					resizable : true

				}, {
					title : '药品品名/规格',
					field : 'merchandiseName',
					resizable : true

				}, {
					title : '药品编码',
					field : 'merchandiseCode',
					resizable : true
				}, {
					title : '中包装',
					field : 'middlingPacking',
					align : 'left',
					resizable : true
				}, {
					title : '大包装',
					field : 'packingNumber',
					align : 'left',
					resizable : true
				}, {
					title : '单位',
					field : 'merchandiseUnit',
					align : 'left',
					resizable : true
				}, {
					title : '生产产地',
					field : 'producingName',
					align : 'left',
					resizable : true
				}, {
					title : '销售数量',
					field : 'amount',
					align : 'left',
					resizable : true
				}, {
					title : '销售金额',
					field : 'money',
					align : 'left',
					resizable : true
				} ] ]
			});

}
function searchUniolCust(merchandiseId, bdate, edate) {

	$('#unionCustTable').datagrid(
			{
				nowrap : true,
				striped : true,
				fitColumns : true,
				toolbar : "#toolbar",
				url : '/admin/analysis/unionCust.json?merchandiseId='
						+ merchandiseId + '&bdate=' + bdate + '&edate=' + edate
						+ '',
				method : 'post',
				pagination : true,
				singleSelect : false,
				idField : 'merchandiseId',

				columns : [ [ {
					title : '客户名称',
					field : 'custName',
					resizable : true

				}, {
					title : '药品品名/规格',
					field : 'merchandiseName',
					resizable : true

				}, {
					title : '药品编码',
					field : 'merchandiseCode',
					resizable : true
				}, {
					title : '中包装',
					field : 'middlingPacking',
					align : 'left',
					resizable : true
				}, {
					title : '大包装',
					field : 'packingNumber',
					align : 'left',
					resizable : true
				}, {
					title : '单位',
					field : 'merchandiseUnit',
					align : 'left',
					resizable : true
				}, {
					title : '生产产地',
					field : 'producingName',
					align : 'left',
					resizable : true
				}, {
					title : '销售数量',
					field : 'amount',
					align : 'left',
					resizable : true
				}, {
					title : '销售金额',
					field : 'money',
					align : 'left',
					resizable : true
				}, {
					title : '时间',
					field : 'createTime',
					align : 'left',
					resizable : true,
					formatter : function(dateString) {
						return dateString.substr(0, 10);
					}
				} ] ]
			});
}

function showCustMessage() {

	$('#searchRegisterCustTable').datagrid(
			{
				nowrap : true,
				striped : true,
				fitColumns : true,
				toolbar : "#toolbar",
				url : '/admin/analysis/custByUnion.json',
				method : 'post',
				pagination : true,
				singleSelect : false,
				idField : 'custId',
				frozenColumns : [ [ {
					field : 'custId',
					checkbox : true
				} ] ],
				toolbar : [
						{
							text : '查看药品信息',
							disabled : false,
							iconCls : 'icon-search',
							handler : function() {
								showUnionMedData();
							}
						},
						{
							text : '查询',
							disabled : false,
							iconCls : 'icon-search',
							handler : function() {
								$("#searchCustUnion").window("center");
								$("#searchCustUnion").window("open");
							}
						},
						{
							text : '导出Excel',
							disabled : false,
							iconCls : 'icon-save',
							handler : function() {
								excelcustunion();
							}
						},
						{
							text : '查看详细信息',
							disabled : false,
							iconCls : 'icon-save',
							data : 'custId',
							handler : function() {
								var selected = $('#searchRegisterCustTable')
										.datagrid('getSelections');
								if (selected && selected.length == 1) {
									selected = selected[0];
									var bdate = $("#bdateun").val();
									var edate = $("#edateun").val();
									searchUnionByCust(selected.custId, bdate,
											edate);
									$("#showUnionByCust").window("center");
									$("#showUnionByCust").window("open");
								} else {
									alert("只能查看一条明细");
								}
							}
						} ],
				columns : [ [ {
					title : '分公司',
					field : 'branchName',
					resizable : true
				}, {
					title : '机构类型',
					field : 'custTypeName',
					resizable : true
				}, {
					title : '客户名称',
					field : 'custName',
					align : 'left',
					resizable : true
				}, {
					title : '用户名',
					field : 'loginName',
					align : 'left',
					resizable : true
				}, {
					title : '采购数量',
					field : 'buyerCount',
					align : 'left',
					resizable : true
				}, {
					title : '采购金额',
					field : 'buyerMoney',
					align : 'left',
					resizable : true
				} ] ]
			});

}

function searchUnionByCust(custId, bdate, edate) {

	$('#unionByCustTable').datagrid(
			{
				nowrap : true,
				striped : true,
				fitColumns : true,
				toolbar : "#toolbar",
				url : '/admin/analysis/unionByCust.json?custId=' + custId
						+ '&bdate=' + bdate + '&edate=' + edate + '',
				method : 'post',
				pagination : true,
				singleSelect : false,
				idField : 'custId',
				columns : [ [ {
					title : '客户名称',
					field : 'custName',
					resizable : true

				}, {
					title : '药品品名/规格',
					field : 'merchandiseName',
					resizable : true

				}, {
					title : '药品编码',
					field : 'merchandiseCode',
					resizable : true
				}, {
					title : '中包装',
					field : 'middlingPacking',
					align : 'left',
					resizable : true
				}, {
					title : '大包装',
					field : 'packingNumber',
					align : 'left',
					resizable : true
				}, {
					title : '单位',
					field : 'merchandiseUnit',
					align : 'left',
					resizable : true
				}, {
					title : '生产产地',
					field : 'producingName',
					align : 'left',
					resizable : true
				}, {
					title : '销售数量',
					field : 'amount',
					align : 'left',
					resizable : true
				}, {
					title : '销售金额',
					field : 'money',
					align : 'left',
					resizable : true
				}, {
					title : '时间',
					field : 'createTime',
					align : 'left',
					resizable : true,
					formatter : function(dateString) {
						return dateString.substr(0, 10);
					}
				} ] ]
			});
}

function excelRegister() {

	var custBh = $("#custBh").val();
	var custMan = $("#custMan").val();
	var loginName = $("#loginName").val();
	var custLevel = $("#custLevel").combobox("getValue");

	var startDate = $("#startDater").datebox('getValue');
	var endDate = $("#endDater").datebox('getValue');
	var branchName = $("#branchNamer").combobox("getValue");
	window.location.href = "/admin/analysis/validateExcelRegister.htm?custBh=" + custBh
			+ "&custMan=" + custMan + "&loginName=" + loginName + "&custLevel="
			+ custLevel + "&startDate=" + startDate + "&endDate=" + endDate
			+ "&branchName=" + branchName;

}

function excelEorder() {

	var cust_Bh = $("#cust_Bh").val();
	var cust_Man = $("#cust_Man").val();
	var login_Name = $("#login_Name").val();

	var cust_Level = $("#cust_Level").combobox("getValue");
	var start_Date = $("#start_Date").datebox('getValue');
	var end_Date = $("#end_Date").datebox('getValue');
	var branch_Name = $("#branch_Name").combobox("getValue");
	window.location.href = "/admin/analysis/validateExcelEorder.htm?cust_Bh=" + cust_Bh
			+ "&cust_Man=" + cust_Man + "&login_Name=" + login_Name
			+ "&cust_Level=" + cust_Level + "&start_Date=" + start_Date
			+ "&end_Date=" + end_Date + "&branch_Name=" + branch_Name;

}

function excelNoEorder() {

	var cust_Bh1 = $("#cust_Bh1").val();
	var cust_Man1 = $("#cust_Man1").val();
	var login_Name1 = $("#login_Name1").val();
	var cust_Level1 = $("#cust_Level1").combobox("getValue");
	var start_Date1 = $("#start_Date1").datebox('getValue');
	var end_Date1 = $("#end_Date1").datebox('getValue');
	var branch_Name1 = $("#branch_Name1").combobox("getValue");
	window.location.href = "/admin/analysis/validateExcelNoEorder.htm?cust_Bh1="
			+ cust_Bh1 + "&cust_Man1=" + cust_Man1 + "&login_Name1="
			+ login_Name1 + "&cust_Level1=" + cust_Level1 + "&start_Date1="
			+ start_Date1 + "&end_Date1=" + end_Date1 + "&branch_Name1="
			+ branch_Name1;

}

function excelBranchEorder() {

	var start_Date2 = $("#start_Date2").datebox('getValue');
	var end_Date2 = $("#end_Date2").datebox('getValue');
	var branch_Name2 = $("#branch_Name2").combobox("getValue");
	window.location.href = "/admin/analysis/validateExcelBranch.htm?start_Date2="
			+ start_Date2 + "&end_Date2=" + end_Date2 + "&branch_Name2="
			+ branch_Name2;
}

function excelBranchEorderDay() {

	var start_Date2 = $("#start_Date2").datebox('getValue');
	var end_Date2 = $("#end_Date2").datebox('getValue');
	var branch_Name2 = $("#branch_Name2").combobox("getValue");
	window.location.href = "/admin/analysis/validateExcelBranchEorderDay.htm?start_Date2="
			+ start_Date2
			+ "&end_Date2="
			+ end_Date2
			+ "&branch_Name2="
			+ branch_Name2;
}

function excelSaleFairs() {

	var startDate = $("#startDate").datebox('getValue');
	var endDate = $("#endDate").datebox('getValue');
	var custName = $("#custName").val();
	var merchandiseCode = $("#merchandiseCode").val();
	var merchandiseName = $("#merchandiseName").val();
	var searchPavilionCob = $("#searchPavilionCob").combobox("getValue");
	var branchName = $("#branchName").combobox("getValue");

	window.location.href = "/admin/analysis/validateExcelSaleFairs.htm?startDate="
			+ startDate + "&endDate=" + endDate + "&custName=" + custName
			+ "&merchandiseCode=" + merchandiseCode + "&merchandiseName="
			+ merchandiseName + "&searchPavilionCob=" + searchPavilionCob
			+ "&branchName=" + branchName;
}

function excelSellDetail() {

	var minPrice = $("#minPrice").val();
	var maxPrice = $("#maxPrice").val();
	var merchandiseCodes = $("#merchandiseCodes").val();
	var merchandiseNames = $("#merchandiseNames").val();
	var startDates = $("#startDates").datebox('getValue');
	var endDates = $("#endDates").datebox('getValue');
	var producingNames = $("#producuingNames").val();
	var branchNames = $("#branchNames").combobox("getValue");

	window.location.href = "/admin/analysis/validateExcelSellDetail.htm?minPrice="
			+ minPrice + "&maxPrice=" + maxPrice + "&merchandiseCodes="
			+ merchandiseCodes + "&merchandiseNames=" + merchandiseNames
			+ "&startDates=" + startDates + "&endDates=" + endDates
			+ "&producingNames=" + producingNames + "&branchNames="
			+ branchNames;
}
function excelSellDetailMX() {
	
	var minPrice = $("#minPrice").val();
	var maxPrice = $("#maxPrice").val();
	var merchandiseCodes = $("#merchandiseCodes").val();
	var merchandiseNames = $("#merchandiseNames").val();
	var startDates = $("#startDates").datebox('getValue');
	var endDates = $("#endDates").datebox('getValue');
	var producingNames = $("#producuingNames").val();
	var branchNames = $("#branchNames").combobox("getValue");
	
	window.location.href = "/admin/analysis/validateExcelSellDetailMX.htm?minPrice="
		+ minPrice + "&maxPrice=" + maxPrice + "&merchandiseCodes="
		+ merchandiseCodes + "&merchandiseNames=" + merchandiseNames
		+ "&startDates=" + startDates + "&endDates=" + endDates
		+ "&producingNames=" + producingNames + "&branchNames="
		+ branchNames;
}

function excelBasket() {

	var merchandiseName = $("#merchandiseNameq").val();
	var merchandiseCode = $("#merchandiseCodeq").val();
	var manufacturer = $("#manufacturerq").val();
	var custName = $("#custNameq").val();
	var danwbh = $("#danwbhq").val();
	var branchName = $("#branchNameq").combobox("getValue");
	var startTime = $("#startTimeq").datebox('getValue');
	var endTime = $("#endTimeq").datebox('getValue');
	window.location.href = "/admin/analysis/validateExcelBasket.htm?merchandiseName="
			+ merchandiseName + "&merchandiseCode=" + merchandiseCode
			+ "&manufacturer=" + manufacturer + "&custName=" + custName
			+ "&danwbh=" + danwbh + "&branchName=" + branchName + "&startTime="
			+ startTime + "&endTime=" + endTime;
}

function excelBasketMed() {

	var merchandiseNameqq = $("#merchandiseNameqq").val();
	var merchandiseCodeqq = $("#merchandiseCodeqq").val();
	var manufacturerqq = $("#manufacturerqq").val();
	var branchNameqq = $("#branchNameqq").combobox("getValue");
	window.location.href = "/admin/analysis/validateExcelBasketMed.htm?merchandiseNameqq="
			+ merchandiseNameqq
			+ "&merchandiseCodeqq="
			+ merchandiseCodeqq
			+ "&manufacturerqq="
			+ manufacturerqq
			+ "&branchNameqq="
			+ branchNameqq;
}

function excelAttention() {

	var merchandiseNamea = $("#merchandiseNamea").val();
	var merchandiseCodea = $("#merchandiseCodea").val();
	var producingNamea = $("#producingNamea").val();
	var branchNamea = $("#branchNamea").combobox("getValue");
	window.location.href = "/admin/analysis/validateExcelAttention.htm?merchandiseNamea="
			+ merchandiseNamea
			+ "&merchandiseCodea="
			+ merchandiseCodea
			+ "&producingNamea="
			+ producingNamea
			+ "&branchNamea="
			+ branchNamea;
}

function excelProduct() {

	var beginDate = $("#beginDatex").datebox('getValue');
	var endDate = $("#endDatex").datebox('getValue');
	var branchName = $("#branchNamex").combobox("getValue");
	window.location.href = "/admin/analysis/validateExcelProduct.htm?beginDate="
			+ beginDate + "&endDate=" + endDate + "&branchName=" + branchName;
}

function excelunion() {

	var merchandiseNameu = $("#merchandiseNameu").val();
	var merchandiseCodeu = $("#merchandiseCodeu").val();
	var producuingNameu = $("#producuingNameu").val();
	var beginDate = $("#beginDate").datebox('getValue');
	var endDate = $("#endDate").datebox('getValue');
	var branchNameu = $("#branchNameu").combobox("getValue");

	window.location.href = "/admin/analysis/validateExcelUnion.htm?merchandiseNameu="
			+ merchandiseNameu + "&merchandiseCodeu=" + merchandiseCodeu
			+ "&producuingNameu=" + producuingNameu + "&beginDate=" + beginDate
			+ "&endDate=" + endDate + "&branchNameu=" + branchNameu;
}

function excelcustunion() {

	var custName = $("#custNameun").val();
	var loginName = $("#loginNameun").val();
	var beginDateun = $("#beginDateun").datebox('getValue');
	var endDateun = $("#endDateun").datebox('getValue');
	var custType = $("#custTypeun").combobox("getValue");
	var branchNameu = $("#branchNameun").combobox("getValue");
	window.location.href = "/admin/analysis/validateExcelcustunion.htm?custName="
			+ custName + "&loginName=" + loginName + "&beginDateun="
			+ beginDateun + "&endDateun=" + endDateun + "&custType=" + custType
			+ "&branchNameu=" + branchNameu;
}
function searchTGLTable() {
	$('#searchTGLTable').datagrid('options').queryParams = {
		"custName" : $("#custName").val(),
		"pyName" : $("#pyName").val(),
		"branchName" : $("#branchNamer").combobox("getValue"),
		"ywyName" : $("#ywyName").val(),
		"ywyTel" : $("#ywyTel").val(),
		"qtName" : $("#qtName").val(),
		"sStartTime" : $("#sStartTime").datebox('getValue'),
		"sEndTime" : $("#sEndTime").datebox('getValue')
	}, $("#searchTGLTable").datagrid('reload');
	$('#searchTGL').window('center');
	$("#searchTGL").window("close");
}
// 关闭打开窗口
function closeRegisterTable() {
	$("#statusDiv").window("close");
	$("#searchRegister").window("close");
}

function closeEorderTable() {
	$("#statusDiv").window("close");
	$("#searchEorder").window("close");
}
function closeNoEorderTable() {
	$("#statusDiv").window("close");
	$("#searchNoEorder").window("close");
}

function closeBranchTable() {
	$("#statusDiv").window("close");
	$("#searchBranch").window("close");
}
function closeSaleFairsTable() {
	$("#statusDiv").window("close");
	$("#searchSaleFairs").window("close");
}
function closeSellDetailTable() {
	$("#statusDiv").window("close");
	$("#searchSellDetail").window("close");
}
function closeBasketTable() {
	$("#statusDiv").window("close");
	$("#searchBasket").window("close");
}
function closeBasketMedTable() {
	$("#statusDiv").window("close");
	$("#searchBasketMed").window("close");
}
function closeAttentTable() {
	$("#statusDiv").window("close");
	$("#searchAttention").window("close");
}
function closeNewProductTable() {
	$("#statusDiv").window("close");
	$("#searchNewProduct").window("close");
}
function closeUnionTable() {
	$("#statusDiv").window("close");
	$("#searchUnion").window("close");
}
function closeUnionCustTable() {
	$("#statusDiv").window("close");
	$("#searchCustUnion").window("close");
}
function closeTGLTable() {
	$("#searchTGL").window("close");
}