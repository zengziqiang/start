
$(document).ready(function() {
	 $('.table-04 tr:even').addClass('alt');
   	 $('.table-04 tr').mouseover(function(){$(this).addClass('over')}).mouseout(function(){$(this).removeClass('over')})
$('.table-04 tr td a.show_tg').mousemove(function(e){
		
		var newtop=(e.pageY+12)+'px';	
		var newleft=(e.pageX+12)+'px';
		$('.all_product_div').css('left',newleft).css('top',newtop).fadeIn('fast');
	});
	$('.table-04 tr td a,.table-04').mouseout(function(){
		$('.all_product_div').hide();
	});
	$('.table-04').mouseover(function(){
		$('.all_product_div').hide();
		
		
	});
	
	if($('.show_s_t').val()!=''){$('span.show_label_tip').animate({opacity: 0},100,function(){$(this).css('visibility','hidden')			        ;});}
	$('.show_s_t').focus(function(){
		if ($(this).val()==''){
			$('span.show_label_tip').animate({opacity: 0.3},120);
		}else{
			$('span.show_label_tip').animate({opacity: 0},100,function(){$(this).css('visibility','hidden')		  	;});
		}
		}).blur(function(){
		if ($(this).val()==''){
			$('span.show_label_tip').css('visibility','visible').animate({opacity: 1},120);
		}else{
			$('span.show_label_tip').animate({opacity: 0},100,function(){$(this).css('visibility','hidden')			        ;});
		}
		}).keydown(function(){
		$(this).siblings('span.show_label_tip').animate({opacity: 0},100,function(){$(this).css('visibility		','hidden');});
	});
		$('span.show_label_tip').click(function(){$('.show_s_t').focus();});
		
		
	 $('.zg_am').click(function(){
		
		var nowis=$('.zg_bm').css("display") == "none" ? "" : "none";
		$('.zg_bm').css("display",nowis)
	})
   
	$('.zg_cur').click(function(){
		$('.zg_am').val($(this).html());
		$('.zg_bm').css('display','none');
	})
	$('.zg_cur').hover(function(){
			$(this).css('background-color','#EBEBEB').css('color','#f90');
		},function(){
			$(this).css('background-color','#fff').css('color','#007cd0');
			});
	$('.zg_bm').hover(function(){},function(){
		$(this).css('display','none');
	});
	
	//商家输入框
	
	 $('.show_am').click(function(){
		
		var nowis=$('.show_bm').css("display") == "none" ? "" : "none";
		$('.show_bm').css("display",nowis)
	})
   
	$('.show_cur').click(function(){
		$('.show_am').val($(this).html());
		$('.show_bm').css('display','none');
	})
	$('.show_cur').hover(function(){
			$(this).css('background-color','#EBEBEB').css('color','#f90');
		},function(){
			$(this).css('background-color','#fff').css('color','#788F72');
			});
	$('.show_bm').hover(function(){},function(){
		$(this).css('display','none');
	});
	
	
});		  



