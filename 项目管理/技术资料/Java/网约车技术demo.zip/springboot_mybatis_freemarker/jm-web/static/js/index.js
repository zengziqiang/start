﻿
$(document).ready(function() {
	init();
	$('.slidesjs-slide').each(function(k,i) {

		var real_src=$('.tu_real a img').eq(k).attr('src');
		var real_href=$('.tu_real a').eq(k).attr('href')
 		$(this).children('img').attr('src',real_src);
		$(this).attr('href',real_href);
});

});		  

function init(){
	//三个选项卡到位
		$('.qlink span a').hover(function(){$(this).parent('span').addClass('newv')},function(){$(this).parent('span').removeClass('newv')});
		$('.tabus_box div a img,.left_img a img').hover(function(){
			$(this).css('opacity',0.7);	
		},function(){
			$(this).css('opacity',1);	
		});
		$(".s_t").autocomplete(cities,{
		width:328,
		scrollHeight: 220
	});
		$('.tabus').children('div').children('span').mouseover(function(){
			$(this).parent('div').children('span').removeClass('tabchoose tabright_choose ad_choose');
			$(this).addClass('tabchoose tabright_choose ad_choose');
			$(this).parent('div').parent('div').children('div').hide();
			$(this).parent('div').parent('div').children('div').eq(0).show();
			var tab_bum=$(this).parent('div').children('span').index(this)+1;
			$(this).parent('div').parent('div').children('div').eq(tab_bum).show();
			
		})
		$('.tabus1').children('div').children('div').children('span').mouseover(function(){
			$(this).parent('div').children('span').removeClass('ad_choose');
			$(this).addClass('ad_choose');
			$(this).parent('div').parent('div').parent('div').children('div').hide();
			$(this).parent('div').parent('div').parent('div').children('div').eq(0).show();
			
			
			var tab_bum=$(this).parent('div').children('span').index(this)+1;
			$(this).parent('div').parent('div').parent('div').children('div').eq(tab_bum).show();
		})
		
		var n=3;
		
		$('.message_l:lt('+n+')').show();
		$('.message_l:odd').addClass('bs')
		$('.message_dot .dot').mouseover(function(){
			$('.message_dot .dot').removeClass('now_in');
			$(this).addClass('now_in');
			if($(this).index()==1){
				$('.message_l').hide();
				$('.message_l:lt('+n+')').show();
			 }
			else if($(this).index()==$('.message_dot .dot:last').index()){
				$('.message_l').hide();
				
			
				$('.message_l:gt('+5+')').show();
			 }else{
				 var m=$('.message_l:last').index()-n;
				 $('.message_l').show();
				 var x=n*($(this).index()-1);
				 $('.message_l:lt('+3+')').hide();
				 $('.message_l:gt('+5+')').hide();
			 }
			 
			});
	$('#slides').slidesjs({
	 effect: {
      	slide: {
        // Slide effect settings.
        speed: 250
          // [number] Speed in milliseconds of the slide animation.
      }},
      
		play: {
      active: true,
	  preload:true,
	  preloadImage:'/images/loading_s.gif',
        // [boolean] Generate the play and stop buttons.
        // You cannot use your own buttons. Sorry.
      effect: "slide",
        // [string] Can be either "slide" or "fade".
      interval: 7000,
	
	  pause: 1000,
        // [number] Time spent on each slide in milliseconds.
      auto: true,
	  hoverPause: true,
	  generateNextPrev: false,
        // [boolean] Start playing the slideshow on load.
      swap: true
        // [boolean] show/hide stop and play buttons
    }

     });

};

