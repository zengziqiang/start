//var searchType='1';  //设置搜索条件
//var param="";        //传递搜索值
//var showTimeStr='';
//var fairsBeginTime='';
//var fairsEndTime='';
//var pavilionId='';
function loadSelectedInput() {
	//$('.table-04 tr:even').addClass('alt');
  	 $('.table-04 tr').mouseover(function(){$(this).addClass('over')}).mouseout(function(){$(this).removeClass('over')})
$('.table-04 tr td a.show_tg').mousemove(function(e){
		
		var newtop=(e.pageY+12)+'px';	
		var newleft=(e.pageX+12)+'px';
		$('.all_product_div').css('left',newleft).css('top',newtop).fadeIn('fast');
	});
  	 
  	$('.table-04 tr td a.show_zc').mousemove(function(e){

  		var newtop=(e.pageY+12)+'px';	
  		var newleft=(e.pageX+12)+'px';
  		$('.all_product_div').html('<div class="all_zc">'+$(this).html()+'</div>');
  		$('.all_product_div').css('left',newleft).css('top',newtop).fadeIn('fast');
  		});
  	 
  	 
  	 
	$('.table-04 tr td a,.table-04').mouseout(function(){
		$('.all_product_div').hide();
	});
	$('.table-04').mouseover(function(){
		$('.all_product_div').hide();
		
		
	});
	
	$('.show_s_t').focus(function(){
		if ($(this).val()==''){
			$('span.show_label_tip').animate({opacity: 0.3},120);
		}else{
			$('span.show_label_tip').animate({opacity: 0},100,function(){$(this).css('visibility','hidden')		  	;});
		}
		}).blur(function(){
		if ($(this).val()==''){
			$('span.show_label_tip').css('visibility','visible').animate({opacity: 1},120);
		}else{
			$('span.show_label_tip').animate({opacity: 0},100,function(){$(this).css('visibility','hidden')			        ;});
		}
		}).keydown(function(){
		$(this).siblings('span.show_label_tip').animate({opacity: 0},100,function(){$(this).css('visibility		','hidden');});
	});
		$('span.show_label_tip').click(function(){$('.show_s_t').focus();});
		
		
	 $('.zg_am').click(function(){
		var nowis=$('.zg_bm').css("display") == "none" ? "" : "none";
		$('.zg_bm').css("display",nowis)
	})
  
	$('.zg_cur').click(function(){
		$('.zg_am').val($(this).html());
		$('.zg_bm').css('display','none');
	})
	$('.zg_cur').hover(function(){
			$(this).css('background-color','#EBEBEB').css('color','#f90');
		},function(){
			$(this).css('background-color','#fff').css('color','#007cd0');
			});
	$('.zg_bm').hover(function(){},function(){
		$(this).css('display','none');
	});
	
	//商家输入框
	
	 $('.show_am').click(function(){
		
		var nowis=$('.show_bm').css("display") == "none" ? "" : "none";
		$('.show_bm').css("display",nowis)
	})
  
	$('.show_cur').click(function(){
		$('.show_am').val($(this).html());
		$('.show_bm').css('display','none');
	})
	$('.show_cur').hover(function(){
			$(this).css('background-color','#EBEBEB').css('color','#f90');
		},function(){
			$(this).css('background-color','#fff').css('color','#788F72');
			});
	$('.show_bm').hover(function(){},function(){
		$(this).css('display','none');
	});
	
	if($('.show_s_t').val()!=''){$('span.show_label_tip').animate({opacity: 0},100,function(){$(this).css('visibility','hidden');});}
};	

//查询厂家信息
function searchFairsIndex(pageNum,pageSize,pavilionId,customerName,boothNumber)
{
	var url = '/sale/fairs/searchFairs.json';
	$.ajax({   
		type : "post",   
		url : url,
		data:{page:pageNum,rows:pageSize,pavilionId:pavilionId,customerName:customerName,boothNumber:boothNumber,startDate:fairsBeginTime,endDate:fairsEndTime},
		async : false,   
		success : function(data){   
			listFairs = parserToJson(data);
		}   
	}); 
	return listFairs;
}

//查询展馆
function searchPavilionIndex()
{
	var url = '/sale/fairs/searchPavilion.htm';
	$.ajax({   
		type : "post",   
		url : url,
		async : false,   
		success : function(data){   
			listPavilion = parserToJson(data);
		}   
	}); 
	return listPavilion;
}


//加载body 头
function loadBodyInfo(){
	var fairsBodyInfo="";
var pavilionResult=searchPavilionIndex();
fairsBodyInfo=fairsBodyInfo
+'<tr id="fairs_title">'
+'<th>展位号</th>'
+'<th width="100" >'
+'<input type="text" readonly="readonly" class="zg_am" id="am" value="展馆类型">'
+'<div class="zg_bm" style="display:none"> ';
$.each(pavilionResult,function(i,row){
	fairsBodyInfo=fairsBodyInfo+'<span class="zg_cur" onclick="paramePavilion('+row.pavilionId+')">'+row.pavilionName+'</span>';
	   
});
fairsBodyInfo=fairsBodyInfo+'</div></th><th>参展商家</th><th>参展品种数</th></tr>';
$('#fairs_tbody').append(fairsBodyInfo);
}
//加载参展厂家信息
function loadFairs(pageNum,pageSize)
{
 $("#fairs_tb tbody tr").eq(0).nextAll().remove();
	var fairsInfo="";
	var pavilionId=roomId;
	
	if(pavilionId==1)
		{
		pavilionId=null;
		}
	var customerName='';
    var boothNumber='';
	if(searchType=='1')
	{
		boothNumber=$("#searchString").val();
		
	}else{
		
		customerName=$("#searchString").val();
	}
	var fairsResult=searchFairsIndex(pageNum,pageSize,pavilionId,customerName,boothNumber);
	
	if(null==fairsResult.rows||""==fairsResult.rows)
		{
		return fairsResult.pagination;;
		}
	
	$.each(fairsResult.rows,function(i,row){
		fairsInfo=fairsInfo+'<tr><td>'+row.boothNumber+'</td>'
		+'<td>'+row.pavilionName+'</td>'		
		+'<td><a href="/sale/fairs/fairsToItem.htm?boothNumber='+row.boothNumber+'">'+row.customerName+'</a></td>'
		+'<td>'+row.fairsItemCount+'</td></tr>';  
	});
	$('#fairs_tbody').append(fairsInfo);
	return fairsResult.pagination;
}


//查询参展药品信息
function searchFairsItemsIndex(pageNum,pageSize,fairsTypeId,customerName,boothNumber,pavilionId)
{
	var url = '/sale/fairsItem/searchFairsItem.json';
	$.ajax({   
		type : "post",   
		url : url,   
		data:{fairsTypeId:fairsTypeId,page:pageNum,rows:pageSize,customerName:customerName,boothNumber:boothNumber,pavilionId:pavilionId,startDate:fairsBeginTime,endDate:fairsEndTime},
		async : false,   
		success : function(data){   
			listFairsItems= parserToJson(data);
		}   
	}); 
	return listFairsItems;

}

//加载返现参展药品
function loadFairsItemsFX(pageNum,pageSize)
{
	$('#fairsItemFX_tb').html('');
	var fairsItemInfo="";
	fairsItemInfo=fairsItemInfo+'<tbody>'
	+'<tr><th>药品名称/规格</th><th>生产厂家</th><th>中/大包装</th>'
	+'<th>会员价</th><th>零售价</th><th>库存</th><th>优惠政策</th>'
	+'<th>购买数量</th><th>操作</th></tr>';
	var customerName='';
    var boothNumber='';
    var pavilionId=roomId;
	if(searchType=='1')
	{
		boothNumber=$("#searchString").val();
		
	}else{
		
		customerName=$("#searchString").val();
	}
	
//	if(pavilionId!=null||''!=pavilionId)
//	{
//		customerName=null;//11111111
//		boothNumber=null;
//	}
	
	var fairsItemsResult=searchFairsItemsIndex(pageNum,pageSize,1,customerName,boothNumber,pavilionId);

	$.each(fairsItemsResult.rows,function(i,row){
		fairsItemInfo=fairsItemInfo+'<tr><td><a class="show_tg" onmouseover="updateFudDiv('+row.merchandiseId+')"  target="blank" href="/front/merchandise/detail.htm?id='+row.merchandiseId+'">'+row.currencyName+'</a></td>'
		+'<td><a href="#">'+(row.manufacturer==null?'--':row.manufacturer)+'</a></td>'
        +'<td>'+row.middlingPacking+'/'+row.packingNumber+'</td>'
        +'<td><span>'+(row.mermberPrice==null?'--':row.mermberPrice)+'</span></td>'
        +'<td>'+row.retailPrice+'</td>'
        +'<td><em>'+(row.storageNumber>100?'>100':'0-100')+'</em></td>'
        +'<td><a a class="show_zc">'+row.fairsPolicy+'</a></td>'
        +'<td><a class="minus" href="javascript:void(0);"><img src="/static/images/minus.gif"></a> <input id="num_'+row.merchandiseId+'" style="ime-mode: disabled;" class="price" value="1"> <a class="plus" href="javascript:void(0);"><img src="/static/images/plus.gif"></a></td>'
        +'<td class="check_td"><button onclick="fairsAddcart('+row.merchandiseId+')"  class="small_btn"></button></td></tr>';
      
	});
	
	fairsItemInfo=fairsItemInfo+'</tbody>';
	$('#fairsItemFX_tb').append(fairsItemInfo);
	return fairsItemsResult.pagination;
}


//加载返礼参展药品
function loadFairsItemsFL(pageNum,pageSize)
{
	$('#fairsItemFL_tb').html('');
	var fairsItemInfo="";
	fairsItemInfo=fairsItemInfo+'<tbody>'
	+'<tr><th>药品名称/规格</th><th>生产厂家</th><th>中/大包装</th>'
	+'<th>会员价</th><th>零售价</th><th>库存</th><th>优惠政策</th>'
	+'<th>购买数量</th><th>操作</th></tr>';
	var customerName='';
    var boothNumber='';
    var pavilionId=roomId;
	if(searchType=='1')
	{
		boothNumber=$("#searchString").val();
		
	}else{
		
		customerName=$("#searchString").val();
	}
//	alert(pavilionId);
//		if(pavilionId!=null||''!=pavilionId)
//		{
//			customerName=null;//11111111
//			boothNumber=null;
//		}
	
	var fairsItemsResult=searchFairsItemsIndex(pageNum,pageSize,2,customerName,boothNumber,pavilionId);
	$.each(fairsItemsResult.rows,function(i,row){
		fairsItemInfo=fairsItemInfo+'<tr><td><a class="show_tg" onmouseover="updateFudDiv('+row.merchandiseId+')"  target="blank" href="/front/merchandise/detail.htm?id='+row.merchandiseId+'">'+row.currencyName+'</a></td>'
		+'<td><a href="#">'+(row.manufacturer==null?'--':row.manufacturer)+'</a></td>'
        +'<td>'+row.middlingPacking+'/'+row.packingNumber+'</td>'
        +'<td><span>'+(row.mermberPrice==null?'--':row.mermberPrice)+'</span></td>'
        +'<td>'+row.retailPrice+'</td>'
        +'<td><em>'+(row.storageNumber>100?'>100':'0-100')+'</em></td>'
        +'<td><a a class="show_zc">'+row.fairsPolicy+'</a></td>'
        +'<td><a class="minus" href="javascript:void(0);">'
        +'<img src="/static/images/minus.gif"></a> '
        +'<input id="num_'+row.merchandiseId+'" style="ime-mode: disabled;" class="price" value="1"> '
        +'<a class="plus" href="javascript:void(0);"><img src="/static/images/plus.gif"></a></td>'
        +'<td class="check_td"><button onclick="fairsAddcart('+row.merchandiseId+')"  class="small_btn"></button></td></tr>';   
	});
	fairsItemInfo=fairsItemInfo+'</tbody>';
	$('#fairsItemFL_tb').append(fairsItemInfo);
	return fairsItemsResult.pagination;
}

//加载展位中药品
function  searchBoothFairsItems(pageNum,pageSize,boothNumber)
{
   var fairsItemsResult;
	var url = '/sale/fairsItem/searchFairsItem.json';
	$.ajax({   
		type : "post",   
		url : url,   
		data:{boothNumber:boothNumber,page:pageNum,rows:pageSize},
		async : false,   
		success : function(data){   
			fairsItemsResult= parserToJson(data);
		}   
	}); 
	return  fairsItemsResult;
}
function loadBoothFairsItems(pageNum,pageSize)
{
	$('#boothTitleDiv').html('');
	$('#boothFairsItemTb').html('');
	var boothFairsItemInfo="";
	var fairsItemsResult=searchBoothFairsItems(pageNum,pageSize,boothNum);
	boothFairsItemInfo=boothFairsItemInfo+'<tbody>'
	  +'<tr>'
	  +'<th>药品名称/规格</th>'
	  +'<th>生产厂家</th>'
	  +'<th>中/大包装</th>'
	  +'<th>会员价</th>'
	  +'<th>零售价</th>'
	  +'<th>库存</th>'
	  +'<th>优惠政策</th>'
	  +'<th>购买数量</th>'
	  +'<th>操作</th>'
	  +'</tr>';
	var titleInfo=fairsItemsResult.rows;
	var titleDiv='<P>展号位：'+titleInfo[0].boothNumber+'</P>'
	+'<p class="c_t">'+titleInfo[0].customerName+'</p>';
	$.each(fairsItemsResult.rows,function(i,row){
		boothFairsItemInfo=boothFairsItemInfo+'<tr>'
		+'<td><a class="show_tg" onmouseover="updateFudDiv('+row.merchandiseId+')"  target="blank" href="/front/merchandise/detail.htm?id='+row.merchandiseId+'">'+row.currencyName+'</a></td>'
		+'<td><a href="#">'+(row.manufacturer==null?'--':row.manufacturer)+'</a></td>'
		+'<td>'+row.middlingPacking+'/'+row.packingNumber+'</td>'
		+'<td><span>'+(row.mermberPrice==null?'--':row.mermberPrice)+'</span></td>'
		+'<td>'+row.retailPrice+'</td>'
		+'<td><em>'+(row.storageNumber>100?'>100':'0-100')+'</em></td>'
		+'<td><a class="show_zc">'+row.fairsPolicy+'</a></td>'
		+'<td><a class="minus" href="javascript:void(0);">'
		+'<img src="/static/images/minus.gif"></a> '
		+'<input id="num_'+row.merchandiseId+'" style="ime-mode: disabled;" class="price" value="1"> '
		+'<a class="plus" href="javascript:void(0);">'
		+'<img src="/static/images/plus.gif"></a></td>'
		 +'<td class="check_td"><button onclick="fairsAddcart('+row.merchandiseId+')"  class="small_btn"></button></td></tr>';
	});
	boothFairsItemInfo=boothFairsItemInfo+'</tbody>';
	$('#boothTitleDiv').append(titleDiv);
	$('#boothFairsItemTb').append(boothFairsItemInfo);
	return fairsItemsResult.pagination;
}
	
//根据展馆筛选
function paramePavilion(spanPavilionId)
{
	//展馆的时清空搜索条件
	
	// searchType='1';  //设置搜索条件
	 param="";
	// $("#searchName").val('展位号');
	// $("#searchString").val('');
	roomId=spanPavilionId;
	setJumpHREF();
	window.location.href='/sale/fairs/indexRoom.htm?roomId='+roomId;
	//pageInit(loadFairs,20);
}

function fairsAddcart(merchandiseId)
{
	var num=$('#num_'+merchandiseId).val();
	if(0==num||null==num||""==num)
		{
		alert("请输入购买数量!");
		return;
		}
	var reg = new RegExp("^(0|[1-9][0-9]*)$");
	if(!reg.test(num)){
        alert("请输入正确数量!");
        return;
    }
	//退货品种提示
	var json = isReturnMerchandise(merchandiseId);
	if(json.isNotReturnType && (!confirm(json.message))){
		return;
	}
	
	var aerray="[{merchandiseId:"+merchandiseId+",merchandiseNumber:"+num+"}]";
	var json = check_cart(aerray);//加入购物车
	//if(returnValue != null && returnValue!=""){
//		alert(returnValue);
//	}
	//if(returnValue=="添加失败"){
	if(json==undefined){
	("#checkbox"+merchandiseId).removeAttr('checked');
		}
	//}
}

function updateFudDiv(merchandiseId)
{
	var url  ="/merchandise/oneMerchandise.json";
	$("#fuMerchdise").html('');
	jsonData = "merchandise_id="+merchandiseId;
	$.ajax({
		  type : "GET",                 
		  url: url,
		  data:jsonData,
		  async:false,
		  success: function(data){
			  var json = parserToJson(data);
			  var merchandiseImagePath = json.merchandiseImagePath;
			  var orgmerchandiseCode = json.merchandise.orgmerchandiseCode;
			  var temp ='<div class="all_product_div_t">'+json.merchandise.merchandiseName+'</div>'
				  		+'<div class="float_img"><img src="'+merchandiseImagePath+orgmerchandiseCode+'/'+orgmerchandiseCode+'.JPG" width="150" height="113" /></div>'
				  		+'<div class="float_font">'
				  		+'<p>商品编码：'+orgmerchandiseCode +'</p>'
				  		+'<p>批准文号：'+json.merchandise.passfileNumber+'</p>'
				  		+'<p>销售类别：未知</p>'
				  		+'<p>是否拆零：是</p>'
				  		+'<p>处方分类：乙类</p>'
				  		+'<p>有效期：'+json.merchandise.fvalidity+'</p>'
				  		+'</div>';
			 $("#fuMerchdise").append(temp);
		  }
	});
}

//设置搜索条件
function setSearchType(typeValue)
{
	searchType=typeValue;
	setJumpHREF();
}


//搜索按钮功能
function searchFairsByQuery()
{
	//搜索的时候展馆设置为null，
//	 roomId=1;
	//判断类型
	 
	var param=$("#searchString").val();
	 var ready=validationSearchParam(param);
	 if(false==ready)
		 {
		 return;
		 }
	window.location.href = '/sale/fairs/fairsToBooth.htm?promotionState=0&searchType='+searchType+'&param='+param+'&roomId='+roomId;
	// pageInit(loadFairs,20);
	 //setSelectedVal();
}

function searchFairsItemfYByQuery(){
	//判断类型
	var param=$("#searchString").val();
	 var ready=validationSearchParam(param);
	 if(false==ready)
	 {
	 return;
	 }
	 setJumpHREF();
	// pageInit(loadFairsItemsFL,20);
	 window.location.href = '/sale/fairs/fairsToBooth.htm?promotionState=1&searchType='+searchType+'&param='+param+'&roomId='+roomId;
}

function searchFairsItemflByQuery()
{
	//判断类型
	var param=$("#searchString").val();
	 var ready=validationSearchParam(param);
	 if(false==ready)
	 {
	 return;
	 }
	 setJumpHREF();
	// pageInit(loadFairsItemsFL,20);
	 window.location.href = '/sale/fairs/fairsToBooth.htm?promotionState=1&searchType='+searchType+'&param='+param+'&roomId='+roomId;
}

function searchFairsItemfxByQuery()
{
	//判断类型
	 param=$("#searchString").val();
	 var ready= validationSearchParam(param);
	 if(false==ready)
	 {
	 return;
	 }
	 setJumpHREF();
	 pageInit(loadFairsItemsFX,20);

}

//验证搜索条件
function validationSearchParam(validationParam)
{
	
	var reg = new RegExp("^[0-9]*$");
	
	 //搜索条件验证
		 if(searchType=='1')
		 {	 
			 if(!reg.test(validationParam)){
			        alert("请输入数字!");
			        return false;
			    }
		 }else{
			 if(''==validationParam||null==validationParam)
				 {	 
				 alert("请输入厂家名称!");
			        return false;
				 }
		 }
}


//点搜索就设置跳转链接
function setJumpHREF()
{
	var param=$("#searchString").val();
	$("#jump_01").attr('href','/sale/fairs/fairsToBooth.htm?promotionState=0&&searchType='+searchType+'&&param='+param+'&roomId='+roomId);
	$("#jump_02").attr('href','/sale/fairs/fairsToBooth.htm?promotionState=1&&searchType='+searchType+'&&param='+param+'&roomId='+roomId);
	$("#jump_03").attr('href','/sale/fairs/fairsToBooth.htm?promotionState=2&&searchType='+searchType+'&&param='+param+'&roomId='+roomId);
	$("#jump_04").attr('href','/sale/fairs/fairsToBooth.htm?promotionState=3&&searchType='+searchType+'&&param='+param+'&roomId='+roomId);
}

//设置跳转后的下拉框值
function setSelectedVal(pId)
{
	
	var pavilionResult=searchPavilionIndex();
	$.each(pavilionResult,function(i,row){
		if(pId==row.pavilionId)
			{
			$("#am").val(row.pavilionName);  
			}   
	});
}

//查询展会时间
function searchPavilionSwitch(){
	 var pavilionTime;
		var url = '/sale/fairs/searchPavilionClose.json?'+Math.random();
		var result;
		$.ajax({   
			type : "post",   
			url : url,   
			async : false,   
			success : function(data){   
				result =parserToJson(data);
				
			}   
		}); 
  return result;
}



//设置页面时间
function setPavTime()
{
	
	var fairsTo='';
	var result=searchPavilionSwitch();
     fairsBeginTime=result[0].startDate==null?'':result[0].startDate.substr(0, 10);
     fairsEndTime=result[0].endDate==null?'':result[0].endDate.substr(0, 10);
     fairsTo=result[0].customerName==null?'':result[0].customerName;
	showTimeStr='本次展销时间：'+fairsBeginTime+ ' - ' +fairsEndTime+'   展销对象：'+fairsTo;
	
}

function setPhtml(pid)
{
	$("#p_pavTime"+pid).html('');
	$("#p_pavTime"+pid).append(showTimeStr);
}