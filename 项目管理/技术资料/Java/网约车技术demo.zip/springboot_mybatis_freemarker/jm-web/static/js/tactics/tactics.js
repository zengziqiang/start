//---------------------------------------------------- 界面
//查询展销会展台
var isEdit = false;//是新增还是修改的标识，true表示修改，false表示新增
function loadAllM(){
		$('#MTable').datagrid({
			//fit : true,
			striped: true,
			//fitColumns:true,
			toolbar:"#MToolbar",
			url:'/admin/sale/tactics/tacticsAllM.htm',
			method:'post',
			pageSize : 15,
			pageNumber : 1,
			pagination:true,
			singleSelect:false,
			rownumbers:true,
			idField:'merchandiseId',
			frozenColumns:[[
	            {field:'merchandiseIds',checkbox:true}
			]],
			onAfterEdit: function (rowIndex, rowData, changes) {
				editRow2 = undefined;
	        },
	        onClickRow:function (rowIndex, rowData) {
	            if (editRow2 != undefined) {
	                $("#MTable").datagrid('endEdit', editRow2);
	            }
	        
	                $("#MTable").datagrid('beginEdit', rowIndex);
	                editRow2 = rowIndex;
	          
	        },
			columns:[[
				{title:'药品名称', field:'merchandiseName', align:'left', resizable:true,width:'120'},
				{title:'药品规格', field:'merchandiseSpec', align:'left', resizable:true,width:'100'},
				{title:'药品编码', field:'orgmerchandiseCode', align:'left', resizable:true,width:'100'},
				{title:'活动名称', field:'aktionsprogrammName', align:'left', resizable:true,width:'80'},
				{title:'活动类型', field:'aktionsprogrammTypeName', align:'left', resizable:true,width:'80'},
				{title:'开始时间', field:'startTime', align:'left', resizable:true,width:'70'},
				{title:'结束时间', field:'endTime', align:'left', resizable:true,width:'70'},
				{title:'排序', field:'morder', align:'left', resizable:true,width:'80',editor:{type:'numberbox',options:{precision:0}}}
			]]
		});	
}

function loadAllTactics(){
		$('#saleTacticsItemTable').datagrid({
			fit : true,
			striped: true,
			fitColumns:true,
			toolbar:"#toolbar",
			url:'/admin/sale/tactics/serchTactics.htm',
			method:'post',
			pageSize : 15,
			pagination:true,
			singleSelect:false,
			rownumbers:true,
		//	idField:'aktionsprogrammId',
			frozenColumns:[[
	            {field:'aktionsprogrammIds',checkbox:true}
			]],
			
			columns:[[
				{title:'策略名称', field:'aktionsprogrammName', align:'left', resizable:true},
				{title:'策略类型', field:'aktionsprogrammTypeName', align:'left', resizable:true},
				//{title:'品种规则', field:'merchandiseRuleName', align:'left', resizable:true},
				{title:'策略状态', field:'stateName', align:'left', resizable:true},
				{title:'开始时间', field:'startTime', align:'left', resizable:true},
				{title:'结束时间', field:'endTime', align:'left', resizable:true},
				{title:'创建时间', field:'maintenancetime', align:'left', resizable:true},
				{title:'兑换规则', field:'tacticsDesc', align:'left', resizable:true},
				{title:'促销政策', field:'tacticsContent', align:'left', resizable:true}
			]]
		});	
}
//加载品种表
function loadMDetail(parm){
	if(parm==2){
		$('#tacticsItemClientTable2').datagrid({
			//fit : true,
			striped: true,
			//fitColumns:true,
			async:false,
			toolbar:"#addToolbar2",
			url:'',
			pageSize :5,
			pageList:[5],
			pageNumber : 1,
			pagination:false,
			singleSelect:false,
			rownumbers:true,
			idField:'merchandiseId',
			frozenColumns:[[
				            {field:'merchandiseIds',checkbox:true}
						]],
			onAfterEdit: function (rowIndex, rowData, changes) {
	            editRow = undefined;
	        },
	        onClickRow:function (rowIndex, rowData) {
	            if (editRow != undefined) {
	                $("#tacticsItemClientTable2").datagrid('endEdit', editRow);
	            }
	            
	                $("#tacticsItemClientTable2").datagrid('beginEdit', rowIndex);
	                editRow = rowIndex;
	            
	        },
		
			columns:[[
				{title:'药品编码', field:'orgmerchandiseCode', align:'left', resizable:true,width:'80'},
			    {title:'药品名称', field:'merchandiseName', align:'left', resizable:true,width:'180'},
				{title:'药品规格', field:'merchandiseSpec', align:'left', resizable:true,width:'80'},
				{title:'药品单位', field:'merchandiseUnit', align:'left', resizable:true,width:'65'},
				{title:'中包装数量', field:'packingNumber', align:'left', resizable:true,width:'80'},
				{title:'促销政策', field:'content', align:'left', resizable:true,width:'100',editor: {type:'text'}},
				{title:'采购药品金额', field:'tactics', align:'left', resizable:true,width:'90',editor:{type:'numberbox',options:{precision:3}}},
				{title:'赠送九州币', field:'currency', align:'left', resizable:true,width:'65'}
			]]
		});
	}
	else if(parm==3){
			$('#tacticsItemClientTable2').datagrid({
				//fit : true,
				striped: true,
				//fitColumns:true,
				toolbar:"#addToolbar2",
				url:'',
				async:false,
				pageSize :5,
				pageList:[5],
				pageNumber : 1,
				pagination:false,
				singleSelect:false,
				rownumbers:true,
				idField:'merchandiseId',
				frozenColumns:[[
		            {field:'merchandiseIds',checkbox:true}
				]],
				columns:[[
					{title:'药品编码', field:'orgmerchandiseCode', align:'left', resizable:true,width:80},
					{title:'药品名称', field:'merchandiseName', align:'left', resizable:true,width:220},
					{title:'药品规格', field:'merchandiseSpec', align:'left', resizable:true,width:80},
					{title:'药品单位', field:'merchandiseUnit', align:'left', resizable:true,width:80},
					{title:'中/大包装数量', field:'packingNumber', align:'left', resizable:true,width:100}
				]]
			});	
			
	}else{	
		$('#tacticsItemClientTable3').css("display","none");
	}
}
//加载表单界面
function loadinitface(newValue){
	ism =0;isclient =0;
	switch(newValue){
    case '1':{
    	$('#divvarieties').css("display","none");
    	$('#divtactics').css("display","inline");
    	$('#tacticsItemClientTable3').css("display","none");
    }break;
    case '2':{
    	$('#divvarieties').css("display","none");
    	$('#divtactics').css("display","none");
		$('#tacticsItemClientTable3').css("display","inline");
    	loadMDetail(2);
    }break;
    case '3':{
    	$('#divvarieties').css("display","inline-block");
    	$('#divtactics').css("display","inline");
    	if($('input[name="varieties"]:checked').val()=='1'){
    	$('#tacticsItemClientTable3').css("display","none");
    	}
    	else{
    		$('#tacticsItemClientTable3').css("display","inline");
    		loadMDetail(3);
    	}
    }break;
    }
}
//----------------------------------------------------客户单位
//打开客户单位窗口
function showUsersDiv()
{
	$('#saleUsersItemTable').datagrid('uncheckAll');
	$('#usersDiv').window('open');
}
//关闭客户单位窗口
function addUsersClose()
{
	$('#usersDiv').window('close');
}
//删除选中单位客户
function delTacticsItem()
{                           
	var rows = $('#tacticsItemClientTable').datagrid("getSelections");	//获取你选择的所有行	
	//循环所选的行
	if(rows.length ==0)
	{
		$.messager.alert('提示', '请选择要删除的行信息！');
		return;
	}
	else
	{
		var tempdanwnm ='';
		for(var i =rows.length-1;i>=0;i--)
		  {
			tempdanwnm =tempdanwnm+rows[i].custName+",";
		  }
		$.messager.confirm("提示","确定要删除 "+ tempdanwnm+" 客户单位",function(result){
		 if(result){
			for(var i =rows.length-1;i>=0;i--)
			  {
			    var tempstr = "/,"+rows[i].danwBh+",/g";
			    clients= clients.replace(eval(tempstr), ",");
		        var index = $('#tacticsItemClientTable').datagrid('getRowIndex',rows[i]);//获取某行的行号
				$('#tacticsItemClientTable').datagrid('deleteRow',index);
			  }
		   }
		  else{ return;}
		});
	}
}
//删除全部单位客户
function delAllTacticsItem()
{                   
	if(isclient==1){
		isclient=2;
	};
	var rows = $('#tacticsItemClientTable').datagrid("getData");	//获取所有行	
	if(rows.length ==0)
	{
		$.messager.alert('提示', '没有要删除的行信息！');
		return;
	}
	$.messager.confirm("提示","确定要删除全部客户单位",function(result){
		 if(result){
				$('#tacticsItemClientTable').datagrid('loadData', { total: 0, rows: [] });
				clients=',,';
		   }
		  else{ return;}
		});
}
//加载当前客户单位
function loadUsersDetail(){
	$('#tacticsItemClientTable').datagrid({
		//fit : true,
		striped: true,
		fitColumns:true,
		toolbar:"#addToolbar",
		url:'/admin/sale/tactics/serchTacticsDetail.htm',
		pageSize :5,
		pageList:[5],
		pageNumber : 1,
		pagination:false,
		singleSelect:false,
		rownumbers:true,
		idField:'danwBh',
		frozenColumns:[[
            {field:'danwBhs',checkbox:true}
		]],
		columns:[[
			{title:'客户编码', field:'danwBh', align:'left', resizable:true,width:80},
			{title:'客户名称', field:'custName', align:'left', resizable:true,width:120},
			{title:'登陆帐号', field:'loginName', align:'left', resizable:true,width:100},
			{title:'客户类型', field:'custTypeName', align:'left', resizable:true,width:80},
			{title:'客户区域', field:'custArea', align:'left', resizable:true,width:80},
			{title:'注册时间', field:'loginTime', align:'left', resizable:true,width:80}
		]]
	});	
}
//加载所有客户单位
function loadAllUsers(){
	$('#saleUsersItemTable').datagrid({
		fit : true,
		striped: true,
		fitColumns:true,
		toolbar:"#usersToolbar",
		url:'/basic/get_cust_main.json',
		method:'post',
		pageSize : 15,
		pageNumber : 1,
		pagination:true,
		singleSelect:false,
		rownumbers:true,
		idField:'danwBh',
		queryParams:{'tcmStatus':2},
		frozenColumns:[[
            {field:'danwBhs',checkbox:true}
		]],
		columns:[[
			{title:'客户单位编码', field:'danwBh', align:'left', resizable:true,width:200},
			{title:'客户单位名称', field:'custName', align:'left', resizable:true,width:200}
		]]
	});	
}
//添加客户单位
function usersFormCommint()
{
		 var rows = $('#saleUsersItemTable').datagrid('getSelections'); 
		 for(var i=0; i<rows.length; i++){  
	         var row = rows[i];  
	         if(clients.indexOf(","+row.danwBh+",") < 0 )   
	         {   
	             $("#tacticsItemClientTable").datagrid("appendRow", row);
	        	 clients= clients+row.danwBh+",";  
	         }  
	     } 
		 $("#usersDiv").window("close");
}
//根据条件查询客户
function searchCust() {
	$('#saleUsersItemTable').datagrid('options').queryParams = {
		"custName" : $("#searchUsersName").val(),
		"tcmStatus":2,
		"danwBh" : $("#searchUsersCode").val()
	};
	$("#saleUsersItemTable").datagrid('reload');
}
//----------------------------------------------------策略
//打开新增策略窗口
function showAddTacticsDiv()
{
	 isEdit = false;
	 isclient =0;
	 ism =0;
	 issubmit=0;
	 isUporIn = "In";
	 loadinitface('2');
	 cleanForm();
	 $('#saleTacticsItemTable').datagrid('uncheckAll');
	
	 //loadMDetail(2);
	$('#addTacticsDiv').panel({'title':'新增九州币活动策略'});
	$('#addTacticsDiv').window('open');
	
}
//关闭策略窗口
function addTacticsClose()
{
	issubmit = 0;
	cleanForm();
	$('#addTacticsDiv').window('close');
}
//清空表单
function cleanForm(){
	isclient =0; 
	ism =0;
	//$('#btnTacticsOk').css("display","inline");
	//$('#btnTacticsOk').linkbutton("disable",true);
	$('#btnTacticsOk').linkbutton("enable");
 	$('#divvarieties').css("display","none");
	$('#divtactics').css("display","none");
	$('#tacticsInfo').val('');
	$('#start_timebox').datetimebox('setValue','');
	$('#end_timebox').datetimebox('setValue','');
	$('#aktionsprogrammName').val('');
	$('#tactics').val('');
	$('#startTime').val('');
	$('#endTime').val('');
	$('#tacticsContent').val('');
	$('#aktionsprogrammId').val('0');
	$('#tacticsItemClientTable').datagrid('options').queryParams = {
		"tacticsId" : 0
	};
	$('#tacticsItemClientTable').datagrid('loadData', { total: 0, rows: [] });
	$('#start_timebox').datetimebox({disabled:false});  
	$('#end_timebox').datetimebox({disabled:false});  
	$('#tacticTypeCombox').combobox('select',2);
	$('#merchandiseRule').val('');
	$('#aktionsprogrammType').val('');
	$('#state').val('1');
	$("input[name=varieties]:eq(0)").attr("checked",'checked');
	clients=",,";
	merchandises =",,";
	if($('#tacticsItemClientTable2')){
		///admin/sale/tactics/serchTacticsM.htm
		  $('#tacticsItemClientTable2').datagrid({url:''});
		$('#tacticsItemClientTable2').datagrid('options').queryParams = {
			"tacticsId" : -1
		};
	   $('#tacticsItemClientTable2').datagrid('loadData', { total: 0, rows: [] });
	   $("#tacticsItemClientTable2").datagrid('reload');
	}
	
	//清空区域、客户
	loadArea('');
	loadCustType('');
	$("#clientRow").val('');//新增时清空选择的客户
	
}
//打开修改信息
function modTactics()
{
	
	 isEdit = true;
	 var rows = $("#saleTacticsItemTable").datagrid("getSelections");
		if (rows.length==0) {
			$.messager.alert('提示',"请选择要修改的策略信息",'info');
			return;
		}
		else if(rows.length==1){
			//$.messager.alert('提示',(rows[0].merchandiseRule-1),'info');
			//$('#start_timebox').datetimebox({disabled:true});  
			//$('#end_timebox').datetimebox({disabled:true});  
			$('#tacticsInfo').val(rows[0].aktionsprogrammId);
			$('#tacticsContent').val(rows[0].tacticsContent);
			$('#start_timebox').datetimebox('setValue',rows[0].startTime);
			$('#end_timebox').datetimebox('setValue',rows[0].endTime);
			$('#aktionsprogrammName').val(rows[0].aktionsprogrammName);
			$('#aktionsprogrammId').val(rows[0].aktionsprogrammId);
			$('#tactics').val(rows[0].tactics);
			$('#tacticsItemClientTable').datagrid('options').queryParams = {
				"tacticsId" : rows[0].aktionsprogrammId
			};
			
			//修改时加载区域、客户类型
			loadArea(rows[0].aktionsprogrammId);
			loadCustType(rows[0].aktionsprogrammId);
			
			$("#tacticsItemClientTable").datagrid('reload');
	
			$('#tacticTypeCombox').combobox('select',rows[0].aktionsprogrammType);
			if($('#tacticsItemClientTable2')){
				 $('#tacticsItemClientTable2').datagrid({url:'',queryParams:{"tacticsId" : 0}});
			}
			if(rows[0].aktionsprogrammType==3){
			    $("input[name=varieties]:eq("+(rows[0].merchandiseRule-1)+")").attr("checked",'checked');
			    loadinitface('3');
			}
			else{
				loadinitface('2');
			    }
			 isclient=1;
			 ism =1;
			    $('#tacticsItemClientTable2').datagrid({url:'/admin/sale/tactics/serchTacticsM.htm',queryParams:{"tacticsId" : rows[0].aktionsprogrammId}});
		//		$('#tacticsItemClientTable2').datagrid('options').queryParams = {
		//			"tacticsId" : rows[0].aktionsprogrammId
		//		};
				$("#tacticsItemClientTable2").datagrid('reload');
				
			$('#addTacticsDiv').panel({'title':'修改九州币活动策略'});
			$('#addTacticsDiv').window('open');
		}
		else{
			$.messager.alert('提示',"请选择一条要修改的策略信息",'info');
			return;
		}
		if(rows[0].state==3 || rows[0].state ==4 ||rows[0].state ==2){
			$('#btnTacticsOk').linkbutton("disable");
			$.messager.alert('提示',"已开始、已结束、已终止的活动仅供查看无法修改！",'info');
			return;
		}
		else{
			$('#btnTacticsOk').linkbutton("enable");
		}
		$('#tacticsItemClientTable').datagrid('uncheckAll');
		$('#tacticsItemClientTable2').datagrid('uncheckAll');
}
function startTactics(){
	 var rows = $("#saleTacticsItemTable").datagrid("getSelections");
		if (rows.length==0) {
			$.messager.alert('提示',"请选择要修改的策略信息",'info');
			return;
		}
		if (rows.length>1) {
			$.messager.alert('提示',"请选择一条要修改的策略信息",'info');
			return;
		}
	if(rows[0].state==3 || rows[0].state ==4 ){
		//$('#btnTacticsOk').css("display","none");
		$.messager.alert('提示',"该活动已结束或已终止！",'info');
		return;
	}
	$("#startName").val(rows[0].aktionsprogrammName);
	$("#startId").val(rows[0].aktionsprogrammId);
	$('#startState').val(rows[0].state);
	$('#starttimeks').val(rows[0].startTime);
	$('#startDiv').window('open');
	
}
function cutM(){
	$('#MTable').datagrid('uncheckAll');
	$('#MDiv').window('open');
	
}
function startSub(){
	var sd ="终止";
	if($('input[name="startType"]:checked').val()=='2'){
		sd="开启";
		if($('#startState').val()=='2'){
			$.messager.alert('提示','当前活动已开启！','error');
			return;
		}	
		var ssDate = formatDate($('#starttimeks').val(),"yyyy-MM-dd");
	    var curDate = formatDate(new Date().format("yyyy-MM-dd"),"yyyy-MM-dd");
		if(curDate>ssDate){
			$.messager.alert('提示','当前时间处于活动时间之内，请修改活动开始时间后重新添加！','error');
			return;
		}
		if(curDate<ssDate){
			$.messager.alert('提示','该活动不能提前开启，请修改活动时间！','error');
			return;
		}
	}
	if($('input[name="startState"]:checked').val()==$('#startState').val()){
	    $.messager.alert('提示','活动已开启！','error');
		return;
	}
	if($('#startState').val()==1&&$('input[name="startType"]:checked').val()=='4'){
	    $.messager.alert('提示','活动未开启不能进行终止！','error');
		return;
	}

	var tempdanwName =$("#startName").val();
	$.messager.confirm("提示","确定要 "+sd+tempdanwName+" 九州币策略？",function(result){
		 if(result){
			$('#startState').val($('input[name=startType]:checked').val());
            $('#startForm').form('submit',{
	             url:"/admin/sale/tactics/start.htm",
	     		 onSubmit:function(){},
	             success:function(data){  
	    	            var text = parserToJson(data);
	    	            if(text.success) {
	    	            	  loadAllTactics();
		    		          $.messager.alert('提示',text.msg,'info');
		    		         $("#saleTacticsItemTable").datagrid("uncheckAll");
		    		         $("#MTable").datagrid('reload');
		    	         }
		    	         else {
		    		          $.messager.alert('发生错误',text.msg,'error');
		    		          }
	    	            $('#startDiv').window('close');
	             }
	    	});
		  }
		 });

}
//删除策略
function delTactics()
{
	 var rows = $("#saleTacticsItemTable").datagrid("getSelections");
		if (rows.length) {
			var tempdanwbh ='';
			var tempdanwName ='';
			for (var i=0;i<rows.length;i++)
             {
       	   		 tempdanwbh+=rows[i].aktionsprogrammId+',';
       	  		 tempdanwName+=rows[i].aktionsprogrammName+',';
            }                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             
			$.messager.confirm("提示","确定要删除 "+tempdanwName+" 九州币策略？",function(result){
				 if(result){
					 $("#tacticsIds").val(tempdanwbh.substring(0,tempdanwbh.length-1));
	                 $('#tacticsIdsForm').form('submit',{
	  	             url:"/admin/sale/tactics/del.htm",
	  	     		 onSubmit:function(){},
	  	             success:function(data){  
	  	    	            var text = parserToJson(data);
	  	    	            if(text.success) {
	  	    	            	  loadAllTactics();
	  		    		          $.messager.alert('提示',text.msg,'info');
	  		    		        $("#saleTacticsItemTable").datagrid("uncheckAll");
	  		    	         }
	  		    	         else {
	  		    		          $.messager.alert('发生错误',text.msg,'error');
	  		    		          }
	  	             }
	  	    	});
				  }
				 });
		}
		else{
			 $.messager.alert('提示',"请选择要删除的策略信息",'info');
		}
	}

function searchM() {
	$('#MTable').datagrid('options').queryParams = {
		"aktionsprogrammType" : $("#searchTType").datebox('getValue'),
		"aktionsprogrammName" : $("#searchTName").val(),
		"startTime1" : $("#searchStartime1").datebox('getValue'),
		"startTime2" : $("#searchStartime2").datebox('getValue'),
		"endTime1" : $("#searchEndtime1").datebox('getValue'),
		"endTime2" : $("#searchEndtime2").datebox('getValue'),
		"merchandiseName" : $("#searchMName").val(),
		"orgmerchandiseCode" : $("#searchMCode").val()
	};
	editRow2 = undefined;
	$("#MTable").datagrid('reload');
}
function delMItem()
{                           
	var rows = $('#tacticsItemClientTable2').datagrid("getSelections");	//获取你选择的所有行	
	//循环所选的行
	if(rows.length ==0)
	{
		$.messager.alert('提示', '请选择要删除的行信息！');
		return;
	}
	else
	{
		var tempmname ='';
		for(var i =rows.length-1;i>=0;i--)
		  {
			tempmname =tempmname+rows[i].merchandiseName+",";
		  }
		$.messager.confirm("提示","确定要删除 "+ tempmname+" 药品",function(result){
		 if(result){
			for(var i =rows.length-1;i>=0;i--)
			  {
		        var index = $('#tacticsItemClientTable2').datagrid('getRowIndex',rows[i]);//获取某行的行号
				$('#tacticsItemClientTable2').datagrid('deleteRow',index);
			  }
		   }
		  else{ return;}
		});
	}
}
//删除全部药品
function delAllMItem()
{                   
	if(ism==1){
		ism=2;
	};
	var rows = $('#tacticsItemClientTable2').datagrid("getData");	//获取所有行	
	if(rows.length ==0)
	{
		$.messager.alert('提示', '没有要删除的行信息！');
		return;
	}
	$.messager.confirm("提示","确定要删除全部药品",function(result){
		 if(result){
				$('#tacticsItemClientTable2').datagrid('loadData', { total: 0, rows: [] });
		   }
		  else{ return;}
		});
}
//清空查询条件按钮
function cleanM(){
	
	$('#searchEndtime1').datetimebox('setValue','');
	$('#searchEndtime2').datetimebox('setValue','');
	$('#searchStartime1').datetimebox('setValue','');
	$('#searchStartime2').datetimebox('setValue','');
	$('#searchMCode').val('');
	$('#searchMName').val('');
	$('#searchTName').val('');
	 $('#searchTType').combobox('select',0);
}

function cleanT(){
	
	$('#searchStartDate1').datetimebox('setValue','');
	$('#searchStartDate2').datetimebox('setValue','');
	$('#searchEndDate1').datetimebox('setValue','');
	$('#searchEndDate2').datetimebox('setValue','');
	$('#searchTacticsName').val('');
	$('#searchTacticsType').combobox('select',0);
	$('#searchTacticsState').combobox('select',0);
	
}

//自动加载区域信息
function loadArea(tacticId){
	 if(isEdit){
		 areurl = '/admin/sale/'+tacticId+'/get_all_area.json';
	 }else{
		 areurl = '/basic/cust_areanew.json?level=2';
	 }
	 $('#areatree').combotree({  
		    url:areurl ,  
		    multiple:true,
		    onLoadSuccess: function (row, data) {
		    	    $('#areatree').combotree('tree').tree("collapseAll"); 
		    }  
		  }); 
}

//自动加载客户单位类型
function loadCustType(tacticId){
	 if(isEdit){
		 areurl = '/admin/sale/'+tacticId+'/get_cust_type.json';
	 }else{
		 areurl = '/basic/get_cust_type.json';
	 }
	 $('#custtype').combobox({  
		    url:areurl ,  
		    multiple:true,
		    valueField:'id',  
			textField:'text'
	}); 
}