﻿$(document).ready(function() {
	pageInit(loadDetail,10);
	loadFamous();
	//加载同类品牌
	loadPic();
});
function loadPic(){
	var beginOrderId = $('#beginOrderId').val();
	var endOrderId = $('#endOrderId').val();
	if(beginOrderId != '' && endOrderId != ''){
		var data = selectPic(beginOrderId,endOrderId);
		innerPic(data,beginOrderId);
	}
	
}

function selectPic(beginOrderId,endOrderId){
	var url = '/front/indexPic/listPicByOrder.json?'+Math.random();
	var picIndex = $('#picIndex').val();
	var dataResult;
	$.ajax({   
		type : "get",   
		url : url,   
		data:{beginOrderId:beginOrderId,endOrderId:endOrderId,ignoreOrderId:picIndex},
		async : false,   
		success : function(data){   
			dataResult = parserToJson(data);
		}   
	});
	return dataResult;
}

function getBeginIndex(index){
	var tempIndex = index-16;
	var isFirst = true;
	while(tempIndex>6){
		tempIndex = tempIndex - 6;
		if(isFirst){
			tempIndex = tempIndex - 1;
			isFirst = false;
		}
	}
	if(!(tempIndex >=3 && tempIndex <=6) ){
		return "";
	}else {
		return index-(tempIndex - 3);
	}
}


function innerPic(data,beginOrderId){
	var staticUrl = $("#staticUrl").val();
	$.each(data.picList,function(i,row){
		var link = row.link;
		if(beginOrderId != '' && link.indexOf('/front/manufacturerTopic/view.htm')>=0){
			link = link + '&beginPicIndex='+beginOrderId;
		}
		var innerHtml ='<a href="'+link+'"><img onerror="this.src=\''+staticUrl+'/images/nophoto.png\'" src="'+row.url+'" width="150" height="50" /></a>';
		$('#pinpai').append(innerHtml);
	});
}

function selectFamous(){
	var url = '/front/manufacturerDetail/pageFamous.json?'+Math.random();
	var detailList;
	var topicId = $('#topicId').val();
	$.ajax({   
		type : "get",   
		url : url,   
		data:{pageIndex:1,rows:3,topicId:topicId},
		async : false,   
		success : function(data){   
			detailList = parserToJson(data);
		}   
	});
	return detailList;
}

function loadFamous(){
	$('#famousList').html('');
	var detailList = selectFamous();
	innerFamous(detailList);
}

function innerFamous(detailList){
	var staticUrl = $("#staticUrl").val();
	$.each(detailList,function(i,row){
		var innerHtml = 
			'<div class="product_li_le">'+
			'<div class="left_img"><a target="blank" href="/front/merchandise/detail.htm?id='+row.merchandiseId+'"><img onerror="this.src=\''+staticUrl+'/images/nophoto.png\'" src="'+merchandiseImagePath+substrVal2(row.orgMerchandiseCode,11)+'/'+substrVal2(row.orgMerchandiseCode,11)+'.JPG" width="70" height="70" /></a></div>'+
			'<div class="left_font">'+
			'<p><a target="blank" href="/front/merchandise/detail.htm?id='+row.merchandiseId+'" class="p_name" title="'+row.merchandiseName+'">'+substrVal(row.merchandiseName,7)+'</a></p>'+
			'<p class="yuanj">零售价:'+row.formatRetailPrice+'</p>';
			if(isCustLogin){
				innerHtml=innerHtml+
				'<p class="xianj">会员价:'+row.formatMermberPrice+'</p>';
			 }else {
				 innerHtml=innerHtml+
				 '<p class="xianj">会员价:--</p>';
			}
			innerHtml=innerHtml+
			'<p><a href="javascript:void(0)" onclick="openBuyWindow('+row.merchandiseId+');">加入购物车<img width="5" height="10" src="'+staticUrl+'/images/icon.gif"></a></p>'+
			'</div>'+
			'</div>'+
			'<div class="clearit"></div>';
			$('#famousList').append(innerHtml);
	});
}

function selectDetailList(pageNum,pageSize){
	$('#productList').html('');
	var url = '/front/manufacturerDetail/pageDetail.json?'+Math.random();
	var detailList;
	$.ajax({   
		type : "get",   
		url : url,   
		data:{pageIndex:pageNum,rows:pageSize,topicId:$('#topicId').val()},
		async : false,   
		success : function(data){   
			detailList = parserToJson(data);
		}   
	});
	return detailList;
}

//分页加载专题明细
function loadDetail(pageNum,pageSize){
	var detailList = selectDetailList(pageNum,pageSize);
	innerDetail(detailList.merchandiseList);
	return detailList.pagination;
}


function innerDetail(detailList){
	var staticUrl = $("#staticUrl").val();
	$.each(detailList,function(i,row){
		var innerHtml = '<div class="product_imglist">'+
		'<div class="blank10 clearit"></div>'+
		'<div class="imgbox"><a target="_blank" href="/front/merchandise/detail.htm?id='+row.merchandiseId+'"><img onerror="this.src=\''+staticUrl+'/images/nophoto.png\'" src="'+merchandiseImagePath+substrVal2(row.orgMerchandiseCode,11)+'/'+substrVal2(row.orgMerchandiseCode,11)+'.JPG" width="90" height="90" /></a></div>'+
		'<div class="fontbox"><p><a target="blank" href="/front/merchandise/detail.htm?id='+row.merchandiseId+'">'+row.currencyName+'</a></p><p>'+(row.passfileNumber == null?'':row.passfileNumber)+'</p><p >药品编码：'+row.orgMerchandiseCode+'</p></div>'+
		'<div class="s_num">'+row.middlingPacking+'</div>';
		if(isCustLogin){
			innerHtml=innerHtml+
			'<div class="pricehnum">'+row.formatMermberPrice+'</div>';
		 }else {
			 innerHtml=innerHtml+
				'<div class="pricehnum">--</div>';
		}
		innerHtml=innerHtml+
		'<div class="pricelnum">'+row.formatRetailPrice+'</div>'+
		'<div class="k_num">'+formatStorage(row.showTactics,row.merchandiseId)+'</div>'+
		'<div class="now_num"><a href="javascript:void(0);" class="minus"><img src="'+staticUrl+'/images/minus.gif"></a>';
		if(row.isDecimal){
			innerHtml=innerHtml+
			' <input name="buyNumber" class="price1" value="1"> ';
		}else {
			innerHtml=innerHtml+
			' <input name="buyNumber" class="price" value="1"> ';
		} 
		innerHtml=innerHtml+
		'<a href="javascript:void(0);" class="plus"><img src="'+staticUrl+'/images/plus.gif"></a></div>'+
		'<div class="small_buy"><button class="small_btn" onclick="localAddCart('+row.merchandiseId+',this)"></button></div>'+
		'<div class="blank10 clearit"></div>'+
		'</div>'+
		'<div class="clearit"></div>';
		$('#productList').append(innerHtml);
	});
}

function localAddCart(merchandiseId,obj){
	var buyNumber = $(($(obj).parent().parent().find('[name=buyNumber]'))[0]).val();
	add_one_merchandise_to_cart2(merchandiseId,buyNumber)
}