// DOM Ready		
$(function() { 
	var offset = $(".oneli a").offset();
	if (offset == null){
		$("#NaviActive").css('left',0);
	}else{//alert(offset);
		$("#NaviActive").css("left",0);
	}
	$(".oneli").click(function(){//alert(sfix);
		var ink=$(this).index();;
		var a = $(this).width();
		$("#NaviActive").stop().animate({left:ink*a});
		
});
});
//$('.news_tit ul li').click(function(){var a = $(this).index();
//$('.news_con').hide();
//$('.news_con').eq(a).show();
//if(a==0){$('.news_tit ul li:last').removeClass('yydt').addClass('yydt1');
//$(this).removeClass('hyxw1').addClass('hyxw');}
//else {$('.news_tit ul li:first').removeClass('hyxw').addClass('hyxw1');$(this).removeClass('yydt1').addClass('yydt');}})
//$(document).ready(function(){
//	$('.new_wddd_menu_nav div').click(function(){
//		var index = $(this).index();
//		$('.contents .tabContent').hide();
//		$('.contents .tabContent:eq('+index+')').show();


	
//});

