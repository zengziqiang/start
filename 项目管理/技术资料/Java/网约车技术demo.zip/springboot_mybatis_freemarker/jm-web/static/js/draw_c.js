// JavaScript Document
	var $i = 0; //index
	var poolId=$("#poolId").val();
	
$.fn.draw = function(options){
	
	var $_this = $(this);
	var $dp = options.prod;

	var $r = $("#firstGiftId").val(); //round,第一个奖品ID
	var $s = 100; //spead
	
	
	var $t=$dp.find(".roulette-prize-shade").length-1;
	function dr(){
		//drawround
		if($_this.res!='' && $_this.res!=undefined && $i==0){
			dr2();
		}else{

			$dp.find(".roulette-prize-shade").hide().eq($i).show();
			$i = $i >= $t ? 0 : $i+1;
			setTimeout(dr,$s);
		}
	}
	
	function dr2(){
		
		$dp.find(".roulette-prize-shade").hide().eq($i).show();
		$i = $i >= $t ? 0 : $i+1;
		$s = $s+30;
		
		if( $r < $_this.res + $t ){
			$r++;
		}else{
		
			
			$r = $("#firstGiftId").val();
			$s = 100;
			setTimeout(result,1000);
			return;
		}
		setTimeout(dr2,$s);
	}
	
	function getRes(item){
		$_this.res = '';
		//赋结果值
		setTimeout(function(){
			$_this.res =parseInt(item)+parseInt(1); //设置最终停止位置
		},3000);
	}
	var giftId="";
	var giftType="";
	var giveNumber="";
	var flag=true;
	var credits=0;
	function click(){
		$_this.bind("click",function(){
//			if(flag){
//				showDialog("每次抽奖需要消耗"+score+"九州币，是否继续？");
//				flag=false;
//				return;
//			}
			//请求抽奖返回结果
			var url= "/member/present/lottery.json?time="+Math.random()+"&poolId="+poolId;
			  $.get(url,function(data){
				  var dataObj=eval("("+data+")");
				  if(dataObj.success==null){
					  giftId=dataObj.giftId;
					  giftType=dataObj.giftType;
					  giveNumber=dataObj.giveNumber;
					  getRes(dataObj.giftId);
					  credits=dataObj.credits;
					  dr();
					  $_this.unbind("click");
				  }else{
					  alert(dataObj.msg);
				  }
			  });
		});
	}click();

	function result(){
		$("#yhsyjzb").html(credits);
		getAllGift();
		getSurplusCount();//获取剩余抽奖次数
		if(giftId==12){
			$i=0;
		}else{
			$i=giftId;
		}
		if(giftType==4){
			showDialog("很遗憾，本次抽奖没有抽中哦，再接再厉期待下一次的大奖!");
		}else if(giftType==3){//九州币
			showDialog("恭喜您,获得了"+giveNumber+"个九州币!");
		}else if(giftType==2){//积分
			showDialog("恭喜您,获得了"+giveNumber+"个积分!");
		}else{
			showDialog("恭喜您,获得了"+$("#prize"+giftId).val()+"!");
		}
		click();
	}
};

$("#go").draw({
	prod:$("#game")
});

function showDialog(content){
	if ($('#show_info_dialog1').length > 0) {
		$('#show_info_dialog1').remove();
	}
	if ($('#show_info_dialog1').length <= 0) {
		var str = '<div id="show_info_dialog1" class="box_main"><div class="box_top"><P class="box_top_title">'
				+ '<span style="margin-left:20px;"><img src="/static/images/image/box_ico.gif" width="18" height="18" /></span><span style="margin-left:5px;">提示</span>'
				+ '</P><p class="box_top_close"><img src="/static/images/image/box_close.gif"  /></p></div>'
				+ '<div class="box_middle"><div class="box_button"  id="boxbutton"><p class="box_font">'
				+ content
				+ '</p></div></div><div class="box_bottom"><a class="btn-bar btnmargin140" href="javascript:goAhead();"><span>继续</span></a><a class="btn-bar btnmargin20" href="javascript:void(0);"><span>取消</span></a></div></div>';
		$('body').append(str);
	}
	showBg('#show_info_dialog1', 400, 215);
	$('.box_top_close img,.btn-bar').click(function() {
		$("#fullbg").hide();
		$("#show_info_dialog1").hide();
	});
}
function goAhead(){
	$("#go").click();
};

function getAllGift(){
	$.get("/member/present/getAllGift.json?time="+Math.random(),function(data){
		  var dataObj=eval("("+data+")");
		  var items=dataObj.giftInfoItemVOs;
		/*  if(items[0].giftAmount<=0&&items[0].giftType!=4){
			 $("#game").append("<div class='roulette-prize-no ' style='width: 123px; height: 104px; left: 0px; top: 0px;display:;'>已&nbsp;抽&nbsp;完</div>");
			 }
		  if(items[1].giftAmount<=0&&items[1].giftType!=4){
			  $("#game").append("<div class='roulette-prize-no' style='width: 123px; height: 104px; left: 124px; top: 0px;display:;'>已&nbsp;抽&nbsp;完</div>");
			 }
		  if(items[2].giftAmount<=0&&items[2].giftType!=4){
			  $("#game").append("<div class='roulette-prize-no' style='width: 123px; height: 104px; left: 248px; top: 0px;display:;'>已&nbsp;抽&nbsp;完</div>");
			 }
		  if(items[3].giftAmount<=0&&items[3].giftType!=4){
			  $("#game").append("<div class='roulette-prize-no' style='width: 123px; height: 104px; left: 372px; top: 0px;display:;'>已&nbsp;抽&nbsp;完</div>");
			 }
		  if(items[4].giftAmount<=0&&items[4].giftType!=4){
			  $("#game").append("<div class='roulette-prize-no' style='width: 123px; height: 104px; left: 496px; top: 0px;display:;'>已&nbsp;抽&nbsp;完</div>");
			 }
		  if(items[5].giftAmount<=0&&items[5].giftType!=4){
			  $("#game").append("<div class='roulette-prize-no' style='width: 123px; height: 104px; left: 496px; top: 105px;display:;'>已&nbsp;抽&nbsp;完</div>");
			 }
		  if(items[6].giftAmount<=0&&items[6].giftType!=4){
			  $("#game").append("<div class='roulette-prize-no' style='width: 123px; height: 104px; left: 496px; top: 210px;display:;'>已&nbsp;抽&nbsp;完</div>");
			 }
		  if(items[7].giftAmount<=0&&items[7].giftType!=4){
			  $("#game").append("<div class='roulette-prize-no' style='width: 123px; height: 104px; left: 372px; top: 210px;display:;'>已&nbsp;抽&nbsp;完</div>");
			 }
		  if(items[8].giftAmount<=0&&items[8].giftType!=4){
			  $("#game").append("<div class='roulette-prize-no' style='width: 123px; height: 104px; left: 248px; top: 210px;display:;'>已&nbsp;抽&nbsp;完</div>");
			 }
		  if(items[9].giftAmount<=0&&items[9].giftType!=4){
			  $("#game").append("<div class='roulette-prize-no' style='width: 123px; height: 104px; left: 124px; top: 210px;display:;'>已&nbsp;抽&nbsp;完</div>");
			 }
		  if(items[10].giftAmount<=0&&items[10].giftType!=4){
			  $("#game").append("<div class='roulette-prize-no' style='width: 123px; height: 104px; left: 0px; top: 210px;display:;'>已&nbsp;抽&nbsp;完</div>");
			 }
		  if(items[11].giftAmount<=0&&items[11].giftType!=4){
			  $("#game").append("<div class='roulette-prize-no' style='width: 123px; height: 104px; left: 0px; top: 105px;display:;'>已&nbsp;抽&nbsp;完</div>");
			 }*/
		  });
}

function getSurplusCount(){
	$.get("/member/present/getSurplusCount.json?poolId="+poolId+"&time="+Math.random(),function(data){
		var dataObj=eval("("+data+")");
		//alert(dataObj.surplusCount);
		$("#surplusCount").html(dataObj.surplusCount);
	});
}







