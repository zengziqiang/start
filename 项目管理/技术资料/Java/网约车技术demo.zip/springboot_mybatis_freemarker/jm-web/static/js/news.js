// JavaScript Document
$(document).ready(function() {
	initTitle(5);
});

$(window).load(function() {

 var liW = $("#actor li:first").height();
 var liL = $("#actor li").length;

    var lis = $("#actor li").length;


 
  $("#bnt li").each(function(index) {
   $(this).click(function(){
    if($("#actor").is(":animated")==false){
     $("#actor").animate({"marginTop":-index*liW},500,function(){

	
	      $("#bnt li").removeClass("sli");
     $("#bnt li").eq(index).addClass("sli");
	  $('.case h2').children('a').removeClass("lan_c");
	 $('.case h2').children('a').eq(index).addClass("lan_c");
     });
      };
    });
        });
  settime=window.setInterval(atuoScroll,2000);
  $("#jiaodian").hover(function(){
  window.clearInterval(settime);
  },function(){
  settime=window.setInterval(atuoScroll,2000);
 });
 
 


//////////////////////////////////////

});//END


function atuoScroll(){
  var liW = $("#actor li:first").height();
  var liL = $("#actor li").length;
  var ulM =parseInt( $("#actor").css("margin-top"));

  if(ulM==-((liL-1)*liW)&&$("#actor").is(":animated")==false){
	
   $("#actor").stop();
  $("#actor").animate({marginTop:0},500,function(){
     $("#bnt li").removeClass("sli");
     $("#bnt li:first").addClass("sli");
	  $('.case h2').children('a').removeClass("lan_c");
	 $('.case h2').children('a').eq(0).addClass("lan_c");   
   });
   }
   
  else if($("#actor").is(":animated")==false){
  $("#actor").stop();
  $("#actor").animate({"marginTop":ulM-liW},500,function(){
  var ulM =parseInt( $("#actor").css("margin-top"));
  var num = -ulM/liW
     $("#bnt li").removeClass("sli");
     $("#bnt li").eq(num).addClass("sli");   
	 $('.case h2').children('a').removeClass("lan_c");
	 $('.case h2').children('a').eq(num).addClass("lan_c");
   });
   };
 };
