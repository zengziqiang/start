package com.jm.platform;

import org.apache.commons.lang.StringUtils;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * DateUtils 日期工具类
 */
public class DateUtils {

    private static final TimeZone         TZ = TimeZone.getTimeZone("GMT+:08:00");
    private static final SimpleDateFormat FORMAT_DATE_TIME;
    private static final SimpleDateFormat FORMAT_TIME;
    private static final SimpleDateFormat FORMAT_DATE;
    private static final SimpleDateFormat FORMAT_MONTH_DATE;

    private static final SimpleDateFormat FORMAT_YYYYMMDD;

    private static final SimpleDateFormat FORMAT_DATE_NOZONE;

    public static final String   SHORT_DATE_FORMAT_STR   = "yyyy-MM-dd";
    public static final String   LONG_DATE_FORMAT_STR    = "yyyy-MM-dd HH:mm:ss";
    public static final DateFormat SHORT_DATE_FORMAT       = new SimpleDateFormat(SHORT_DATE_FORMAT_STR);
    public static final DateFormat LONG_DATE_FORMAT        = new SimpleDateFormat(LONG_DATE_FORMAT_STR);
    public static final String     EARLY_TIME              = "00:00:00";
    public static final String     LATE_TIME               = "23:59:59";

    static {
        FORMAT_DATE_TIME = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        FORMAT_DATE_TIME.setTimeZone(TZ);

        FORMAT_TIME = new SimpleDateFormat("HH:mm:ss");
        FORMAT_TIME.setTimeZone(TZ);

        FORMAT_DATE = new SimpleDateFormat("yyyy-MM-dd");
        FORMAT_DATE.setTimeZone(TZ);

        FORMAT_MONTH_DATE = new SimpleDateFormat("yyyyMM");
        FORMAT_MONTH_DATE.setTimeZone(TZ);

        FORMAT_YYYYMMDD = new SimpleDateFormat("yyyyMMdd");
        FORMAT_YYYYMMDD.setTimeZone(TZ);

        FORMAT_DATE_NOZONE = new SimpleDateFormat("yyyy-MM-dd");
    }

    public static Calendar getCalendar() {
        return Calendar.getInstance(TZ);
    }

    public static String toDateTimeStr(Date date) {
        return FORMAT_DATE_TIME.format(date);
    }

    public static String toTimeStr(Date date) {
        return FORMAT_TIME.format(date);
    }

    public static String toDateStr(Date date) {
        return FORMAT_DATE.format(date);
    }

    public static String toMonthStr(Date date) {
        return FORMAT_MONTH_DATE.format(date);
    }

    public static Integer toyyyyMMdd(Date date) {
        return Integer.parseInt(FORMAT_YYYYMMDD.format(date));
    }

    /**
     * 2016-02-23
     */
    public static Date fromDate(String v) {
        try {
            return FORMAT_DATE.parse(v);
        } catch (ParseException e) {
            return new Date();
        }
    }

    /**
     * 格式化时间为yyyy-MM-dd，不设置时区
     * @param str
     * @return
     */
    public static Date formatDateNoZone(String str) {
        try {
            return FORMAT_DATE_NOZONE.parse(str);
        } catch (ParseException e) {
            return new Date();
        }
    }

    /**
     * 20160223
     */
    public static Date fromDate(Integer vs) {
        try {
            String v = Integer.toString(vs);
            Calendar calc = getCalendar();
            calc.set(Calendar.YEAR, Integer.parseInt(v.substring(0, 4)));
            calc.set(Calendar.MONTH, Integer.parseInt(v.substring(4, 6)) - 1);
            calc.set(Calendar.DAY_OF_MONTH, Integer.parseInt(v.substring(6, 8)));

            calc.set(Calendar.HOUR_OF_DAY, 0);
            calc.set(Calendar.MINUTE, 0);
            calc.set(Calendar.SECOND, 0);
            return calc.getTime();

        } catch (Exception e) {
            return new Date();
        }
    }

    /**
     * 2016-02-23 08:09:01
     */
    public static Date fromDateTime(String v) {
        try {
            return FORMAT_DATE_TIME.parse(v);
        } catch (ParseException e) {
            return new Date();
        }
    }

    /**
     * <pre>
     * 2016-02-23 return 2016-02-24
     * 2016-02-29 return 2016-03-01
     * </pre>
     */
    public static Date addDay(Date v, int days) {
        final Calendar calc = getCalendar();
        calc.setTime(v);
        calc.add(Calendar.DAY_OF_WEEK, days);
        return calc.getTime();
    }

    /**
     * 获取按天累加的日期序列
     */
    public static List<Date> getDaySeq(Date dt1, Date dt2) {
        final Calendar calc = getCalendar();

        List<Date> r = new ArrayList<>();
        for (calc.setTime(dt1); calc.getTime().compareTo(dt2) <= 0; calc.add(Calendar.DAY_OF_WEEK, 1)) {
            r.add(calc.getTime());
        }
        return r;
    }

    /**
     * <pre>
     * 获取按月累加的日期序列, 例如 201601 201702
     * 返回  201601 201602 201603
     * </pre>
     */
    public static List<String> getMonthSeq(int d1, int d2) {
        Date dt1 = fromDate(Integer.parseInt(Integer.toString(d1) + "01"));
        Date dt2 = fromDate(Integer.parseInt(Integer.toString(d2) + "01"));
        return getMonthSeq(dt1, dt2);
    }

    /**
     * 获取按月累加的日期序列, 返回 201601 201602 201603
     */
    public static List<String> getMonthSeq(Date dt1, Date dt2) {
        final Calendar calc = Calendar.getInstance();

        calc.setTime(dt1);
        if (calc.get(Calendar.DAY_OF_MONTH) > 1) {
            dt1 = fromDate(Integer.parseInt(toMonthStr(dt1).substring(0, 6) + "01"));
        }
        calc.setTime(dt2);
        if (calc.get(Calendar.DAY_OF_MONTH) > 1) {
            dt2 = fromDate(Integer.parseInt(toMonthStr(dt2).substring(0, 6) + "01"));
        }

        List<String> r = new ArrayList<>();
        for (calc.setTime(dt1); calc.getTime().compareTo(dt2) <= 0; calc.add(Calendar.MONTH, 1)) {
            r.add(toMonthStr(calc.getTime()));
        }
        return r;
    }

    /**
     * 用于设置后台搜索的时间项 袁华
     *
     * @param map
     * @param timeStr
     * @param identify
     */
    public static void setTime(Map map, String timeStr, String identify) {
        if (!StringUtils.isEmpty(timeStr)) {
            String[] vs = timeStr.split("至");
            if (vs.length == 2) {
                Timestamp dt1 = new Timestamp(DateUtils.formatDateNoZone(vs[0].trim()).getTime());
                Timestamp dt2 = new Timestamp(DateUtils.addDay(DateUtils.formatDateNoZone(vs[1].trim()), 1).getTime());
                map.put(identify + "Begin", dt1);
                map.put(identify + "End", dt2);
            }
        }
    }
    /**
     * 得到某个日期在这一天中时间最早的日期对象
     *
     * @param date
     * @return
     * @throws ParseException
     */

    public static Date getEarlyInTheDay(Date date) {
        String dateString = SHORT_DATE_FORMAT.format(date) + " " + EARLY_TIME;
        try {
            return LONG_DATE_FORMAT.parse(dateString);
        } catch (ParseException e) {
            throw new RuntimeException("parser date error.", e);
        }
    }
    /*
    * 获取前后日期 i为正数 向后推迟i天，负数时向前提前i天
    * @author XP
    * @time 2016年11月25日
    */
    public static Date getDate(int i) {
        Date dat = null;
        Calendar cd = Calendar.getInstance();
        cd.add(Calendar.DATE, i);
        dat = cd.getTime();
        SimpleDateFormat dformat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Timestamp date = Timestamp.valueOf(dformat.format(dat));
        return date;
    }

    /*
     * 获取当前时间加或减一段时间以后的日期 , i为正数 向后推迟，负数时向前提前
     * @param i 增量, calendar 类型
     * @author XP
     * @time 2016年11月25日
     */
    public static Date getDate(int i, int calendar) {
        Date dat = null;
        Calendar cd = Calendar.getInstance();
        cd.add(calendar, i);
        dat = cd.getTime();
        SimpleDateFormat dformat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Timestamp date = Timestamp.valueOf(dformat.format(dat));
        return date;
    }

    /**
     * 使用参数Format格式化Date成字符串
     *
     * @return String
     */
    public static String format(Date date, String pattern) {
        return date == null ? "" : new SimpleDateFormat(pattern).format(date);
    }
    public static void main(String[] args) {
        String d1 = "2016-02-23";
        String d2 = "2016-03-02";
        System.out.println(d1);

        System.out.println(toDateTimeStr(fromDate(20161018)));

        // System.out.println(fromDate(d1).compareTo(fromDate(d2)));
        // System.out.println(fromDate(d2).compareTo(fromDate(d1)));
        // System.out.println(fromDate(d1).compareTo(fromDate(d1)));

        List<Date> seq = getDaySeq(fromDate(d1), fromDate(d2));
        for (Date d : seq) {
            System.out.println(toDateStr(d));
        }
    }
}
