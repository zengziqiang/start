package com.jm.platform;

import java.util.Map;

/**
 * 用来向客户端抛出 Json 对象格式的异常
 */
public class JsonMessageException extends RuntimeException {

    private final Map<?, ?> innerMessage;

    public JsonMessageException(String message) {
        this.innerMessage = YvanUtil.jsonToMap(message);
    }

    public JsonMessageException(String message, Throwable cause) {
        super("", cause);
        this.innerMessage = YvanUtil.jsonToMap(message);
    }

    public Map<?, ?> getInnerMessage() {
        return innerMessage;
    }
}
