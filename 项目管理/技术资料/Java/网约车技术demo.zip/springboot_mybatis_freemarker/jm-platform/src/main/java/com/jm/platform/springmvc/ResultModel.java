package com.jm.platform.springmvc;


import com.github.pagehelper.Page;

import java.util.LinkedHashMap;

/**
 * 用来快速返回结果的model对象
 */
public class ResultModel extends LinkedHashMap<String, Object> {

    public static ResultModel newSuccess() {
        return new ResultModel() {
            {
                this.put("success", true);
            }
        };
    }

    public static ResultModel newSuccess(final Object data) {
        return new ResultModel() {
            {
                this.put("success", true);
                this.put("data", data);
            }
        };
    }

    public static ResultModel newFail(final String errorMsg) {
        return new ResultModel() {
            {
                this.put("success", false);
                this.put("msg", errorMsg);
            }
        };
    }

    public static ResultModel newBootstrapPaginationData(final Object data) {
        return new ResultModel() {
            {
                this.put("success", true);
                this.put("total", ((Page) data).getTotal());
                this.put("rows", data);
            }
        };
    }

    public static Object newEasyuiResult(final long total, final Object rows) {
        return new ResultModel() {
            {
                this.put("total", total);
                this.put("rows", rows);
            }
        };
    }
}
