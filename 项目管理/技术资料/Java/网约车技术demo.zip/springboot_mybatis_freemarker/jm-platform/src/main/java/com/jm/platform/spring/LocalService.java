package com.jm.platform.spring;

public interface LocalService {
}
