package com.jm.platform;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

public class FileUploadUtils {
    private static final Logger logger = LoggerFactory.getLogger(FileUploadUtils.class);

    public static String uploadFile(MultipartFile multipartFile, String absolutePath, String relativePath, long maxSize, String[] includesuffixs)
            throws Exception {
        String realAbsolutePath = initPath(absolutePath + relativePath);
        String fileName = multipartFile.getOriginalFilename();
        if (StringUtils.isEmpty(fileName)) return null;
        String[] split = fileName.split("\\.");
        String suffix = split.length >= 2 ? split[split.length - 1] : "temp";
        canUpload(multipartFile, suffix, maxSize, includesuffixs);
        String filePrefix = new Long(System.currentTimeMillis()).toString() + UUID.randomUUID().toString().substring(0, 3);
        String destFileName = realAbsolutePath + filePrefix + "." + suffix;
        File destFile = new File(destFileName);
        try {
            multipartFile.transferTo(destFile);
            logger.info("上传文件:" + destFileName);
        } catch (Exception e) {
            return null;
        }
        return destFileName.replace(absolutePath, "");
    }

    private static String initPath(String absolutePath) {
        String today = new SimpleDateFormat("yyyyMMdd").format(new Date());
        String todayPath = absolutePath.endsWith("/") ? absolutePath + today : absolutePath + "/" + today + "/";
        initDir(todayPath);
        return todayPath;
    }

    private static void initDir(String uploadPath) {
        File directory = new File(uploadPath);
        if (!directory.isDirectory()) {
            directory.mkdirs();
        }
    }

    private static void canUpload(MultipartFile multipartFile, String suffix, long maxSize, String[] includesuffixs) throws IOException {
        if (multipartFile == null || multipartFile.getSize() == 0) {
            throw new IOException("上传文件不存在");
        }
        if (multipartFile.getSize() > maxSize * 1024) {
            throw new IOException("上传文件不能超过  " + maxSize + " K");
        }
        if (includesuffixs == null || includesuffixs.length == 0) return;
        boolean eixstSuffix = false;
        for (String includesuffix : includesuffixs) {
            if (includesuffix.toLowerCase().equals(suffix.toLowerCase())) {
                eixstSuffix = true;
                break;
            }
        }
        if (!eixstSuffix) {
            throw new IOException("上传的文件格式不正确");
        }
    }
}
